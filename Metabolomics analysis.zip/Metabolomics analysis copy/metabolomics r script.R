#install_github("jokergoo/ComplexHeatmap")
#install.packages("ggh4x")
library(ComplexHeatmap)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
#BiocManager::install("clusterProfiler")
library(clusterProfiler)
library(ggplot2)
library(tidyr)
library(ggrepel)
library(ggfortify)
library(ggforce)
library(extrafont)
extrafont::loadfonts()
#install.packages("cluster")
library(cluster)
library(factoextra)
library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
library(writexl)
library(Cairo)
#install.packages("Cairo")

#import data sheets
iroa_pos <- read_excel("Input/IROA POSITIVE.xlsx")
iroa_neg <- read_excel("Input/IROA NEGATIVE.xlsx")
hilic_pos <- read_excel("Input/HILIC POSITIVE.xlsx")
hilic_neg <- read_excel("Input/HILIC NEGATIVE.xlsx")

#clean up sample names
colnames(iroa_pos) <- sub("_[GB].*", "", colnames(iroa_pos))
colnames(iroa_neg) <- sub("_[GB].*", "", colnames(iroa_neg))
colnames(hilic_pos) <- sub("_[GB].*", "", colnames(hilic_pos))
colnames(hilic_neg) <- sub("_[GB].*", "", colnames(hilic_neg))

#Call out the most relevant columns
iroa_pos <- iroa_pos[c(1,19:98)]
iroa_neg <- iroa_neg[c(1,19:98)]
hilic_pos <- hilic_pos[c(1,19:98)]
hilic_neg <- hilic_neg[c(1,19:98)]


#convert to log2
iroa_pos <- iroa_pos %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
iroa_neg <- iroa_neg %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
hilic_pos <- hilic_pos %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
hilic_neg <- hilic_neg %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))

#export sheets
write.csv(iroa_pos,"Output/Log IROA POSITIVE.csv")
write.csv(iroa_neg,"Output/Log IROA NEGATIVE.csv")
write.csv(hilic_pos,"Output/Log HILIC POSITIVE.csv")
write.csv(hilic_neg,"Output/Log HILIC NEGATIVE.csv")

#mf1 <- iroa_pos
#mf1 <- iroa_neg
mf1 <- hilic_pos
#mf1 <- hilic_neg

# rearrange columns based on sex and genotype
mf1 <- mf1[, order(sub(".*?(\\(.*\\))", "\\1", colnames(mf1)))]

#finetune column order
mf1 <- mf1[c(81, 34:38, 1:4, 29:33, 5:10, 11:28, 75:80, 39:42, 70:74, 43:47,48:69)]

#write.csv(mf1, "Output/IS normalized Lipidomics II.csv")


m1 <- as.matrix(mf1)
m2 <- m1 [,2:81]
rownames(m2) <- mf1$Compound

#rename columns
m3 <- as.data.frame(m2) %>%
  mutate(across(1:80, as.numeric))

suffixes <- sub(".*?(\\(.*)", "\\1", colnames(m3))
group_ids <- match(suffixes, unique(suffixes))
letters <- ave(suffixes, suffixes, FUN = \(x) LETTERS[seq_along(x)])

colnames(m3) <- paste0(group_ids, letters)

#calculate row z-score
m3.z <- t(scale(t(m3)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
FnWT <- length(grep("^1[A-Z]$", colnames(m4)))
FnCre <- length(grep("^2[A-Z]$", colnames(m4)))
FnTam <- length(grep("3", colnames(m4)))
FnCreTam <- length(grep("4", colnames(m4)))
FnHet <- length(grep("5", colnames(m4)))
FnKO <- length(grep("6", colnames(m4)))
MnWT <- length(grep("7", colnames(m4)))
MnCre <- length(grep("8", colnames(m4)))
MnTam <- length(grep("9", colnames(m4)))
MnCreTam <- length(grep("10", colnames(m4)))
MnHet <- length(grep("11", colnames(m4)))
MnKO <- length(grep("12", colnames(m4)))


end_index_FnWT <- grep("^1[A-Z]$", colnames(m4)) [FnWT]
end_index_FnCre <- grep("^2[A-Z]$", colnames(m4)) [FnCre]
end_index_FnTam <- grep("3", colnames(m4)) [FnTam]
end_index_FnCreTam <- grep("4", colnames(m4)) [FnCreTam]
end_index_FnHet <- grep("5", colnames(m4)) [FnHet]
end_index_FnKO <- grep("6", colnames(m4)) [FnKO]
end_index_MnWT <- grep("7", colnames(m4)) [MnWT]
end_index_MnCre <- grep("8", colnames(m4)) [MnCre]
end_index_MnTam <- grep("9", colnames(m4)) [MnTam]
end_index_MnCreTam <- grep("10", colnames(m4)) [MnCreTam]
end_index_MnHet <- grep("11", colnames(m4)) [MnHet]
end_index_MnKO <- grep("12", colnames(m4)) [MnKO]


#row_order <- order(class_factor)

heatmap <- Heatmap(m4,
                   show_row_names = F,
                   show_column_names = F,
                   show_row_dend = TRUE,
                   show_column_dend = F,
                   
                   cluster_rows = TRUE,
                   #cluster_columns = T,
                   #row_order = row_order,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D2",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(col = "black", fontsize = 8),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(100, "mm"),
                   width = ncol(m4)*unit(3, "mm"),
                   
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = "Z-score",
                     title_position = "topleft",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(3, "cm")),
                   
                   split = 4, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                     
                     ind = unique(c(mat[, c(end_index_FnWT,
                                            end_index_FnCre,
                                            end_index_FnTam,
                                            end_index_FnCreTam,
                                            end_index_FnHet,
                                            end_index_FnKO,
                                            end_index_MnWT,
                                            end_index_MnCre,
                                            end_index_MnTam,
                                            end_index_MnCreTam,
                                            end_index_MnHet,
                                            end_index_MnKO
                     ) # enter the number where you want a gap between columns
                     ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
) 

draw(heatmap)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 1
grid.rect(x = (end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnWT)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("F_WT", 
          x = (end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 2
grid.rect(x = (end_index_FnCre + end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("F_Cre", 
          x = (end_index_FnCre + end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 3
grid.rect(x = (end_index_FnTam + end_index_FnCre)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("F_Tam", 
          x = (end_index_FnTam + end_index_FnCre)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 4
grid.rect(x = (end_index_FnCreTam + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("F_CreTam", 
          x = (end_index_FnCreTam + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("F_Het", 
          x = (end_index_FnHet + end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("F_KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 7
grid.rect(x = (end_index_MnWT + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnWT)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("M_WT", 
          x = (end_index_MnWT + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 8
grid.rect(x = (end_index_MnCre + end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("M_Cre", 
          x = (end_index_MnCre + end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 9
grid.rect(x = (end_index_MnTam + end_index_MnCre)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_Tam", 
          x = (end_index_MnTam + end_index_MnCre)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 10
grid.rect(x = (end_index_MnCreTam + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_CreTam", 
          x = (end_index_MnCreTam + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 11
grid.rect(x = (end_index_MnHet + end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("M_Het", 
          x = (end_index_MnHet + end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 12
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("M_KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))
## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnWT/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_FnCre/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_FnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_FnCreTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnKO/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnWT/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_MnCre/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_MnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_MnCreTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

#############################################################
#############################################################
#############################################################
#import data sheets without unknown annotations
iroa_pos <- read_excel("Input/IROA POSITIVE II.xlsx")
iroa_neg <- read_excel("Input/IROA NEGATIVE II.xlsx")
hilic_pos <- read_excel("Input/HILIC POSITIVE II.xlsx")
hilic_neg <- read_excel("Input/HILIC NEGATIVE II.xlsx")


#clean up sample names
colnames(iroa_pos) <- sub("_[GB].*", "", colnames(iroa_pos))
colnames(iroa_neg) <- sub("_[GB].*", "", colnames(iroa_neg))
colnames(hilic_pos) <- sub("_[GB].*", "", colnames(hilic_pos))
colnames(hilic_neg) <- sub("_[GB].*", "", colnames(hilic_neg))

#Call out the most relevant columns
iroa_pos <- iroa_pos[c(1,19:98)]
iroa_neg <- iroa_neg[c(1,19:98)]
hilic_pos <- hilic_pos[c(1,19:98)]
hilic_neg <- hilic_neg[c(1,19:98)]

#export sheets
write.csv(iroa_pos,"Output/IROA POSITIVE_cleaned.csv")
write.csv(iroa_neg,"Output/IROA NEGATIVE_cleaned.csv")
write.csv(hilic_pos,"Output/HILIC POSITIVE_cleaned.csv")
write.csv(hilic_neg,"Output/HILIC NEGATIVE_cleaned.csv")

#convert to log2
iroa_pos <- iroa_pos %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
iroa_neg <- iroa_neg %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
hilic_pos <- hilic_pos %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
hilic_neg <- hilic_neg %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))

#export sheets
write.csv(iroa_pos,"Output/Log IROA POSITIVE_cleaned.csv")
write.csv(iroa_neg,"Output/Log IROA NEGATIVE_cleaned.csv")
write.csv(hilic_pos,"Output/Log HILIC POSITIVE_cleaned.csv")
write.csv(hilic_neg,"Output/Log HILIC NEGATIVE_cleaned.csv")


##############################
####################################PLS-DA
#load dataset
iroa_pos <- read.csv("Output/Log IROA POSITIVE_cleaned.csv", row.names = 1, check.names = F)
iroa_neg <- read.csv("Output/Log IROA NEGATIVE_cleaned.csv", row.names = 1, check.names = F)
hilic_pos <- read.csv("Output/Log HILIC POSITIVE_cleaned.csv", row.names = 1, check.names = F)
hilic_neg <- read.csv("Output/Log HILIC NEGATIVE_cleaned.csv", row.names = 1, check.names = F)

#clean up column names
colnames(iroa_pos) <- sub("_.*", "", colnames(iroa_pos))
colnames(iroa_neg) <- sub("_.*", "", colnames(iroa_neg))
colnames(hilic_pos) <- sub("_.*", "", colnames(hilic_pos))
colnames(hilic_neg) <- sub("_.*", "", colnames(hilic_neg))

#merge dataframes into one dataframe
comb <- rbind(iroa_neg,iroa_pos,hilic_neg,hilic_pos)

# Extract the first column as column names
col_comb <- comb[, 1]

# Transpose the dataframe and set column names
transform_comb <- t(comb[,-1])
colnames(transform_comb) <- col_comb


# Converting matrix to data frame
transform_comb <- as.data.frame(transform_comb)

#Loading labelling key
lab <- read.csv("Input/Labeling key I.csv", check.names = F)
#lab2 <- read.csv("Input/Labeling key II.csv", check.names = F)
#lab3 <- read.csv("Input/Labelling key III.csv", check.names = F)
#merge labelling key to lipidomics data
transform_comb$Sample <- rownames(transform_comb)

# Then, merge by "Sample"
transform_comb <- merge(lab, transform_comb, by = "Sample")


#reorder dataframes
transform_comb <- transform_comb[order(transform_comb$Sex, transform_comb$Genotype), ]

write.csv(transform_comb, "Output/Combined metabolomics_wide II.csv")


######################## PLS-DA ############################################
# Install and load required packages
BiocManager::install("mixOmics")
library(mixOmics)

df2 <- read.csv("Output/Combined metabolomics_wide II.csv", check.names = F, row.names = 1)

# Remove rows where Genotype is "Cre"
df2 <- df2[df2$Genotype != "Cre", ]

# Remove rows where Genotype is "VC"
df2 <- df2[df2$Genotype != "VC", ]

# Remove rows where Genotype is "HET"
df2 <- df2[df2$Genotype != "HET", ]

# Remove rows where Genotype is "Tam"
df2 <- df2[df2$Genotype != "Tam", ]
##################################### Sex and Genotype as response variable
#combine sex and genotype columns into a single column
df2 <- df2 %>%
  mutate(Groups = paste(Sex, Genotype, sep = "_"))

#rearrange columns
df2 <- df2[c(1:3,443,4:442)]

X <- df2[, 5:443]  # predictors
Y <- as.factor(df2[, 4])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Protein = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
write.csv(vip_filtered, "Output/PLSDA VIP_SexbyGenotype response variable.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Metabolomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 22%` = scores[, 1],`X-Variate2: 10%` = scores[, 2],Group = Y, check.names = F) 
df_scores$Sex <- df2$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 22%`, y = `X-Variate2: 10%`, color = Group)) +
  geom_point(aes(fill=Group),shape=21,size=3,alpha=0.85,stroke=0.5,color="black")+
  stat_ellipse(aes(color=Group),type="norm",linewidth=0.4)+
  scale_color_manual(values=c("black","#359099","grey50","#AA4611"))+
  scale_fill_manual(values=c("white","#359099","grey","#AA4611"))+
  theme_bw(base_size=14)+
  theme(
    legend.position="none",
    panel.grid=element_blank(),
    axis.title=element_text(size=14),
    axis.text=element_text(size=14)
  )+
  labs(title="")

# Save plot
ggsave(filename = "Heart Metabolomics PLSDA_Sex and Genotype.pdf", width = 4.5, height = 4.69, units = "in")
ggsave(filename="Heart Metabolomics PLSDA_Sex and Genotype.svg",width=4.3,height=4.69,units="in")

##################################### Genotype as response variable
df2 <- read.csv("Output/Combined metabolomics_wide II.csv", check.names = F, row.names = 1)

# Remove rows where Genotype is "VC"
df2 <- df2[df2$Genotype != "VC", ]

# Remove rows where Genotype is "Tam"
df2 <- df2[df2$Genotype != "Tam", ]

# Remove rows where Genotype is "HET"
df2 <- df2[df2$Genotype != "HET", ]

# Remove rows where Genotype is "Cre"
df2 <- df2[df2$Genotype != "Cre", ]

X <- df2[, 4:442]  # predictors
Y <- as.factor(df2[, 3])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Metabolite = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
write.csv(vip_filtered, "Output/PLSDA VIP_Genotype response variable.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Metabolomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 11%` = scores[, 1],`X-Variate2: 12%` = scores[, 2],Group = Y, check.names = F) 
df_scores$Sex <- df2$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 11%`, y = `X-Variate2: 12%`, color = Group)) +
  geom_point(aes(shape = df2$Sex), size = 3, alpha = 0.9) +  # Shape mapped here only
  stat_ellipse(type = "norm", linewidth = 0.5) +             # Ellipses by Group only
  scale_color_manual(values = c("#B5A6B0","#7CD8AD", "#1C4649")) +
  scale_shape_manual(values = c("F" = 16, "M" = 17)) +
  theme_bw(base_size = 14) +  # Sets a larger base font size for the whole plot
  theme(
    axis.title = element_text(size = 14),     # Axis labels
    axis.text  = element_text(size = 14),   # Axis tick labels
    legend.title = element_text(size = 14),   # Legend title
    legend.text  = element_text(size = 14),                  # Legend items
  ) +
  labs(title = "Heart Metabolomics PLS-DA", shape = "Sex")

# Save plot
ggsave(filename = "Heart Metabolomics PLSDA_Genotype.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Metabolomics PLSDA_Genotype.svg",width=5.98,height=4.36,units="in")
########################################################################
########################################################################
########################## Dot Plot VIP################################
#import of data
vip <- read.csv("Output/PLSDA VIP_Genotype response variable.csv", row.names = 1)

#standardize lettering in VIP names
vip$Metabolite[-c(1, 2, 4)] <- sub("^(\\w)", "\\U\\1", tolower(vip$Metabolite[-c(1, 2, 4)]), perl = TRUE)

#Identify the top 25 vips
strong_vip <- vip %>%
  arrange(-comp1) %>%
  slice_head(n = 25) 

# Reorder Description based on comp1
strong_vip <- strong_vip %>%
  mutate(Metabolite = factor(Metabolite, levels = Metabolite[order(comp1, decreasing = F)]))


p.vip <- ggplot(strong_vip, aes(x = comp1, y = Metabolite)) +
  geom_point(size = 4, color = "black") +
  theme_bw(base_size = 13) +
  ylab(NULL) +
  xlab("VIP Score") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 11),
    axis.text.x = element_text(colour = "black", size = 13),
    strip.text = element_text(colour = "black"),
    legend.position = "none"
  )
p.vip
ggsave(filename="vip dotplot_Genotype response.pdf",width=4.4,height=4.36,units="in")
ggsave(filename="vip dotplot_Genotype response.svg",width=4,height=4.36,units="in")

#################LIMMA #########################################################
library(limma)

#exprs <- read.csv("Output/Log HILIC POSITIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
#exprs <- read.csv("Output/Log HILIC NEGATIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
#exprs <- read.csv("Output/Log IROA POSITIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
#exprs <- read.csv("Output/Log IROA NEGATIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
df <- read.csv("Output/combined metabolomics_wide II.csv", check.names = F, row.names = 1) #expression data
df$sample <- paste(df$Sample, df$Genotype, sep = "_")
df <- df[, c("sample", names(df)[!names(df) %in% c("Sample", "Sex", "Genotype", "sample")])]

#transpose data
exprs <- as.data.frame(t(df[, -1]))
colnames(exprs) <- df$sample
exprs <- cbind(Metabolite = rownames(exprs), exprs)
rownames(exprs) <- NULL

write.csv(exprs, "Output/Log2 Combined Metabolomics.csv")

sample_info <- read.csv("Input/Metabolomics metadata.csv", check.names = F) #metadata

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeWT = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "WT"),
  SexF_GenotypeCre = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre"),
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeCreTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre+Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeWT = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "WT"),
  SexM_GenotypeCre = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeCreTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre+Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:7)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
###############
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeCreTam - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
write.csv(results, "Output/Limma F_CreTamvs Tam.csv", row.names = F)

results <- results %>% filter(adj.P.Val < 0.05)
#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
###############
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeCreTam - SexM_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
write.csv(results, "Output/Limma M_CreTam vs Tam.csv", row.names = F)

results <- results %>% filter(adj.P.Val < 0.05)
#reorder dataframe
results <- results[order(-abs(results$logFC)), ]

#############Permanova - are the controls CreTam and Tam significantly different
#install.packages("vegan")
library(vegan)

# lipid_matrix = samples as rows, lipids as columns (controls only)
# metadata = dataframe with your group labels

met_matrix <- read.csv("Output/combined metabolomics_wide II.csv", check.names = F, row.names = 1)
sample_info <- read.csv("Input/Metabolomics metadata.csv", check.names = F) #metadata

met_matrix <- met_matrix %>%
  filter(Genotype %in% c("Cre+Tam", "Tam"))

sample_info <- sample_info %>%
  filter(Genotype %in% c("Cre+Tam", "Tam"))

m <- met_matrix %>%
  filter(Sex %in% c("M"))
m<- m[-c(2:3)]
m_md <- sample_info %>%
  filter(Sex %in% c("M"))
m_numeric <- m %>%
  column_to_rownames("Sample") %>%
  select(where(is.numeric))

adonis2(m_numeric ~ Genotype, data = m_md, permutations = 999, method = "euclidean")

# ------------result ------------------
#Permutation test for adonis under reduced model
#Permutation: free
#Number of permutations: 999

#adonis2(formula = m_numeric ~ Genotype, data = m_md, permutations = 999, method = "euclidean")
#Df SumOfSqs      R2      F Pr(>F)  
#Model     1   222.26 0.21641 2.2094  0.067 .
#Residual  8   804.76 0.78359                
#Total     9  1027.02 1.00000                
#---
#  Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
#conclusion: despite limma showing only two metabolites that are sig different, permanova says that genotype accounts for 22% of the total variance between groups, quite substantial. verdict is to not pool

f <- met_matrix %>%
  filter(Sex %in% c("F"))
f<- f[-c(2:3)]
f_md <- sample_info %>%
  filter(Sex %in% c("F"))
f_numeric <- f %>%
  column_to_rownames("Sample") %>%
  select(where(is.numeric))
adonis2(f_numeric ~ Genotype, data = f_md, permutations = 999, method = "euclidean")
# ----------result---------------------
#Permutation test for adonis under reduced model
#Permutation: free
#Number of permutations: 999

#adonis2(formula = f_numeric ~ Genotype, data = f_md, permutations = 999, method = "euclidean")
#Df SumOfSqs     R2      F Pr(>F)   
#Model     1   416.00 0.3295 4.4228   0.01 **
#  Residual  9   846.53 0.6705                 
#Total    10  1262.53 1.0000                 
#---
#  Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1
#conclusion: the test is a bit clearer here, telling us that there are Genotype accounts for a sig difference between controls (33% of variance.)
#####################
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeKO - SexF_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
write.csv(results, "Output/Limma female metbalomics_KOvCreTam.csv", row.names = F)

results <- results %>% filter(adj.P.Val < 0.05)
#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Sig hits_Limma female metbalomics_KOvCreTam.csv", row.names = F)

##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexM_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
write.csv(results, "Output/Limma male metbalomics_KOvCreTam.csv", row.names = F)

results <- results %>% filter(adj.P.Val < 0.05)
#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Sig hits_Limma male metbalomics_KOvCreTam.csv", row.names = F)

#####################################################################################################
######################################## Volcano Plot ###############################################
#####################################################################################################
f1 <- read.csv("Output/Limma HILIC NEG_F KOvCreTam.csv", check.names = F)
f2 <- read.csv("Output/Limma HILIC POS_F KOvCreTam.csv", check.names = F)
f3 <- read.csv("Output/Limma IROA NEG_F KOvCreTam.csv", check.names = F)
f4 <- read.csv("Output/Limma IROA POS_F KOvCreTam.csv", check.names = F)

female <- rbind(f1, f2, f3, f4)
write.csv(female, "Output/Combined Limma_F.csv", row.names = F)


# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

#convert log average expression to linear scale
female$meanexpression <- 2^female$AveExpr

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(female$logFC), max(female$logFC))))

#label dots with biggest positive FC
label_point <- female %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 

label_point4 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(desc(AveExpr)) %>%
  slice_head(n = 10)

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, label_point4)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(female, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 3) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = "Female KO/Ctrl") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5),
        text = element_text(size = 12)) +
  #scale_size_continuous(range = c(1,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,15)) +
  xlim(c(-3,3)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 3-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -3-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot
ggsave(filename="Female KO v CreTam.pdf",width=5,height=5,units="in")
ggsave(filename="Female KO v CreTam.svg",width=5,height=5,units="in")

#################### Male
m1 <- read.csv("Output/Limma HILIC NEG_M KOvCreTam.csv", check.names = F)
m2 <- read.csv("Output/Limma HILIC POS_M KOvCreTam.csv", check.names = F)
m3 <- read.csv("Output/Limma IROA NEG_M KOvCreTam.csv", check.names = F)
m4 <- read.csv("Output/Limma IROA POS_M KOvCreTam.csv", check.names = F)

male <- rbind(m1, m2, m3, m4)
write.csv(male, "Output/Combined Limma_M.csv", row.names = F)

# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05


# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(male$logFC), max(male$logFC))))

#label dots with biggest positive FC
label_point <- male %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 

label_point4 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(desc(AveExpr)) %>%
  slice_head(n = 10)

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, label_point4)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(male, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 3) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = "Male KO/Ctrl") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5),
        text = element_text(size = 12)) +
  #scale_size_continuous(range = c(1,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,15)) +
  xlim(c(-3,3)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 2-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -2-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot
ggsave(filename="Male KO v CreTam.pdf",width=5,height=5,units="in")
ggsave(filename="Male KO v CreTam.svg",width=5,height=5,units="in")

############################################################################################
##################################### PCA plot #############################################
############################################################################################
#PCA plot

#Loading required packages
library(cluster)
library(factoextra)
library(RColorBrewer)

#Loading metabolomics dataset
m1 <- read.csv("Output/Log HILIC NEGATIVE.csv", check.names = F, row.names = 1)
m2 <- read.csv("Output/Log HILIC POSITIVE.csv", check.names = F, row.names = 1)
m3 <- read.csv("Output/Log IROA NEGATIVE.csv", check.names = F, row.names = 1)
m4 <- read.csv("Output/Log IROA POSITIVE.csv", check.names = F, row.names = 1)

met <- rbind(m1, m2, m3, m4)

#clean up column lipid names
colnames(met) <- sub("_.*", "", colnames(met))

# Extract the first column as column names
col_met <- met[, 1]

# Transpose the dataframe and set column names
transform_met <- t(met[,-1])
colnames(transform_met) <- col_met


# Converting matrix to data frame
transform_met <- as.data.frame(transform_met)

#Loading labelling key
lab <- read.csv("Input/Labeling key I.csv", check.names = F)
#lab2 <- read.csv("Input/Labeling key II.csv", check.names = F)
#lab3 <- read.csv("Input/Labelling key III.csv", check.names = F)
#merge labelling key to lipidomics data
transform_met$Sample <- rownames(transform_met)

# Then, merge by "Sample"
transform_met <- merge(lab, transform_met, by = "Sample")


#reorder dataframes
transform_met <- transform_met[order(transform_met$Sex, transform_met$Genotype), ]

write.csv(transform_met, "Output/Combined metabolomics_wide.csv")


df1 <- transform_met


######################Plotting PCA##################################
pca_plot <- prcomp(df1[,-(1:3)], scale. = TRUE)

# Define your custom colors for each Genotype
genotype_colors <- c(
  "KO" = "#DC5E0B",
  "Cre" = "#7F733E",
  "Tam" = "#8E6885",
  "Cre+Tam" = "#B5A6B0",
  "HET" = "#F1B6A1",
  "VC" = "#5E2750")

# Plot with manual color and shape mapping
autoplot(pca_plot, data = df1, colour = 'Genotype', shape = 'Sex', size = 3) +
  theme_bw() +
  scale_colour_manual(values = genotype_colors) +
  scale_shape_manual(values = c("F" = 16, "M" = 17, "QC" = 15)) +  
  ggtitle("Heart Metabolomics") +
  guides(colour = guide_legend(title = "Genotype"),
         shape = guide_legend(title = "Sex"))

# Save plot
ggsave(filename = "Heart Metabolomics PCA.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Metabolomics PCA.svg",width=5.98,height=4.36,units="in")

############################################################################
############################################################################
######################## PLS-DA ############################################
# Install and load required packages
#BiocManager::install("mixOmics")
library(mixOmics)

df2 <- read.csv("Output/Combined metabolomics_wide.csv", check.names = F, row.names = 1)

X <- df2[, 4:2537]  # predictors
Y <- as.factor(df2[, 3])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Compound = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
write.csv(vip_filtered, "Output/PLSDA VIP_Genotype response variable.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Metabolomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 15%` = scores[, 1],`X-Variate2: 21.5%` = scores[, 2],Group = Y, check.names = F) #Corn oil injected mice
df_scores$Sex <- df2$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 15%`, y = `X-Variate2: 21.5%`, color = Group)) +
  geom_point(aes(shape = df2$Sex), size = 3, alpha = 0.9) +  # Shape mapped here only
  stat_ellipse(type = "norm", linewidth = 0.5) +             # Ellipses by Group only
  scale_color_manual(values = c("khaki3", "thistle", "#b57c76", "#5D94A5","#B5A6B0", "#854a77")) +
  scale_shape_manual(values = c("F" = 16, "M" = 17)) +
  theme_bw() +
  theme(legend.title = element_text(size = 12)) +
  labs(title = "Heart Metabolomics PLS-DA", shape = "Sex")

# Save plot
ggsave(filename = "Heart Metabolomics PLSDA_Genotype.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Metabolomics PLSDA_Genotype.svg",width=5.98,height=4.36,units="in")

#########################################################################################
#########################################################################################
#########################################################################################
################################## UpSet Plot############################################
library(tidyverse)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(gridtext)
#install.packages("ComplexUpset")
library(ComplexUpset)

#import limma stat sheets
male <- read.csv("Output/Combined Limma_M.csv")
female <- read.csv("Output/Combined Limma_F.csv")

male <- male %>% group_by(Compound) %>% filter(adj.P.Val == min(adj.P.Val)) %>% ungroup()
female <- female %>% group_by(Compound) %>% filter(adj.P.Val == min(adj.P.Val)) %>% ungroup()


# Add "_F" to all column names except the first one
colnames(female)[2:ncol(female)] <- paste0(colnames(female)[2:ncol(female)], "_F")

# Add "_M" to all column names except the first one
colnames(male)[2:ncol(male)] <- paste0(colnames(male)[2:ncol(male)], "_M")

#merge male and female sheets
comb <- merge(male, female, by = "Compound")


# For each comparison, added a column to label the significance as TRUE or FALSE. 
comb$"KO v Tam (M)" <- ifelse(comb$adj.P.Val_M <0.05, "TRUE", "FALSE")
comb$"KO v Tam (F)" <- ifelse(comb$adj.P.Val_F <0.05, "TRUE", "FALSE")

# call out the intersected proteins
intersect <- comb %>%
  filter(comb$"KO v Tam (M)" == "TRUE",comb$"KO v Tam (F)" == "TRUE")

#write.csv(intersect, "Output/Intersected Lipids M and F_KO v Tam.CSV")

# For each comparison, added a column to label the directions of change as Up, Down, or NS.

comb$M_direct <- ifelse(!comb$adj.P.Val_M <0.05, 
                        "NS",
                        ifelse(comb$logFC_M >0,
                               "Up", "Down"))
comb$F_direct <- ifelse(!comb$adj.P.Val_F <0.05, 
                        "NS",
                        ifelse(comb$logFC_F >0,
                               "Up", "Down"))

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"

comb$Intersect_direction <- ifelse(rowSums(comb[, c(16:17)] =="Down", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), 
                                   "Down", 
                                   ifelse(rowSums(comb[, c(16:17)] =="Up", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), "Up", "Different direction"))

comb$Intersect_direction <- factor(comb$Intersect_direction, 
                                   levels = c("Up","Down"))

# Plot UpSet

KOvTam <- colnames(comb)[14:15]

upset(comb, KOvTam, name = '', width_ratio = 0.7,
      height_ratio = 0.7, min_size = 1, min_degree = 1,
      
      base_annotations = list(
        'Intersection size' = (
          intersection_size(mapping = aes(fill = Intersect_direction))
          + scale_fill_manual(values = c("indianred3", "skyblue2"))
          + theme(
            axis.title.y = element_text(margin = margin(r = -10), size = 14),
            text = element_text(size = 14),
            legend.title = element_blank(),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank()
          )
        )
      ),
      
      # Trick: set bar height to 0 by scaling y-axis to 0 range
      set_sizes = (
        upset_set_size()
        + scale_y_continuous(limits = c(0, 0))  # Shrinks bars to invisible
        + theme_void()
      ),
      
      stripes = c("white")
) + 
  theme(
    panel.grid = element_blank(),
    text = element_text(size = 14)
  ) +
  patchwork::plot_layout(heights = c(1, 0.5, 1))

ggsave(filename="Male v Female UpSets.png",width=6.14,height=4.21,units="in",dpi=600)
ggsave(filename="Male v Female UpSets.pdf",width=6.14,height=4.21,units="in")
ggsave(filename="Male v Female UpSets.svg",width=6.14,height=4.21,units="in")


#################LIMMA #########################################################
library(limma)

#exprs <- read.csv("Output/Log HILIC POSITIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
#exprs <- read.csv("Output/Log HILIC NEGATIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
#exprs <- read.csv("Output/Log IROA POSITIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
exprs <- read.csv("Output/Log IROA NEGATIVE_cleaned.csv", check.names = F, row.names = 1) #expression data
sample_info <- read.csv("Input/Metabolomics metadata.csv", check.names = F) #metadata

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeWT = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "WT"),
  SexF_GenotypeCre = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre"),
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeCreTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre+Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeWT = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "WT"),
  SexM_GenotypeCre = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeCreTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre+Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:7)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeCreTam - SexF_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
write.csv(results, "Output/Limma IROA NEG_M v F CreTam.csv", row.names = F)

#####################################################################################################
######################################## Volcano Plot ###############################################
#####################################################################################################
df1 <- read.csv("Output/Limma HILIC NEG_M v F CreTam.csv", check.names = F)
df2 <- read.csv("Output/Limma HILIC POS_M v F CreTam.csv", check.names = F)
df3 <- read.csv("Output/Limma IROA NEG_M v F CreTam.csv", check.names = F)
df4 <- read.csv("Output/Limma IROA POS_M v F CreTam.csv", check.names = F)

df <- rbind(df1, df2, df3, df4)
#write.csv(female, "Output/Combined Limma_F.csv", row.names = F)


# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05


# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(df$logFC), max(df$logFC))))

#label dots with biggest positive FC
label_point <- df %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 

label_point4 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(desc(AveExpr)) %>%
  slice_head(n = 10)

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, label_point4)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(df, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 3) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = "Male v Female") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5),
        text = element_text(size = 12)) +
  #scale_size_continuous(range = c(1,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,15)) +
  xlim(c(-5,5)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 5-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Compound),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -3-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot
ggsave(filename="Male v Female CreTam.pdf",width=5,height=5,units="in")
ggsave(filename="Male v Female CreTam.svg",width=5,height=5,units="in")

#####################################################################################################
#####################################################################################################
#####################################################################################################
library(ggh4x)
#import limma datasets
female <- read.csv("Output/Limma female metbalomics_KOvCreTam.csv")
male <- read.csv("Output/Limma male metbalomics_KOvCreTam.csv")
met_class <- read_excel("Input/Metabolite classification.xlsx")

#remove NA rows
met_class <- met_class %>% filter(!is.na(Class))

#replace FA with FFA
met_class <- met_class %>%
  mutate(across(where(is.character), ~ str_replace_all(., "\\bFA\\b", "FFA")))

#merge class with stats sheet
fem <- merge(met_class, female, by = "Metabolite")
mal <- merge(met_class, male, by = "Metabolite")

#sort unique lipids
fem <- fem[!duplicated(fem$Metabolite), ]
mal <- mal[!duplicated(mal$Metabolite), ]

#plot data
fem$color_group <- ifelse(fem$P.Value > 0.05, "ns", "sig")
ggplot(fem, aes(x = Class, y = logFC, size = AveExpr)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey", linewidth = 0.5) +
  geom_point(data = subset(fem, P.Value > 0.05), shape = 21, fill = "grey", color = "black", alpha = 0.5) +
  geom_point(data = subset(fem, P.Value <= 0.05), aes(fill = P.Value), shape = 21, color = "black", alpha = 0.9) +
  scale_fill_gradientn(colors = c("maroon4", "hotpink1"), name = "P-Value") +
  scale_x_discrete(labels = function(x) gsub("-", "\n", x)) +
  labs(title = " ", x = " ", y = expression(Log[2]*"FC (female KO/CreTam)"), size = "AveExpr") +
  guides(y = guide_axis_minor(), fill = "none", size = "none") +
  geom_text_repel(
    data = subset(fem, P.Value <= 0.05),
    aes(label = Metabolite),
    size = 3.5,
    color = "black",
    box.padding = 0.4,
    point.padding = 0.3,
    segment.color = "black",
    segment.size = 0.25,
    min.segment.length = 0,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  theme_minimal(base_size = 15) +
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5),
        plot.title = element_text(hjust = 0.5, face = "bold"),
        panel.grid = element_blank(),
        axis.line = element_line(color = "black", linewidth = 0.3),
        axis.ticks = element_line(color = "black", linewidth = 0.1),
        axis.minor.ticks.length = unit(0.1, "cm"),
        axis.ticks.length = unit(0.2, "cm"))

ggsave(filename = "Heart metabolomics class female plot.pdf", width = 4.5, height = 4.36, units = "in")
ggsave(filename="Heart metabolomics class female plot.svg",width=4.5,height=4.36,units="in")

#######male
mal$color_group <- ifelse(mal$P.Value > 0.05, "ns", "sig")

ggplot(mal, aes(x = Class, y = logFC, size = AveExpr)) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey", linewidth = 0.5) +
  geom_point(data = subset(mal, P.Value > 0.05), shape = 21, fill = "grey", color = "black", alpha = 0.5) +
  geom_point(data = subset(mal, P.Value <= 0.05), aes(fill = P.Value), shape = 21, color = "black", alpha = 0.9) +
  scale_fill_gradientn(colors = c("maroon4", "hotpink1"), name = "P-Value") +
  scale_x_discrete(labels = function(x) gsub("-", "\n", x)) +
  labs(title = " ", x = " ", y = expression(Log[2]*"FC (male KO/CreTam)"), size = "AveExpr") +
  guides(y = guide_axis_minor(), fill = "none", size = "none") +
  geom_text_repel(
    data = subset(mal, P.Value <= 0.05),
    aes(label = Metabolite),
    size = 3.5,
    color = "black",
    box.padding = 0.4,
    point.padding = 0.3,
    segment.color = "black",
    segment.size = 0.25,
    min.segment.length = 0,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  theme_minimal(base_size = 15) +
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5),
        plot.title = element_text(hjust = 0.5, face = "bold"),
        panel.grid = element_blank(),
        axis.line = element_line(color = "black", linewidth = 0.3),
        axis.ticks = element_line(color = "black", linewidth = 0.1),
        axis.minor.ticks.length = unit(0.1, "cm"),
        axis.ticks.length = unit(0.2, "cm"))


ggsave(filename = "Heart metabolomics class male plot.pdf", width = 4.5, height = 4.36, units = "in")
ggsave(filename="Heart metabolomics class male plot.svg",width=4.5,height=4.36,units="in")

#####################################################################################################
#####################################################################################################
#####################################################################################################
#import datasets
met <- read.csv("Output/Log2 Combined Metabolomics.csv", check.names = F, row.names = 1)
met_class <- read_excel("Input/Metabolite classification.xlsx")

#remove NA rows
met_class <- met_class %>% filter(!is.na(Class))

#merge class with metabolomics sheet
met <- merge(met_class, met, by = "Metabolite")

#sort unique lipids
met <- met[!duplicated(met$Metabolite), ]

#sum up metabolite classes
met_summed <- met %>%
  group_by(Class) %>%
  summarise(across(where(is.numeric), ~ sum(2^., na.rm = TRUE)))

#calculate metabolite ratios
ratio_rows <- bind_rows(
  met_summed %>%
    summarise(Class = "Carnitine/Acyl-Carnitine",
              across(where(is.numeric), ~ .[met_summed$Class == "Carnitine"] / 
                       .[met_summed$Class == "Acyl-Carnitine"])),
  met %>%
    summarise(Class = "Acetyl-CoA/CoA",
              across(where(is.numeric), ~ 2^(.[met$Metabolite == "Acetyl-CoA"] - 
                                               .[met$Metabolite == "COENZYME A"]))),
  met_summed %>%
    summarise(Class = "Acyl-CoA/CoA",
              across(where(is.numeric), ~ .[met_summed$Class == "Acyl-CoA"] / 
                       .[met_summed$Class == "CoA"]))
)

met_summed <- bind_rows(met_summed, ratio_rows)

write.csv(met_summed,"Output/Calculated Metabolite ratios.csv")






