#install_github("jokergoo/ComplexHeatmap")
library(ComplexHeatmap)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
#BiocManager::install("clusterProfiler")
library(clusterProfiler)
library(ggplot2)
library(tidyr)
library(ggrepel)
library(ggfortify)
library(ggforce)
library(extrafont)
extrafont::loadfonts()
#install.packages("cluster")
library(cluster)
library(factoextra)
library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
library(writexl)
library(Cairo)
#install.packages("Cairo")

#import unnormalized input files
unom_pos<- read.csv('Input/Unnormalized Peak Intensity_POS.csv', check.names = F)
unom_neg <- read.csv('Input/Unnormalized Peak Intensity_NEG.csv', check.names = F)


#filter unom_pos relevant lipid classes for normalization
unom_pos_tg <- unom_pos %>%
  filter(grepl("TG", Name))

unom_pos_ce <- unom_pos %>%
  filter(grepl("CE", Name))

unom_pos_cer <- unom_pos %>%
  filter(grepl("Cer", Name))

unom_pos_dg <- unom_pos %>%
  filter(grepl("DG", Name))

unom_pos_lpc <- unom_pos %>%
  filter(grepl("LPC", Name))

unom_pos_lpe <- unom_pos %>%
  filter(grepl("LPE", Name))

unom_pos_pc <- unom_pos %>%
  filter(grepl("PC", Name))
unom_pos_pc <- unom_pos_pc %>%
  filter(!grepl("LPC", Name))

unom_pos_pe <- unom_pos %>%
  filter(grepl("PE", Name))
unom_pos_pe <- unom_pos_pe %>%
  filter(!grepl("LPE", Name))

unom_pos_pg <- unom_pos %>%
  filter(grepl("PG", Name))
unom_pos_pg <- unom_pos_pg %>%
  filter(!grepl("LPG", Name))

unom_pos_sm <- unom_pos %>%
  filter(grepl("SM", Name))

#filter unom_neg relevant lipid classes for normalization
unom_neg_cer <- unom_neg %>%
  filter(grepl("Cer", Name))

unom_neg_lpe <- unom_neg %>%
  filter(grepl("LPE", Name))

unom_neg_pc <- unom_neg %>%
  filter(grepl("PC", Name))
unom_neg_pc <- unom_neg_pc %>%
  filter(!grepl("LPC", Name))

unom_neg_pe <- unom_neg %>%
  filter(grepl("PE", Name))
unom_neg_pe <- unom_neg_pe %>%
  filter(!grepl("LPE",Name))
unom_neg_pe <- unom_neg_pe %>%
  filter(!grepl("LNAPE",Name))

unom_neg_pg <- unom_neg %>%
  filter(grepl("PG", Name))

unom_neg_pi <- unom_neg %>%
  filter(grepl("PI", Name))

#Perform internal std normalization NEG mode
nom_neg_cer <- unom_neg_cer %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_neg_cer[grepl("Std", unom_neg_cer$Name), cur_column()]
  ))
nom_neg_cer <- nom_neg_cer %>%
  filter(!grepl("Std", Name))


nom_neg_lpe <- unom_neg_lpe %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_neg_lpe[grepl("Std", unom_neg_lpe$Name), cur_column()]
  ))
nom_neg_lpe <- nom_neg_lpe %>%
  filter(!grepl("Std", Name))


#nom_neg_pc <- unom_neg_pc %>%
#  mutate(across(
#    -c(1:5),
#    ~ . / unom_neg_pc[grepl("Std", unom_neg_pc$Name), cur_column()]
#  ))
#nom_neg_pc <- nom_neg_pc %>%
#  filter(!grepl("Std", Name))


nom_neg_pe <- unom_neg_pe %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_neg_pe[grepl("Std", unom_neg_pe$Name), cur_column()]
  ))
nom_neg_pe <- nom_neg_pe %>%
  filter(!grepl("Std", Name))


nom_neg_pg <- unom_neg_pg %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_neg_pg[grepl("Std", unom_neg_pg$Name), cur_column()]
  ))
nom_neg_pg <- nom_neg_pg %>%
  filter(!grepl("Std", Name))


nom_neg_pi <- unom_neg_pi %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_neg_pi[grepl("Std", unom_neg_pi$Name), cur_column()]
  ))
nom_neg_pi <- nom_neg_pi %>%
  filter(!grepl("Std", Name))

#row bind normalized data
nom_neg <- bind_rows(nom_neg_cer, nom_neg_lpe, nom_neg_pe, nom_neg_pg, nom_neg_pi)
write.csv(nom_neg, "Output/IS normalized peak intensity_NEG.csv")

#Perform internal std normalization POS mode
nom_pos_ce <- unom_pos_ce %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_ce[grepl("Std", unom_pos_ce$Name), cur_column()]
  ))
nom_pos_ce <- nom_pos_ce %>%
  filter(!grepl("Std", Name))


nom_pos_cer <- unom_pos_cer %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_cer[grepl("Std", unom_pos_cer$Name), cur_column()]
  ))
nom_pos_cer <- nom_pos_cer %>%
  filter(!grepl("Std", Name))


nom_pos_dg <- unom_pos_dg %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_dg[grepl("Std", unom_pos_dg$Name), cur_column()]
  ))
nom_pos_dg <- nom_pos_dg %>%
  filter(!grepl("Std", Name))


nom_pos_lpc <- unom_pos_lpc %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_lpc[grepl("Std", unom_pos_lpc$Name), cur_column()]
  ))
nom_pos_lpc <- nom_pos_lpc %>%
  filter(!grepl("Std", Name))


nom_pos_lpe <- unom_pos_lpe %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_lpe[grepl("Std", unom_pos_lpe$Name), cur_column()]
  ))
nom_pos_lpe <- nom_pos_lpe %>%
  filter(!grepl("Std", Name))


nom_pos_pc <- unom_pos_pc %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_pc[grepl("Std", unom_pos_pc$Name), cur_column()]
  ))
nom_pos_pc <- nom_pos_pc %>%
  filter(!grepl("Std", Name))


nom_pos_pe <- unom_pos_pe %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_pe[grepl("Std", unom_pos_pe$Name), cur_column()]
  ))
nom_pos_pe <- nom_pos_pe %>%
  filter(!grepl("Std", Name))


nom_pos_pg <- unom_pos_pg %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_pg[grepl("Std", unom_pos_pg$Name), cur_column()]
  ))
nom_pos_pg <- nom_pos_pg %>%
  filter(!grepl("Std", Name))


nom_pos_sm <- unom_pos_sm %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_sm[grepl("Std", unom_pos_sm$Name), cur_column()]
  ))
nom_pos_sm <- nom_pos_sm %>%
  filter(!grepl("Std", Name))


nom_pos_tg <- unom_pos_tg %>%
  mutate(across(
    -c(1:5),
    ~ . / unom_pos_tg[grepl("Std", unom_pos_tg$Name), cur_column()]
  ))
nom_pos_tg <- nom_pos_tg %>%
  filter(!grepl("Std", Name))

#row bind normalized data
nom_pos <- bind_rows(nom_pos_ce, nom_pos_cer, nom_pos_dg, nom_pos_lpc, nom_pos_lpe, nom_pos_pc, nom_pos_pe, nom_pos_pg, nom_pos_sm, nom_pos_tg)
write.csv(nom_pos, "Output/IS normalized peak intensity_POS.csv")


#import corrected IS normalized input files
nom_pos<- read.csv('Input/IS normalized peak intensity_POS.csv', check.names = F, row.names = 1)
nom_neg <- read.csv('Input/IS normalized peak intensity_NEG.csv', check.names = F, row.names = 1)
 
#clean up the column names to remove ionization modes.
colnames(nom_neg) <- gsub("_N", "", colnames(nom_neg))
colnames(nom_neg) <- gsub("_P", "", colnames(nom_neg)) #made a mistake in the file naming and sample 1254999 was given a "P" instead of an "N"

colnames(nom_pos) <- gsub("_P", "", colnames(nom_pos))

nom_lipidomics <- bind_rows (nom_pos, nom_neg)
nom_lipidomics2 <- nom_lipidomics[-c(1:3, 5)]

# Identify QC columns (adjust pattern to match your column names)
qc_cols <- grep("QC", colnames(nom_lipidomics2), value = TRUE)

# For duplicated names, keep the row with lowest SD across QCs
nom_lipidomics2 <- nom_lipidomics2 %>%
  mutate(sd_qc = apply(across(all_of(qc_cols)), 1, sd, na.rm = TRUE)) %>%
  group_by(Name) %>%
  slice_min(sd_qc, n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  select(-sd_qc)

#Find the average across Blank columns
nom_lipidomics2 <- nom_lipidomics2 %>%
  rowwise() %>%
  mutate(BLANK = mean(c_across(contains("BLK")), na.rm = TRUE)) %>%
  ungroup()

#remove rows where the abundance in the highest column is not 5x more than levels in blank
nom_lipidomics3 <- nom_lipidomics2  %>%
  rowwise() %>%
  filter(max(c_across(2:97)) >= 5 * `BLANK`) %>%
  ungroup()

#remove BLK samples
nom_lipidomics3 <- nom_lipidomics3 %>%
  select(!contains("BLK"))

nom_lipidomics3 <- nom_lipidomics3 %>%
  select(!contains("BLANK"))

write.csv(nom_lipidomics3, "Output/IS normalized Lipidomics.csv")

#import TIC normalized input files
TIC_pos<- read.csv('Input/TIC Normalized Heart Lipidomics Peak Intensity_POS.csv', check.names = F)
TIC_neg <- read.csv('Input/TIC Normalized Heart Lipidomics Peak Intensity_NEG.csv', check.names = F)

#clean up the column names to remove ionization modes
colnames(TIC_neg) <- gsub("_N", "", colnames(TIC_neg))
colnames(TIC_neg) <- gsub("_P", "", colnames(TIC_neg)) #made a mistake in the file naming and sample 1254999 was given a "P" instead of an "N"

colnames(TIC_pos) <- gsub("_P", "", colnames(TIC_pos))

TIC_lipidomics <- bind_rows (TIC_pos, TIC_neg)
TIC_lipidomics2 <- TIC_lipidomics[-c(1:3, 5)]

#sum up duplicate lipids
TIC_lipidomics2 <- TIC_lipidomics2 %>%
  group_by(Name) %>%
  summarise(across(everything(), ~ if(is.numeric(.)) sum(., na.rm = TRUE) else first(.)))

#Find the average across Blank columns
TIC_lipidomics2  <- TIC_lipidomics2  %>%
  rowwise() %>%
  mutate(BLANK = mean(c_across(contains("BLK")), na.rm = TRUE)) %>%
  ungroup()

#remove rows where the abundance in the highest column is not 5x more than levels in blank
TIC_lipidomics3 <- TIC_lipidomics2   %>%
  rowwise() %>%
  filter(max(c_across(2:97)) >= 5 * `BLANK`) %>%
  ungroup()

#remove BLK samples
TIC_lipidomics3 <- TIC_lipidomics3 %>%
  select(!contains("BLK"))

TIC_lipidomics3 <- TIC_lipidomics3 %>%
  select(!contains("BLANK"))

write.csv(TIC_lipidomics3, "Output/TIC normalized lipidomics.csv")

#convert unormalized data to log2
log_TIC <- TIC_lipidomics3 %>%
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
write.csv(log_TIC, "Output/log2 TIC normalized lipidomics.csv")

############################################################################################
#PCA plot

#Loading required packages
library(cluster)
library(factoextra)
library(RColorBrewer)

#Loading normalized lipidomics dataset
lipid <- read.csv("Output/IS normalized Lipidomics.csv", check.names = F)
lipid <- lipid[-c(1)]

#clean up column lipid names
colnames(lipid) <- sub("_.*", "", colnames(lipid))

# Extract the first column as column names
col_lipid <- lipid[, 1]

# Transpose the dataframe and set column names
transform_lipid <- t(lipid[,-1])
colnames(transform_lipid) <- col_lipid


# Converting matrix to data frame
transform_lipid <- as.data.frame(transform_lipid)

#Loading labelling key
lab <- read.csv("Input/Labeling key I.csv", check.names = F)
lab2 <- read.csv("Input/Labeling key II.csv", check.names = F)
#lab3 <- read.csv("Input/Labelling key III.csv", check.names = F)
#merge labelling key to lipidomics data
transform_lipid$Sample <- rownames(transform_lipid)

# Then, merge by "Sample"
transform_lipid1 <- merge(lab, transform_lipid, by = "Sample")
transform_lipid2 <- merge(lab2, transform_lipid, by = "Sample")

#reorder dataframes
transform_lipid1 <- transform_lipid1[order(transform_lipid1$Sex, transform_lipid1$Genotype), ]
transform_lipid2 <- transform_lipid2[order(transform_lipid2$Sex, transform_lipid2$Genotype), ]

write.csv(transform_lipid1, "Output/IS Normalized lipidomics_wide I.csv")
write.csv(transform_lipid2, "Output/IS Normalized lipidomics_wide II.csv")

df1 <- transform_lipid1
df2 <- transform_lipid2

#############################
#Loading unnormalized lipidomics dataset
#unlipid <- read.csv("Output/Unnormalized lipidomics.csv", check.names = F)
#unlipid <- unom_lipidomics2

#remove BLK samples
#unlipid <- unlipid %>%
#  select(!contains("BLK"))

#clean up column lipid names
#colnames(unlipid) <- sub("_.*", "", colnames(unlipid))

# Extract the first column as column names
#col_unlipid <- unlipid[, 1]

# Transpose the dataframe and set column names
#transform_unlipid <- t(unlipid[,-1])
#colnames(transform_unlipid) <- col_unlipid


# Converting matrix to data frame
#transform_unlipid <- as.data.frame(transform_unlipid)

#Loading labelling key
#lab <- read.csv("Input/Labeling key I.csv", check.names = F)
#lab2 <- read.csv("Input/Labeling key II.csv", check.names = F)

#merge labelling key to lipidomics data
#transform_unlipid$Sample <- rownames(transform_unlipid)

# Then, merge by "Sample"
#transform_unlipid1 <- merge(lab, transform_unlipid, by = "Sample")
#transform_unlipid2 <- merge(lab2, transform_unlipid, by = "Sample")

#reorder dataframes
#transform_unlipid1 <- transform_unlipid1[order(transform_unlipid1$Sex, transform_unlipid1$Genotype), ]
#transform_unlipid2 <- transform_unlipid2[order(transform_unlipid2$Sex, transform_unlipid2$Genotype), ]

#write.csv(transform_unlipid1, "Output/Unnormalized lipidomics_wide I.csv")
#write.csv(transform_unlipid2, "Output/Unnormalized lipidomics_wide II.csv")

#df3 <- transform_unlipid1
#df4 <- transform_unlipid2

######################Plotting PCA##################################
df1 <- transform_lipid1
df1 <- df1 %>%
  filter(Genotype %in% c("Cre+Tam", "Tam", "KO"))
df1 <- df1 %>%
  filter(Sex %in% c("M"))
pca_plot <- prcomp(df1[,-(1:3)], scale. = TRUE)

# Define your custom colors for each Genotype
genotype_colors <- c(
  "KO" = "#DC5E0B",
  "Cre" = "#7F733E",
  "Tam" = "#8E6885",
  "Cre+Tam" = "#B5A6B0",
  "HET" = "#F1B6A1",
  "VC" = "#5E2750",
  "QC" = "#69A88A")

# Plot with manual color and shape mapping
autoplot(pca_plot, data = df1, colour = 'Genotype', shape = 'Sex', size = 3) +
  theme_bw() +
  scale_colour_manual(values = genotype_colors) +
  scale_shape_manual(values = c("F" = 16, "M" = 17, "QC" = 15)) +  
  ggtitle("Heart Lipidomics") +
  guides(colour = guide_legend(title = "Genotype"),
         shape = guide_legend(title = "Sex"))

autoplot(pca_plot, data = df1, colour = 'Genotype', shape = 'Sex', size = 3,
         frame = TRUE, frame.type = 'norm') +
  theme_bw() +
  scale_colour_manual(values = genotype_colors) +
  scale_fill_manual(values = genotype_colors) +
  scale_shape_manual(values = c("F" = 16, "M" = 17, "QC" = 15)) +
  ggtitle("Heart Lipidomics") +
  guides(colour = guide_legend(title = "Genotype"),
         shape = guide_legend(title = "Sex"))
# Save plot
ggsave(filename = "Heart Lipidomics PCA I.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Lipidomics PCA I.svg",width=5.98,height=4.36,units="in")

######################Plotting PCA II##################################
#remove columns with NAs
df2 <- df2[, colSums(is.na(df2)) == 0]

pca_plot <- prcomp(df2[,-(1:3)], scale. = TRUE)

# Define your custom colors for each Genotype
genotype_colors <- c(
  "KO" = "#5D94A5",
  "Tam" = "#B5A6B0",
  "HET" = "#b57c76",
  "VC" = "#854a77",
  "QC" = "#7F733E")

# Plot with manual color and shape mapping
autoplot(pca_plot, data = df2, colour = 'Genotype', shape = 'Sex', size = 3) +
  theme_bw() +
  scale_colour_manual(values = genotype_colors) +
  scale_shape_manual(values = c("F" = 16, "M" = 17, "QC" = 15)) +  
  ggtitle("Heart Lipidomics") +
  guides(colour = guide_legend(title = "Genotype"),
         shape = guide_legend(title = "Sex"))


# Save plot
ggsave(filename = "Heart Lipidomics PCA II.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Lipidomics PCA II.svg",width=5.98,height=4.36,units="in")

######################## PLS-DA ############################################
# Install and load required packages
BiocManager::install("mixOmics")
library(mixOmics)

df2 <- read.csv("Output/IS Normalized lipidomics_wide I.csv", check.names = F, row.names = 1)

# Remove rows where Genotype is "QC"
df2 <- df2[df2$Genotype != "QC", ]

# Remove rows where Genotype is "VC"
df2 <- df2[df2$Genotype != "VC", ]

# Remove rows where Genotype is "HET"
df2 <- df2[df2$Genotype != "HET", ]

# Remove rows where Genotype is "Cre"
df2 <- df2[df2$Genotype != "Cre", ]

# Remove rows where Genotype is "Tam"
df2 <- df2[df2$Genotype != "Tam", ]

##################################### Sex and Genotype as response variable
#combine sex and genotype columns into a single column
df2 <- df2 %>%
  mutate(Groups = paste(Sex, Genotype, sep = "_"))

#rearrange columns
df2 <- df2[c(1:3,559,4:558)]

X <- df2[, 5:559]  # predictors
Y <- as.factor(df2[, 4])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Lipid = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
write.csv(vip_filtered, "Output/PLSDA VIP_Sex and Genotype response variable.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Lipidomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 28%` = scores[, 1],`X-Variate2: 17%` = scores[, 2],Group = Y, check.names = F) 
df_scores$Sex <- df2$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 28%`, y = `X-Variate2: 17%`, color = Group)) +
  geom_point(aes(fill=Group),shape=21,size=3,alpha=0.85,stroke=0.5,color="black")+
  stat_ellipse(aes(color=Group),type="norm",linewidth=0.4)+
  scale_color_manual(values=c("black","#359099","grey50","#AA4611"))+
  scale_fill_manual(values=c("white","#359099","grey","#AA4611"))+
  theme_bw(base_size=14)+
  theme(
    legend.position="none",
    panel.grid=element_blank(),
    axis.title=element_text(size=14),
    axis.text=element_text(size=14)
  )+
  labs(title="")

# Save plot
ggsave(filename = "Heart Lipidomics PLSDA_Sex and Genotype.pdf", width = 4.3, height = 4.69, units = "in")
ggsave(filename="Heart Lipidomics PLSDA_Sex and Genotype.svg",width=4.3,height=4.69,units="in")

##################################### Genotype as response variable
df2 <- read.csv("Output/IS Normalized lipidomics_wide I.csv", check.names = F, row.names = 1)

# Remove rows where Genotype is "QC"
df2 <- df2[df2$Genotype != "QC", ]

# Remove rows where Genotype is "VC"
df2 <- df2[df2$Genotype != "VC", ]

# Remove rows where Genotype is "Tam"
df2 <- df2[df2$Genotype != "Tam", ]

# Remove rows where Genotype is "Cre"
df2 <- df2[df2$Genotype != "Cre", ]

X <- df2[, 4:558]  # predictors
Y <- as.factor(df2[, 3])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Lipid = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
write.csv(vip_filtered, "Output/PLSDA VIP_Genotype response variable.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Lipidomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 24%` = scores[, 1],`X-Variate2: 18%` = scores[, 2],Group = Y, check.names = F) #Corn oil injected mice
df_scores$Sex <- df2$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 24%`, y = `X-Variate2: 18%`, color = Group)) +
  geom_point(aes(shape = df2$Sex), size = 3, alpha = 0.9) +  # Shape mapped here only
  stat_ellipse(type = "norm", linewidth = 0.5) +             # Ellipses by Group only
  scale_color_manual(values = c("#B5A6B0","#7CD8AD", "#1C4649")) +
  scale_shape_manual(values = c("F" = 16, "M" = 17)) +
  theme_bw(base_size = 14) +  # Sets a larger base font size for the whole plot
  theme(
    axis.title = element_text(size = 14),     # Axis labels
    axis.text  = element_text(size = 14),   # Axis tick labels
    legend.title = element_text(size = 14),   # Legend title
    legend.text  = element_text(size = 14),                  # Legend items
  ) +
  labs(title = "Heart Lipidomics PLS-DA", shape = "Sex")

# Save plot
ggsave(filename = "Heart Lipidomics PLSDA_Genotype.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Lipidomics PLSDA_Genotype.svg",width=5.98,height=4.36,units="in")
#########################################################################################################################
#########################################################################################################################
#########################################################################################################################
########### HEAT MAP ################################
mf1 <- read.csv("Output/IS normalized Lipidomics.csv", row.names = 1, check.names = F)

#remove QC samples
mf1 <- mf1 %>%
  select(!contains("QC"))

# rearrange columns based on sex and genotype
mf1 <- mf1[, order(sub(".*?(\\(.*\\))", "\\1", colnames(mf1)))]

#removed sample 1187126 because it is an outlier
#finetune column order
mf1 <- mf1[c(81, 34:38, 1:4, 29:33, 5:10, 11:17, 18:27, 75:80, 39:42, 70:74, 43:47,48:69)]

write.csv(mf1, "Output/IS normalized Lipidomics II.csv")

#convert to log2
mf2<- mf1 %>% 
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
write.csv(mf2, "Output/Log IS normalized Lipidomics II.csv")

m1 <- as.matrix(mf2)
m2 <- m1 [,2:80]
rownames(m2) <- mf1$Name

#rename columns
m3 <- as.data.frame(m2) %>%
  mutate(across(1:79, as.numeric))

suffixes <- sub(".*?(\\(.*)", "\\1", colnames(m3))
group_ids <- match(suffixes, unique(suffixes))
letters <- ave(suffixes, suffixes, FUN = \(x) LETTERS[seq_along(x)])

colnames(m3) <- paste0(group_ids, letters)
write.csv(m3, "Output/Heatmap data matrix.csv")

#calculate row z-score
m3.z <- t(scale(t(m3)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
FnWT <- length(grep("^1[A-Z]$|^2[A-Z]$", colnames(m4)))
FnTam <- length(grep("3|4", colnames(m4)))
FnHet <- length(grep("5", colnames(m4)))
FnKO <- length(grep("6", colnames(m4)))
MnWT <- length(grep("7|8", colnames(m4)))
MnTam <- length(grep("9|10", colnames(m4)))
MnHet <- length(grep("11", colnames(m4)))
MnKO <- length(grep("12", colnames(m4)))


end_index_FnWT <- grep("^1[A-Z]$|^2[A-Z]$", colnames(m4)) [FnWT]
end_index_FnTam <- grep("3|4", colnames(m4)) [FnTam]
end_index_FnHet <- grep("5", colnames(m4)) [FnHet]
end_index_FnKO <- grep("6", colnames(m4)) [FnKO]
end_index_MnWT <- grep("7|8", colnames(m4)) [MnWT]
end_index_MnTam <- grep("9|10", colnames(m4)) [MnTam]
end_index_MnHet <- grep("11", colnames(m4)) [MnHet]
end_index_MnKO <- grep("12", colnames(m4)) [MnKO]


#row_order <- order(class_factor)

heatmap <- Heatmap(m4,
                   show_row_names = F,
                   show_column_names = T,
                   show_row_dend = TRUE,
                   show_column_dend = F,
                   
                   cluster_rows = TRUE,
                   #cluster_columns = T,
                   #row_order = row_order,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D2",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(col = "black", fontsize = 8),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(100, "mm"),
                   width = ncol(m4)*unit(3, "mm"),
                   
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = "Z-score",
                     title_position = "topleft",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(3, "cm")),
                   
                   split = 4, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                     
                     ind = unique(c(mat[, c(end_index_FnWT,
                                            end_index_FnTam,
                                            end_index_FnHet,
                                            end_index_FnKO,
                                            end_index_MnWT,
                                            end_index_MnTam,
                                            end_index_MnHet,
                                            end_index_MnKO
                     ) # enter the number where you want a gap between columns
                     ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
) 

draw(heatmap)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 1
grid.rect(x = (end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnWT)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("F_WT", 
          x = (end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 2
grid.rect(x = (end_index_FnTam + end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("F_Tam", 
          x = (end_index_FnTam + end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("F_Het", 
          x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("F_KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 7
grid.rect(x = (end_index_MnWT + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnWT)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("M_WT", 
          x = (end_index_MnWT + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 8
grid.rect(x = (end_index_MnTam + end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_Tam", 
          x = (end_index_MnTam + end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))


#Condition label 11
grid.rect(x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("M_Het", 
          x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 12
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("M_KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))
## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnWT/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnKO/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnWT/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
# step 4 - end by closing the saved file

pdf(file = 'Figures/IS Heart Lipidomics.pdf',
    width = 12, 
    height = 12)


CairoSVG(file = "Figures/IS Heart Lipidomics.svg", width = 12, height = 12)

#step 2 - draw heatmap in the saved file
draw(heatmap)

dev.off()
#################################################################
########################## ONLY RELEVANT GENOTYPES#################################################

#remove in
m3 <- m3[, !grepl("^1[A-Z]$|^2[A-Z]$|7|8", colnames(m3))]
#calculate row z-score
m3.z <- t(scale(t(m3)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
FnTam <- length(grep("3|4", colnames(m4)))
FnHet <- length(grep("5", colnames(m4)))
FnKO <- length(grep("6", colnames(m4)))
MnTam <- length(grep("9|10", colnames(m4)))
MnHet <- length(grep("11", colnames(m4)))
MnKO <- length(grep("12", colnames(m4)))


end_index_FnTam <- grep("3|4", colnames(m4)) [FnTam]
end_index_FnHet <- grep("5", colnames(m4)) [FnHet]
end_index_FnKO <- grep("6", colnames(m4)) [FnKO]
end_index_MnTam <- grep("9|10", colnames(m4)) [MnTam]
end_index_MnHet <- grep("11", colnames(m4)) [MnHet]
end_index_MnKO <- grep("12", colnames(m4)) [MnKO]


#row_order <- order(class_factor)

heatmap <- Heatmap(m4,
                   show_row_names = F,
                   show_column_names = F,
                   show_row_dend = TRUE,
                   show_column_dend = FALSE,
                   
                   #cluster_rows = TRUE,
                   #cluster_columns = F,
                   #row_order = row_order,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D2",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(col = "black", fontsize = 8),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(100, "mm"),
                   width = ncol(m4)*unit(3, "mm"),
                   
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = "Z-score",
                     title_position = "topleft",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(3, "cm")),
                   
                   split = 3, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                     
                     ind = unique(c(mat[, c(end_index_FnTam,
                                            end_index_FnHet,
                                            end_index_FnKO,
                                            end_index_MnTam,
                                            end_index_MnHet,
                                            end_index_MnKO
                     ) # enter the number where you want a gap between columns
                     ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
) 

draw(heatmap)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"



#Condition label 2
grid.rect(x = (end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("F_Tam", 
          x = (end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("F_Het", 
          x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("F_KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 


#Condition label 8
grid.rect(x = (end_index_MnTam + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_Tam", 
          x = (end_index_MnTam + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))


#Condition label 11
grid.rect(x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("M_Het", 
          x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 12
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("M_KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))
## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnKO/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
# step 4 - end by closing the saved file

pdf(file = 'Figures/IS Heart Lipidomics II.pdf',
    width = 12, 
    height = 12)


CairoSVG(file = "Figures/IS Heart Lipidomics II.svg", width = 12, height = 12)

#step 2 - draw heatmap in the saved file
draw(heatmap)

dev.off()

######Plot separtate heatmaps for Males and Females
female <- m3[c(1:37)]
male <- m3[c(38:79)]

#calculate row z-score
m3.z <- t(scale(t(female)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
FnWT <- length(grep("^1[A-Z]$|^2[A-Z]$", colnames(m4)))
FnTam <- length(grep("3|4", colnames(m4)))
FnHet <- length(grep("5", colnames(m4)))
FnKO <- length(grep("6", colnames(m4)))



end_index_FnWT <- grep("^1[A-Z]$|^2[A-Z]$", colnames(m4)) [FnWT]
end_index_FnTam <- grep("3|4", colnames(m4)) [FnTam]
end_index_FnHet <- grep("5", colnames(m4)) [FnHet]
end_index_FnKO <- grep("6", colnames(m4)) [FnKO]



#row_order <- order(class_factor)

heatmap_f <- Heatmap(m4,
                   show_row_names = F,
                   show_column_names = F,
                   show_row_dend = TRUE,
                   show_column_dend = FALSE,
                   
                   #cluster_rows = TRUE,
                   #cluster_columns = F,
                   #row_order = row_order,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D2",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(col = "black", fontsize = 8),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(100, "mm"),
                   width = ncol(m4)*unit(3, "mm"),
                   
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = "Z-score",
                     title_position = "topleft",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(3, "cm")),
                   
                   split = 3, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                     
                     ind = unique(c(mat[, c(end_index_FnWT,
                                            end_index_FnTam,
                                            end_index_FnHet,
                                            end_index_FnKO
                     ) # enter the number where you want a gap between columns
                     ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
) 

draw(heatmap_f)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 1
grid.rect(x = (end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnWT)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("F_WT", 
          x = (end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 2
grid.rect(x = (end_index_FnTam + end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("F_Tam", 
          x = (end_index_FnTam + end_index_FnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("F_Het", 
          x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("F_KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnWT/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

# step 4 - end by closing the saved file

pdf(file = 'Figures/Female IS Heart Lipidomics.pdf',
    width = 12, 
    height = 12)


CairoSVG(file = "Figures/Female IS Heart Lipidomics.svg", width = 12, height = 12)

#step 2 - draw heatmap in the saved file
draw(heatmap_f)

dev.off()
#####################
####################### Plot Male Heatmap
#calculate row z-score
m3.z <- t(scale(t(male)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
MnWT <- length(grep("7|8", colnames(m4)))
MnTam <- length(grep("9|10", colnames(m4)))
MnHet <- length(grep("11", colnames(m4)))
MnKO <- length(grep("12", colnames(m4)))


end_index_MnWT <- grep("7|8", colnames(m4)) [MnWT]
end_index_MnTam <- grep("9|10", colnames(m4)) [MnTam]
end_index_MnHet <- grep("11", colnames(m4)) [MnHet]
end_index_MnKO <- grep("12", colnames(m4)) [MnKO]


#row_order <- order(class_factor)

heatmap_m <- Heatmap(m4,
                   show_row_names = F,
                   show_column_names = F,
                   show_row_dend = TRUE,
                   show_column_dend = FALSE,
                   
                   #cluster_rows = TRUE,
                   #cluster_columns = F,
                   #row_order = row_order,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(col = "black", fontsize = 8),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(100, "mm"),
                   width = ncol(m4)*unit(3, "mm"),
                   
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = "Z-score",
                     title_position = "topleft",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(3, "cm")),
                   
                   split = 3, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                     
                     ind = unique(c(mat[, c(end_index_MnWT,
                                            end_index_MnTam,
                                            end_index_MnHet,
                                            end_index_MnKO
                     ) # enter the number where you want a gap between columns
                     ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
) 

draw(heatmap_m)


#step 3 - draw the labeling on the heatmap in the saved file


# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"


#Condition label 7
grid.rect(x = (end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnWT)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#854a77",
                    col = "#854a77"
          )
)
grid.text("M_WT", 
          x = (end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 8
grid.rect(x = (end_index_MnTam + end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_Tam", 
          x = (end_index_MnTam + end_index_MnWT)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))


#Condition label 11
grid.rect(x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("M_Het", 
          x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 12
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("M_KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))
## Top label gaps
#Vertical lines
grid.rect(x = end_index_MnWT/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
# step 4 - end by closing the saved file

pdf(file = 'Figures/Male IS Heart Lipidomics.pdf',
    width = 12, 
    height = 12)


CairoSVG(file = "Figures/Male IS Heart Lipidomics.svg", width = 12, height = 12)

#step 2 - draw heatmap in the saved file
draw(heatmap_m)

dev.off()

########################
######################## Heatmap of Tam control, HET and KO
######Plot separtate heatmaps for Males and Females
female2 <- female[c(10:37)]
male2 <- male[c(11:42)]

#calculate row z-score
m3.z <- t(scale(t(female2)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
FnCreTam <- length(grep("3|4", colnames(m4)))
FnHet <- length(grep("5", colnames(m4)))
FnKO <- length(grep("6", colnames(m4)))

end_index_FnCreTam <- grep("3|4", colnames(m4)) [FnCreTam]
end_index_FnHet <- grep("5", colnames(m4)) [FnHet]
end_index_FnKO <- grep("6", colnames(m4)) [FnKO]



#row_order <- order(class_factor)

heatmap_f2 <- Heatmap(m4,
                     show_row_names = F,
                     show_column_names = F,
                     show_row_dend = TRUE,
                     show_column_dend = FALSE,
                     
                     #cluster_rows = TRUE,
                     #cluster_columns = F,
                     #row_order = row_order,
                     
                     clustering_distance_rows = "euclidean",
                     clustering_method_rows = "ward.D2",
                     
                     #row_order = rownames(m4),
                     row_names_side = "left",
                     row_names_gp = gpar(col = "black", fontsize = 8),
                     
                     row_dend_side = "left",
                     row_dend_width = unit(20, "mm"),
                     
                     column_names_side = "top",
                     column_dend_side = "bottom",
                     
                     col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                     
                     
                     column_order = 1:ncol(m4),
                     
                     height = unit(100, "mm"),
                     width = ncol(m4)*unit(3, "mm"),
                     
                     
                     top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                          height = unit(6, "mm"))),
                     border_gp = gpar(col = "black"), # set border color
                     
                     show_heatmap_legend = TRUE,
                     heatmap_legend_param = list(
                       title = "Z-score",
                       title_position = "topleft",
                       at = c(-3, 0, 3), # set ticks/numbers of legend
                       legend_height = unit(3, "cm")),
                     
                     split = 3, # split the heatmap into separate blocks by hierarchical clustering
                     #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                     ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                     
                     layer_fun = function(j, i, x, y, width, height, fill) {
                       mat = restore_matrix(j, i, x, y)
                       
                       ind = unique(c(mat[, c(end_index_FnCreTam,
                                              end_index_FnHet,
                                              end_index_FnKO
                       ) # enter the number where you want a gap between columns
                       ])) 
                       
                       grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                 y = y[ind], 
                                 width = unit(0.03, "inches"), # width of the gap
                                 height = unit(1/nrow(m4), "npc"),
                                 gp = gpar(col = "white", fill = "white") # color of the gap
                       )
                     }
) 

draw(heatmap_f2)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 4
grid.rect(x = (end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnCreTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("Ctrl", 
          x = (end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))                    

#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("Het", 
          x = (end_index_FnHet + end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black")) 

## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnCreTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnKO/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

# step 4 - end by closing the saved file

pdf(file = 'Figures/Female IS Heart Lipidomics II.pdf',
    width = 10, 
    height = 10)


CairoSVG(file = "Figures/Female IS Heart Lipidomics II.svg", width = 10, height = 10)

#step 2 - draw heatmap in the saved file
draw(heatmap_f2)

dev.off()
####################### Plot Male Heatmap
#calculate row z-score
m3.z <- t(scale(t(male2)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
MnCreTam <- length(grep("9|10", colnames(m4)))
MnHet <- length(grep("11", colnames(m4)))
MnKO <- length(grep("12", colnames(m4)))

end_index_MnCreTam <- grep("9|10", colnames(m4)) [MnCreTam]
end_index_MnHet <- grep("11", colnames(m4)) [MnHet]
end_index_MnKO <- grep("12", colnames(m4)) [MnKO]


#row_order <- order(class_factor)

heatmap_m2 <- Heatmap(m4,
                     show_row_names = F,
                     show_column_names = F,
                     show_row_dend = TRUE,
                     show_column_dend = FALSE,
                     
                     #cluster_rows = TRUE,
                     #cluster_columns = F,
                     #row_order = row_order,
                     
                     clustering_distance_rows = "euclidean",
                     clustering_method_rows = "ward.D2",
                     
                     #row_order = rownames(m4),
                     row_names_side = "left",
                     row_names_gp = gpar(col = "black", fontsize = 8),
                     
                     row_dend_side = "left",
                     row_dend_width = unit(20, "mm"),
                     
                     column_names_side = "top",
                     column_dend_side = "bottom",
                     
                     col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                     
                     
                     column_order = 1:ncol(m4),
                     
                     height = unit(100, "mm"),
                     width = ncol(m4)*unit(3, "mm"),
                     
                     
                     top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                          height = unit(6, "mm"))),
                     border_gp = gpar(col = "black"), # set border color
                     
                     show_heatmap_legend = TRUE,
                     heatmap_legend_param = list(
                       title = "Z-score",
                       title_position = "topleft",
                       at = c(-3, 0, 3), # set ticks/numbers of legend
                       legend_height = unit(3, "cm")),
                     
                     split = 2, # split the heatmap into separate blocks by hierarchical clustering
                     #row_km = 3, # or split the heatmap into separate blocks by k-means clustering
                     ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                     
                     layer_fun = function(j, i, x, y, width, height, fill) {
                       mat = restore_matrix(j, i, x, y)
                       
                       ind = unique(c(mat[, c(end_index_MnCreTam,
                                              end_index_MnHet,
                                              end_index_MnKO
                       ) # enter the number where you want a gap between columns
                       ])) 
                       
                       grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                 y = y[ind], 
                                 width = unit(0.03, "inches"), # width of the gap
                                 height = unit(1/nrow(m4), "npc"),
                                 gp = gpar(col = "white", fill = "white") # color of the gap
                       )
                     }
) 

draw(heatmap_m2)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 10
grid.rect(x = (end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("Ctrl", 
          x = (end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))

#Condition label 11
grid.rect(x = (end_index_MnHet + end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("Het", 
          x = (end_index_MnHet + end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))

#Condition label 12
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))
## Top label gaps
#Vertical lines
grid.rect(x = end_index_MnCreTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
# step 4 - end by closing the saved file

pdf(file = 'Figures/Male IS Heart Lipidomics II.pdf',
    width = 10, 
    height = 10)


CairoSVG(file = "Figures/Male IS Heart Lipidomics II.svg", width = 10, height = 10)

#step 2 - draw heatmap in the saved file
draw(heatmap_m2)

dev.off()

################################################################################
################################## Statistical Test #####################################################################################################
#############Permanova - are the controls CreTam and Tam significantly different
#install.packages("vegan")
library(vegan)

# lipid_matrix = samples as rows, lipids as columns (controls only)
# metadata = dataframe with your group labels



lipid_matrix <- read.csv("Output/IS Normalized lipidomics_wide I.csv", check.names = F, row.names = 1)
sample_info <- read.csv("Input/Lipidomics metadata.csv", check.names = F) #metadata

lipid_matrix <- lipid_matrix %>%
  filter(Genotype %in% c("Cre+Tam", "Tam"))

sample_info <- sample_info %>%
  filter(Genotype %in% c("Cre+Tam", "Tam"))

m <- lipid_matrix %>%
  filter(Sex %in% c("M"))
m<- m[-c(2:3)]
m_md <- sample_info %>%
  filter(Sex %in% c("M"))
m_numeric <- m %>%
  column_to_rownames("Sample") %>%
  select(where(is.numeric))

adonis2(m_numeric ~ Genotype, data = m_md, permutations = 999, method = "euclidean")



f <- lipid_matrix %>%
  filter(Sex %in% c("F"))
f<- f[-c(2:3)]
f_md <- sample_info %>%
  filter(Sex %in% c("F"))
f_numeric <- f %>%
  column_to_rownames("Sample") %>%
  select(where(is.numeric))
adonis2(f_numeric ~ Genotype, data = f_md, permutations = 999, method = "euclidean")

################################################################################
################################################################################
BiocManager::install("limma")
library(limma)


exprs <- read.csv("Output/Log IS normalized Lipidomics II.csv", check.names = F, row.names = 1) #expression data
sample_info <- read.csv("Input/Lipidomics metadata.csv", check.names = F) #metadata

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeWT = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "WT"),
  SexF_GenotypeCre = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre"),
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeCreTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre+Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeWT = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "WT"),
  SexM_GenotypeCre = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeCreTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre+Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:7)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeTam - SexF_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_F_Tam v CreTam.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeTam - SexM_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
#results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Limma lipid results_M_Tam v CreTam.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeKO - SexF_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_F_KO.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_F_KO.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexM_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_M_KO.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_M_KO.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexF_GenotypeKO,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_Male v Female KO.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_Male v Female KO.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeCreTam - SexF_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_Male v Female CreTam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_Male v Female CreTam.csv", row.names = F)

#########################Limma with Pooled Controls ###################################################
exprs <- read.csv("Output/Log IS normalized Lipidomics II.csv", check.names = F, row.names = 1) #expression data
sample_info <- read.csv("Input/Lipidomics metadata II.csv", check.names = F) #metadata

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeWT = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "WT"),
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeWT = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "WT"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:5)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeKO - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_F KO v Pooled Tam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_F KO v Pooled Tam.csv", row.names = F)

###################################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexM_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_M KO v Pooled Tam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_M KO v Pooled Tam.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexF_GenotypeKO,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_Male v Female KO.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_Male v Female KO.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeTam - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid results_Male v Female Tam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Sig hits_Limma lipid results_Male v Female Tam.csv", row.names = F)

################################################################################
########################## Venn Diagram##########################################
#install.packages("ggVennDiagram")
library(ggVennDiagram)

m1 <- read_csv("Output/Limma lipid results_F KO v Pooled Tam.csv")
m2 <- read_csv("Output/Limma lipid results_F_KO.csv")

m1 <- m1 %>% filter(adj.P.Val<0.05)
m2 <- m2 %>% filter(adj.P.Val<0.05)

# Create named list of lipid hits (assumes lipid IDs are in a column — adjust column name as needed)
# Common column names might be: "lipid", "feature", "name", "ID" — update below
lipid_col <- "Name"   # <-- change this to your actual lipid ID column name

venn_list <- list(
  "KO v Pooled Tam" = m1[[lipid_col]],
  "F_KO"            = m2[[lipid_col]]
)

ggVennDiagram(venn_list, label_alpha = 0) +
  scale_fill_gradient(low = "white", high = "white") +
  scale_color_manual(values = c("black", "black")) +
  labs(title = "Significant Lipid Hits (adj.P.Val < 0.05)") +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    legend.position = "none"
  )

ggsave("Output/Venn_diagram_lipid_hits.pdf", width = 6, height = 5)

################################################################################
################################################################################
#Volcano Plots

library(ggplot2)
library(ggrepel)
#write.csv(results, "Output/Limma lipid results_M_Tam v CreTam.csv", row.names = F)
#################################### Male - Tam v CreTam
df <- read.csv("Output/Limma lipid results_M_Tam v CreTam.csv", check.names = F)
#df <- df %>% filter(adj.P.Val < 0.05)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

#convert log average expression to linear scale
df$meanexpression <- 2^df$AveExpr

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(df$logFC), max(df$logFC))))


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(df, aes(x=logFC,y= -log10(P.Value), size = meanexpression)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Log"[2]*"FC (male Tam/male CreTam)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  theme(legend.position = "none",
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        axis.text = element_text(size = 14, color = "black"),   # Axis text
        axis.title = element_text(size = 16),    # Axis labels
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(1.5,10), limits = range(df$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,6)) +
  xlim(c(-2,2)) 
volcano_plot
ggsave(filename="Male Tam v CreTam.pdf",width=5,height=4.84,units="in")
ggsave(filename="Male Tam v CreTam.svg",width=5,height=4.84,units="in")

#################################### Female - Tam v CreTam
df <- read.csv("Output/Limma lipid results_F_Tam v CreTam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

#convert log average expression to linear scale
df$meanexpression <- 2^df$AveExpr

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(df$logFC), max(df$logFC))))


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(df, aes(x=logFC,y= -log10(P.Value), size = meanexpression)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Log"[2]*"FC (female Tam/female CreTam)"))) +  
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(size = "Average Abundance") +
  theme(legend.position = "none",
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        axis.text = element_text(size = 14, color = "black"),   # Axis text
        axis.title = element_text(size = 16),    # Axis labels
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(1.5,10), limits = range(df$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,6)) +
  xlim(c(-2,2)) 
volcano_plot
ggsave(filename="Female Tam v CreTam.pdf",width=5,height=4.84,units="in")
ggsave(filename="Female Tam v CreTam.svg",width=5,height=4.84,units="in")
#################################### Male v Female control
df <- read.csv("Output/Limma lipid results_Male v Female Tam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

#convert log average expression to linear scale
df$meanexpression <- 2^df$AveExpr

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(df$logFC), max(df$logFC))))

#label dots with biggest positive FC
label_point <- df %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 10) 

label_point4 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(desc(AveExpr)) %>%
  slice_head(n = 10)

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, label_point4)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(df, aes(x=logFC,y= -log10(P.Value), size = meanexpression)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 2) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = "Male v Female Lipidomics") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  #scale_size_continuous(range = c(1,12), limits = range(df$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,10)) +
  xlim(c(-3,3)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Name),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 3-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Name),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -3-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot
ggsave(filename="Male v Female Tam.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Male v Female Tam.svg",width=6.28,height=5.28,units="in")

################################### Female
#female <- read.csv("Output/Limma lipid results_F_KO.csv", check.names = F)
female <- read.csv("Output/Limma lipid results_F KO v Pooled Tam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

#convert log average expression to linear scale
female$meanexpression <- 2^female$AveExpr

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(female$logFC), max(female$logFC))))

#label dots with biggest positive FC
label_point <- female %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 8) 

#label dots with smallest negative FC
label_point2 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 12) 

#label dots with highest logP val
label_point3 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 8) 

label_point4 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(desc(AveExpr)) %>%
  slice_head(n = 8)

# Label dots with biggest mean expression when logFC < 0
label_point5 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  filter(logFC < 0) %>%
  arrange(desc(AveExpr)) %>%
  slice_head(n = 8)

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, label_point4, label_point5)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)
unique_labels2 <- unique_labels2[-3,]
unique_labels2 <- unique_labels2[-17,]

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(female, aes(x=logFC, y= -log10(P.Value), size = meanexpression)) +
  geom_point(aes(fill = ifelse(adj.P.Val < significance_threshold,
                               ifelse(logFC > 0, "Red", "Blue"), "Grey")),
             shape = 21,
             color = "black",
             stroke = 0.1) +
  xlab(expression(paste("Log"[2]*"FC (female KO/female p.Tam)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_fill_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  labs(title = " ") +  
  theme(legend.position = "none",
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black", linewidth = 0.3),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black", linewidth = 0.3),
        axis.ticks.x = element_line(color = "black"),
        axis.text = element_text(size = 14, color = "black"),
        axis.title = element_text(size = 16),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(2,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(fill = "none", size = "none") +
  ylim(c(0,10)) +
  xlim(c(-4,4)) +
  geom_text_repel(
    data = unique_labels1,
    aes(label = Name),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 2-unique_labels1$logFC,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  geom_text_repel(
    data = unique_labels2,
    aes(label = Name),
    ylim=c(-log10(0.09), NA),
    color = "skyblue2",
    box.padding = 0.2,
    point.padding = 0.1,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -2-unique_labels2$logFC,
    direction = "y",
    hjust = 1,
    size = 4,
    force = 3,
    force_pull = 0.5,
    min.segment.length = 0,
    show.legend = F
  )
volcano_plot
ggsave(filename="Female KO v Pooled Tam.pdf",width=5,height=4.84,units="in")
ggsave(filename="Female KO v Pooled Tam.svg",width=5,height=4.84,units="in")


##################Males
male <- read.csv("Output/Limma lipid results_M_KO.csv", check.names = F)
#male <- read.csv("Output/Limma lipid results_M KO v Pooled Tam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(male$logFC), max(male$logFC))))

#convert log average expression to linear scale
male$meanexpression <- 2^male$AveExpr

#label dots with biggest positive FC
label_point <- male %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 5) 

#label dots with smallest negative FC
label_point2 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 5) 

#label dots with highest logP val
label_point3 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 5) 

label_point4 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(desc(AveExpr)) %>%
  slice_head(n = 5)

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, label_point4)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels1 <- unique_labels1[-12,]

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(male, aes(x=logFC, y= -log10(P.Value), size = meanexpression)) +
  geom_point(aes(fill = ifelse(adj.P.Val < significance_threshold,
                               ifelse(logFC > 0, "Red", "Blue"), "Grey")),
             shape = 21,
             color = "black",
             stroke = 0.1) +
  xlab(expression(paste("Log"[2]*"FC (male KO/male CreTam)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_fill_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  labs(title = " ") +  
  theme(legend.position = "none",
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black", linewidth = 0.3),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black", linewidth = 0.3),
        axis.ticks.x = element_line(color = "black"),
        axis.text = element_text(size = 14, color = "black"),
        axis.title = element_text(size = 16),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(2,12), limits = range(male$meanexpression, na.rm = T)) +
  guides(fill = "none", size = "none") +
  ylim(c(0,10)) +
  xlim(c(-4,4)) +
  geom_text_repel(
    data = unique_labels1,
    aes(label = Name),
    ylim=c(-log10(1), NA),
    color = "indianred",
    box.padding = 0.8,
    point.padding = 0.5,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 2-unique_labels1$logFC,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) 
volcano_plot

ggsave(filename="Male KO v CreTam.pdf",width=5,height=5.07,units="in")
ggsave(filename="Male KO v CreTam.svg",width=5,height=4.84,units="in")

##################Males v Females
mf <- read.csv("Output/Limma lipid results_Male v Female Tam.csv", check.names = F)
#mf <- read.csv("Output/Limma lipid results_Male v Female KO.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(mf$logFC), max(mf$logFC))))

#convert log average expression to linear scale
mf$meanexpression <- 2^mf$AveExpr

#label dots with biggest positive FC
label_point <- mf %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 20) 

#label dots with smallest negative FC
label_point2 <- mf %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 20) 

#label dots with highest logP val
label_point3 <- mf %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 20) 

# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(mf, aes(x=logFC,y= -log10(P.Value), size = meanexpression)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Log"[2]*"FC"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = "Male/Female Tam") +  
  theme(legend.position = 'none',
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(1,10), limits = range(mf$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,10)) +
  xlim(c(-3,3)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Name),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 2-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Name),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -2-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot

ggsave(filename="Male v Female Tam.pdf",width=9.35,height=7.94,units="in")
ggsave(filename="Male v Female Tam.svg",width=9.35,height=7.94,units="in")




################################################################################################################################
##################################################################################################################################
#Lipid Class Analysis
#Lipid Profile Overview Before Starvation
prof <- read.csv("Output/IS normalized lipidomics II.csv", row.names = 1,check.names = F)

#Isolate class information from lipids
prof$Class <- sub("[0-9].*", "", prof$Name)
prof$Class <- sub("^(.*?)( )(.+)-$", "\\1-\\3", prof$Class)

#remove QC samples
prof <- prof %>%
  select(!contains("QC"))

#reorder columns
prof <- prof[c(1,81, 2:80)]

#Calculate the class sum in each sample
prof_2 <- prof %>%
  group_by(Class) %>%
  summarise(across(where(is.numeric), sum, na.rm = TRUE), .groups = "drop")
write.csv(prof_2, "Output/lipid class sums.csv", row.names = F)

#convert to log2
prof_3 <- prof_2 %>%
  mutate(across(-c(1), ~ifelse(.> 0, log2(.),NA)))
write.csv(prof_3, "Output/Log lipid class sums.csv", row.names = F)

##############################################
#Limma Lipid Classes
library(limma)

#########################Limma with Pooled Controls ###################################################
exprs <- read.csv("Output/Log lipid class sums.csv", check.names = F) #expression data
sample_info <- read.csv("Input/Lipidomics metadata II.csv", check.names = F) #metadata

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeWT = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "WT"),
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeWT = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "WT"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)


# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:5)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeKO - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid class results_F KO v pooled Tam.csv", row.names = F)



#####################males
sample_info <- read.csv("Input/Lipidomics metadata.csv", check.names = F) #metadata

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeWT = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "WT"),
  SexF_GenotypeCre = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre"),
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeCreTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Cre+Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeWT = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "WT"),
  SexM_GenotypeCre = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeCreTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Cre+Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:7)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
###############
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexM_GenotypeCreTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))

write.csv(results, "Output/Limma lipid class results_M KO v CreTam.csv", row.names = F)

###############
# contrast
#contrast.matrix <- makeContrasts(
#  SexM_GenotypeTam - SexF_GenotypeTam,
#  levels = design_matrix
#)
#fit the linear model to the contrast
#fit2 <- contrasts.fit(fit, contrast.matrix)
#fit2 <- eBayes(fit2)
#results <- topTable(fit2, coef = 1, number = nrow(exprs))

#write.csv(results, "Output/Limma lipid class results_M v F Tam.csv", row.names = F)

###############
# contrast
#contrast.matrix <- makeContrasts(
#  SexM_GenotypeKO - SexF_GenotypeKO,
#  levels = design_matrix
#)
#fit the linear model to the contrast
#fit2 <- contrasts.fit(fit, contrast.matrix)
#fit2 <- eBayes(fit2)
#results <- topTable(fit2, coef = 1, number = nrow(exprs))

#write.csv(results, "Output/Limma lipid class results_M v F KO.csv", row.names = F)

###############
# contrast
#contrast.matrix <- makeContrasts(
#  SexM_GenotypeWT - SexF_GenotypeWT,
#  levels = design_matrix
#)
#fit the linear model to the contrast
#fit2 <- contrasts.fit(fit, contrast.matrix)
#fit2 <- eBayes(fit2)
#results <- topTable(fit2, coef = 1, number = nrow(exprs))

#write.csv(results, "Output/Limma lipid class results_M v F WT.csv", row.names = F)
#####################################################################################
########################### Volcano #################################################
fem <- read.csv("Output/Limma lipid class results_F KO v pooled Tam.csv", check.names = F)

# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

#convert log average expression to linear scale
fem$meanexpression <- 2^fem$AveExpr

# Calculate the maximum absolute logFC value
max_abs_fc<- max(abs(c(min(fem$logFC), max(fem$logFC))))

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(fem, aes(x = logFC, y = -log10(P.Value), size = meanexpression)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +  # Vertical line at x = 0
  labs(title = " ", size = "Mean expression") +
  xlab(expression(paste("Log"[2]*"FC (female KO/female p.Tam)"))) +
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  theme(legend.position = "none",
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        axis.text = element_text(size = 14, color = "black"),   # Axis text
        axis.title = element_text(size = 16),    # Axis labels
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(3,10), limits = range(fem$meanexpression, na.rm = T)) +
  guides(color = 'none') +
  ylim(c(0,7)) 

# Set custom x-axis limits to center around 0
volcano_plot <- volcano_plot + xlim(c(-max_abs_fc, max_abs_fc))

# Add labels with random arrangement to minimize overlap
volcano_plot <- volcano_plot +
  geom_text_repel(
    data = fem,
    aes(label = Class),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 5,
    show.legend = FALSE
  )

# Print the plot
print(volcano_plot)
ggsave(filename="lipid class volcano plot_F KO v pooled Tam.pdf",width=5,height=4.84,units="in")
ggsave(filename="lipid class volcano plot_F KO v CreTam.svg",width=5,height=4.84,units="in")

####################### Male
mal <- read.csv("Output/Limma lipid class results_M KO v CreTam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

#convert log average expression to linear scale
mal$meanexpression <- 2^mal$AveExpr

# Calculate the maximum absolute logFC value
max_abs_fc<- max(abs(c(min(mal$logFC), max(mal$logFC))))

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(mal, aes(x = logFC, y = -log10(P.Value), size = meanexpression)) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold, 
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(significance_threshold), linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +  # Vertical line at x = 0
  labs(title = " ", size = "Mean expression") +
  xlab(expression(paste("Log"[2]*"FC (male KO/male CreTam)"))) +
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  theme(legend.position = "none",
        panel.background = element_rect(fill = "white"),
        axis.line.y = element_line(color = "black"),
        axis.ticks.y = element_line(color = "black"),
        axis.line.x = element_line(color = "black"),
        axis.ticks.x = element_line(color = "black"),
        axis.text = element_text(size = 14, color = "black"),   # Axis text
        axis.title = element_text(size = 16),    # Axis labels
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm"),
        plot.title = element_text(hjust = 0.5)) +
  scale_size_continuous(range = c(3,10), limits = range(mal$meanexpression, na.rm = T)) +
  guides(color = 'none') +
  ylim(c(0,5)) 

# Set custom x-axis limits to center around 0
volcano_plot <- volcano_plot + xlim(c(-max_abs_fc, max_abs_fc))

# Add labels with random arrangement to minimize overlap
volcano_plot <- volcano_plot +
  geom_text_repel(
    data = mal,
    aes(label = Class),
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    #nudge_x = runif(nrow(merged_stats), -0.5, 0.5),  # Random x nudge
    #nudge_y = runif(nrow(merged_stats), -0.5, 0.5),  # Random y nudge
    size = 5,
    show.legend = FALSE
  )

# Print the plot
print(volcano_plot)
ggsave(filename="lipid class volcano plot_M KO v CreTam.pdf",width=5,height=4.84,units="in")
ggsave(filename="lipid class volcano plot_M KO v CreTam.svg",width=5,height=4.84,units="in")

#####################################################################################
########################### Heatmap of sig diff lipids #################################################
m <- read.csv("Output/Sig hits_Limma lipid results_M KO v Pooled Tam.csv", check.names = F)
f <- read.csv("Output/Sig hits_Limma lipid results_F KO v Pooled Tam.csv", check.names = F)
dt <- read.csv("Output/Heatmap data matrix.csv", check.names = F)

#rename the first column of the dt frame to have the same name as the m and f datafram
colnames(dt)[1] <- "Name"

#filter dt data frame for significant lipids
m2 <- dt %>% filter(Name %in% m$Name)
f2 <- dt %>% filter(Name %in% f$Name)

# Set row names and remove the Name column
rownames(m2) <- m2$Name
m2$Name <- NULL

rownames(f2) <- f2$Name
f2$Name <- NULL


######Plot separtate heatmaps for Males and Females
f3 <- f2[c(10:37)]

#calculate row z-score
m3.z <- t(scale(t(f3)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
FnCreTam <- length(grep("3|4", colnames(m4)))
FnHet <- length(grep("5", colnames(m4)))
FnKO <- length(grep("6", colnames(m4)))

end_index_FnCreTam <- grep("3|4", colnames(m4)) [FnCreTam]
end_index_FnHet <- grep("5", colnames(m4)) [FnHet]
end_index_FnKO <- grep("6", colnames(m4)) [FnKO]



#row_order <- order(class_factor)

heatmap_f2 <- Heatmap(m4,
                      show_row_names = T,
                      show_column_names = F,
                      show_row_dend = F,
                      show_column_dend = FALSE,
                      
                      cluster_rows = TRUE,
                      #cluster_columns = F,
                      #row_order = row_order,
                      
                      clustering_distance_rows = "euclidean",
                      clustering_method_rows = "ward.D2",
                      
                      #row_order = rownames(m4),
                      row_names_side = "left",
                      row_names_gp = gpar(col = "black", fontsize = 10),
                      
                      row_dend_side = "left",
                      row_dend_width = unit(20, "mm"),
                      
                      column_names_side = "top",
                      column_dend_side = "bottom",
                      
                      col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                      
                      
                      column_order = 1:ncol(m4),
                      
                      height = unit(650, "mm"),
                      width = ncol(m4)*unit(3, "mm"),
                      
                      
                      top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                           height = unit(6, "mm"))),
                      border_gp = gpar(col = "black"), # set border color
                      
                      show_heatmap_legend = TRUE,
                      heatmap_legend_param = list(
                        title = "Z-score",
                        title_position = "topleft",
                        at = c(-3, 0, 3), # set ticks/numbers of legend
                        legend_height = unit(3, "cm")),
                      
                      #split = 2, # split the heatmap into separate blocks by hierarchical clustering
                      #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                      ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                      
                      layer_fun = function(j, i, x, y, width, height, fill) {
                        mat = restore_matrix(j, i, x, y)
                        
                        ind = unique(c(mat[, c(end_index_FnCreTam,
                                               end_index_FnHet,
                                               end_index_FnKO
                        ) # enter the number where you want a gap between columns
                        ])) 
                        
                        grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                  y = y[ind], 
                                  width = unit(0.03, "inches"), # width of the gap
                                  height = unit(1/nrow(m4), "npc"),
                                  gp = gpar(col = "white", fill = "white") # color of the gap
                        )
                      }
) 

draw(heatmap_f2)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 4
grid.rect(x = (end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnCreTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("Ctrl", 
          x = (end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))                    

#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("Het", 
          x = (end_index_FnHet + end_index_FnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black")) 

## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnCreTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnKO/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

# step 4 - end by closing the saved file

pdf(file = 'Figures/Female IS Heart Lipidomics_Sig hits.pdf',
    width = 10, 
    height = 30)


CairoSVG(file = "Figures/Female IS Heart Lipidomics_Sig hits.svg", width = 10, height = 30)

#step 2 - draw heatmap in the saved file
draw(heatmap_f2)

dev.off()
####################### Plot Male Heatmap
m3 <- m2[c(48:79)]
#calculate row z-score
m3.z <- t(scale(t(m3)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps
MnCreTam <- length(grep("9|10", colnames(m4)))
MnHet <- length(grep("11", colnames(m4)))
MnKO <- length(grep("12", colnames(m4)))

end_index_MnCreTam <- grep("9|10", colnames(m4)) [MnCreTam]
end_index_MnHet <- grep("11", colnames(m4)) [MnHet]
end_index_MnKO <- grep("12", colnames(m4)) [MnKO]


#row_order <- order(class_factor)

heatmap_m2 <- Heatmap(m4,
                      show_row_names = T,
                      show_column_names = F,
                      show_row_dend = F,
                      show_column_dend = FALSE,
                      
                      cluster_rows = TRUE,
                      #cluster_columns = F,
                      #row_order = row_order,
                      
                      clustering_distance_rows = "euclidean",
                      clustering_method_rows = "ward.D2",
                      
                      #row_order = rownames(m4),
                      row_names_side = "left",
                      row_names_gp = gpar(col = "black", fontsize = 10),
                      
                      row_dend_side = "left",
                      row_dend_width = unit(20, "mm"),
                      
                      column_names_side = "top",
                      column_dend_side = "bottom",
                      
                      col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                      
                      
                      column_order = 1:ncol(m4),
                      
                      height = unit(200, "mm"),
                      width = ncol(m4)*unit(3, "mm"),
                      
                      
                      top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                           height = unit(6, "mm"))),
                      border_gp = gpar(col = "black"), # set border color
                      
                      show_heatmap_legend = TRUE,
                      heatmap_legend_param = list(
                        title = "Z-score",
                        title_position = "topleft",
                        at = c(-3, 0, 3), # set ticks/numbers of legend
                        legend_height = unit(3, "cm")),
                      
                      #split = 2, # split the heatmap into separate blocks by hierarchical clustering
                      #row_km = 3, # or split the heatmap into separate blocks by k-means clustering
                      ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                      
                      layer_fun = function(j, i, x, y, width, height, fill) {
                        mat = restore_matrix(j, i, x, y)
                        
                        ind = unique(c(mat[, c(end_index_MnCreTam,
                                               end_index_MnHet,
                                               end_index_MnKO
                        ) # enter the number where you want a gap between columns
                        ])) 
                        
                        grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                  y = y[ind], 
                                  width = unit(0.03, "inches"), # width of the gap
                                  height = unit(1/nrow(m4), "npc"),
                                  gp = gpar(col = "white", fill = "white") # color of the gap
                        )
                      }
) 

draw(heatmap_m2)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"

#Condition label 10
grid.rect(x = (end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (end_index_MnCreTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("Ctrl", 
          x = (end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))

#Condition label 11
grid.rect(x = (end_index_MnHet + end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("Het", 
          x = (end_index_MnHet + end_index_MnCreTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))

#Condition label 12
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 11,
                    col = "black"))
## Top label gaps
#Vertical lines
grid.rect(x = end_index_MnCreTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
# step 4 - end by closing the saved file

pdf(file = 'Figures/Male IS Heart Lipidomics_Sig hits.pdf',
    width = 10, 
    height = 10)


CairoSVG(file = "Figures/Male IS Heart Lipidomics_Sig hits.svg", width = 10, height = 10)

#step 2 - draw heatmap in the saved file
draw(heatmap_m2)

dev.off()

#########################################################################################
#########################################################################################
#########################################################################################
################################## UpSet Plot############################################
library(tidyverse)
install.packages("ggplot2")
library(ggplot2)
library(dplyr)
library(gridtext)
install.packages("ComplexUpset")
library(ComplexUpset)


install.packages("renv")
library(renv)
renv::init()
renv::install("ggplot2@3.4.4")
renv::remove("ComplexUpset")           # remove old binary
renv::remove("ggplot2")           # remove old binary

renv::install("ggplot2")                 # gets latest version (≥ 3.5)
renv::install("ComplexUpset@1.3.3")     # compatible with latest ggplot2

remotes::install_github("krassowski/complex-upset@v1.0.0")






library(ggplot2)
packageVersion("ggplot2")
library(ComplexUpset)
packageVersion("ComplexUpset")

#import limma stat sheets
male <- read.csv("Output/Limma lipid results_M_KO.csv")
female <- read.csv("Output/Limma lipid results_F KO v pooled Tam.csv")

# Add "_F" to all column names except the first one
colnames(female)[2:ncol(female)] <- paste0(colnames(female)[2:ncol(female)], "_F")

# Add "_M" to all column names except the first one
colnames(male)[2:ncol(male)] <- paste0(colnames(male)[2:ncol(male)], "_M")

#merge male and female sheets
comb <- merge(male, female, by = "Name")


# For each comparison, added a column to label the significance as TRUE or FALSE. 
comb$"KO v CreTam (M)" <- ifelse(comb$adj.P.Val_M <0.05, "TRUE", "FALSE")
comb$"KO v p.Tam (F)" <- ifelse(comb$adj.P.Val_F <0.05, "TRUE", "FALSE")

# call out the intersected proteins
intersect <- comb %>%
  filter(comb$"KO v CreTam (M)" == "TRUE",comb$"KO v p.Tam (F)" == "TRUE")

write.csv(intersect, "Output/Intersected Lipids M and F_KO v Tam.CSV")

# For each comparison, added a column to label the directions of change as Up, Down, or NS.

comb$M_direct <- ifelse(!comb$adj.P.Val_M <0.05, 
                                    "NS",
                                    ifelse(comb$logFC_M >0,
                                           "Up", "Down"))
comb$F_direct <- ifelse(!comb$adj.P.Val_F <0.05, 
                        "NS",
                        ifelse(comb$logFC_F >0,
                               "Up", "Down"))

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"

comb$Intersect_direction <- ifelse(rowSums(comb[, c(16:17)] =="Down", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), 
                                    "Down", 
                                    ifelse(rowSums(comb[, c(16:17)] =="Up", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), "Up", "Different direction"))

comb$Intersect_direction <- factor(comb$Intersect_direction, 
                                    levels = c("Up","Down"))

# Plot UpSet

KOvCre <- colnames(comb)[14:15]

upset(comb, KOvCre, name = '', width_ratio = 0.7,
      height_ratio = 0.7, min_size = 1, min_degree = 1,
      
      base_annotations = list(
        'Intersection size' = (
          intersection_size(mapping = aes(fill = Intersect_direction))
          + scale_fill_manual(values = c("indianred3", "skyblue2"))
          + theme(
            axis.title.y = element_text(margin = margin(r = -10), size = 14),
            text = element_text(size = 14),
            legend.title = element_blank(),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank()
          )
        )
      ),
      
      # Trick: set bar height to 0 by scaling y-axis to 0 range
      set_sizes = (
        upset_set_size()
        + scale_y_continuous(limits = c(0, 0))  # Shrinks bars to invisible
        + theme_void()
      ),
      
      stripes = c("white")
) + 
  theme(
    panel.grid = element_blank(),
    text = element_text(size = 14)
  ) +
  patchwork::plot_layout(heights = c(1, 0.5, 1))
#####################
#--- 1. Define reusable theme objects ---
  theme_intersection <- theme(
    axis.title.y = element_text(margin = margin(r = -10), size = 14),
    text = element_text(size = 14),
    legend.title = element_blank(),
    panel.background = element_rect(fill = "white", color = NA),  # white background
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank()
  )
theme_set_sizes <- theme_void()
# --- 2. Build plot ---
p <- upset(
  comb,
  KOvCre,
  name = '',
  width_ratio = 0.7,
  height_ratio = 0.7,
  min_size = 1,
  min_degree = 1,
  base_annotations = list(
    'Intersection size' = (
      intersection_size(mapping = aes(fill = Intersect_direction)) +
        scale_fill_manual(values = c("indianred3", "skyblue2")) +
        theme(panel.background = element_rect(fill = "white", color = NA),
              text = element_text(size = 14))
    )
  ),
  set_sizes = (
    upset_set_size() +
      scale_y_continuous(limits = c(0, 0)) + # Shrinks bars to invisible 
      theme_set_sizes
  ),
  stripes = c("white"),
  # --- 3. Supply our safe theme externally ---
  themes = list(intersections_matrix = theme_intersection)
) +
  theme(
    panel.grid = element_blank(),
    text = element_text(size = 14)
  ) +
  patchwork::plot_layout(heights = c(1, 0.5, 2))
# --- 4. Draw ---
p



ggsave(filename="Male v Female UpSets.png",width=7,height=4.21,units="in",dpi=600)
ggsave(filename="Male v Female UpSets.pdf",width=7,height=4.21,units="in")
ggsave(filename="Male v Female UpSets.svg",width=7,height=4.21,units="in")
################################################################################
#import limma stat sheets
m1 <- read.csv("Output/Limma lipid results_M KO v pooled Tam.csv")
m2 <- read.csv("Output/Limma lipid results_M_KO.csv")

# Add "_F" to all column names except the first one
colnames(m1)[2:ncol(m1)] <- paste0(colnames(m1)[2:ncol(m1)], "_p")

# Add "_M" to all column names except the first one
colnames(m2)[2:ncol(m2)] <- paste0(colnames(m2)[2:ncol(m2)], "_C")

#merge male and female sheets
comb <- merge(m1, m2, by = "Name")


# For each comparison, added a column to label the significance as TRUE or FALSE. 
comb$"KO v Tam" <- ifelse(comb$adj.P.Val_p <0.05, "TRUE", "FALSE")
comb$"KO v CreTam" <- ifelse(comb$adj.P.Val_C <0.05, "TRUE", "FALSE")

# call out the intersected proteins
intersect <- comb %>%
  filter(comb$"KO v Tam" == "TRUE",comb$"KO v CreTam" == "TRUE")

#write.csv(intersect, "Output/Intersected Lipids M and F_KO v Tam.CSV")

# For each comparison, added a column to label the directions of change as Up, Down, or NS.

comb$p_direct <- ifelse(!comb$adj.P.Val_p <0.05, 
                        "NS",
                        ifelse(comb$logFC_p >0,
                               "Up", "Down"))
comb$C_direct <- ifelse(!comb$adj.P.Val_C <0.05, 
                        "NS",
                        ifelse(comb$logFC_C >0,
                               "Up", "Down"))

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"

comb$Intersect_direction <- ifelse(rowSums(comb[, c(16:17)] =="Down", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), 
                                   "Down", 
                                   ifelse(rowSums(comb[, c(16:17)] =="Up", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), "Up", "Different direction"))

comb$Intersect_direction <- factor(comb$Intersect_direction, 
                                   levels = c("Up","Down"))

# Plot UpSet

KOvCre <- colnames(comb)[14:15]

upset(comb, KOvCre, name = '', width_ratio = 0.7,
      height_ratio = 0.7, min_size = 1, min_degree = 1,
      
      base_annotations = list(
        'Intersection size' = (
          intersection_size(mapping = aes(fill = Intersect_direction))
          + scale_fill_manual(values = c("indianred3", "skyblue2"))
          + theme(
            axis.title.y = element_text(margin = margin(r = -10), size = 14),
            text = element_text(size = 14),
            legend.title = element_blank(),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank()
          )
        )
      ),
      
      # Trick: set bar height to 0 by scaling y-axis to 0 range
      set_sizes = (
        upset_set_size()
        + scale_y_continuous(limits = c(0, 0))  # Shrinks bars to invisible
        + theme_void()
      ),
      
      stripes = c("white")
) + 
  theme(
    panel.grid = element_blank(),
    text = element_text(size = 14)
  ) +
  patchwork::plot_layout(heights = c(1, 0.5, 1))
#####################
#--- 1. Define reusable theme objects ---
theme_intersection <- theme(
  axis.title.y = element_text(margin = margin(r = -10), size = 14),
  text = element_text(size = 14),
  legend.title = element_blank(),
  panel.background = element_rect(fill = "white", color = NA),  # white background
  panel.grid.major = element_blank(),
  panel.grid.minor = element_blank()
)
theme_set_sizes <- theme_void()
# --- 2. Build plot ---
p <- upset(
  comb,
  KOvCre,
  name = '',
  width_ratio = 0.7,
  height_ratio = 0.7,
  min_size = 1,
  min_degree = 1,
  base_annotations = list(
    'Intersection size' = (
      intersection_size(mapping = aes(fill = Intersect_direction)) +
        scale_fill_manual(values = c("indianred3", "skyblue2")) +
        theme(panel.background = element_rect(fill = "white", color = NA),
              text = element_text(size = 14))
    )
  ),
  set_sizes = (
    upset_set_size() +
      scale_y_continuous(limits = c(0, 0)) + # Shrinks bars to invisible 
      theme_set_sizes
  ),
  stripes = c("white"),
  # --- 3. Supply our safe theme externally ---
  themes = list(intersections_matrix = theme_intersection)
) +
  theme(
    panel.grid = element_blank(),
    text = element_text(size = 14)
  ) +
  patchwork::plot_layout(heights = c(1, 0.5, 2))
# --- 4. Draw ---
p



ggsave(filename="Male v Female UpSets.png",width=7,height=4.21,units="in",dpi=600)
ggsave(filename="Male v Female UpSets.pdf",width=7,height=4.21,units="in")
ggsave(filename="Male v Female UpSets.svg",width=7,height=4.21,units="in")
########################################################################
########################################################################
########################## Dot Plot VIP################################
#import of data
vip <- read.csv("Output/PLSDA VIP_Genotype response variable.csv", row.names = 1)
stat <- read.csv("Output/Limma lipid results_F KO v Pooled Tam.csv")

#change names to match VIP list
names(stat)[names(stat) == "Name"] <- "Lipid"

#merge in logFC from stat 
vips <- merge(vip, stat[, c("Lipid", "logFC", "adj.P.Val")], by = "Lipid")

#set logFC to NA for non-significant proteins so they render as a fixed color
vips <- vips %>%
  mutate(logFC_plot = ifelse(adj.P.Val < 0.05, logFC, NA))

#Identify the top 40 vips
strong_vip <- vips %>%
  arrange(-comp1) %>%
  slice_head(n = 25) 


# Reorder Description based on comp1
strong_vip <- strong_vip %>%
  mutate(Lipid = factor(Lipid, levels = Lipid[order(comp1, decreasing = F)]))


p.vip <- ggplot(strong_vip, aes(x = comp1, y = Lipid, fill = logFC_plot)) +
  geom_point(size = 3, shape = 21, color = "black", stroke = 0.2) +
  scale_fill_gradient2(
    low = "blue", mid = "white", high = "red4", midpoint = 0,
    na.value = "white",
    name = "logFC"
  ) +
  theme_bw(base_size = 12) +
  ylab(NULL) +
  xlab("VIP Score") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 12),
    axis.text.x = element_text(colour = "black", size = 12),
    strip.text = element_text(colour = "black"),
    legend.position = "right"
  )
p.vip
ggsave(filename="vip dotplot_Genotype response.pdf",width=4,height=4.36,units="in")
ggsave(filename="vip dotplot_Genotype response.svg",width=4,height=4.36,units="in")

#########################################################################################
###################################### Lipid Correlation Matrix Features##########################
#########################################################################################
#Matrix data generated from LipidOne v 2.3
males <- read.csv("Input/Mcorrelation_matrix_features.csv", row.names = 1, check.names = F)
females <- read.csv("Input/Fcorrelation_matrix_features.csv", row.names = 1, check.names = F)
df <- read.csv("Input/order.csv")

# Get desired order
ord <- df$LipidClass
# Reorder rows and columns identically
males <- males[ord, ord]
females <- females[ord, ord]

#convert dataframe to matrix
males <- as.matrix(males)
females <- as.matrix(females)

males_tri <- males
males_tri[lower.tri(males_tri)] <- NA


heatmap <- Heatmap(
  males_tri,
  
  show_row_names = TRUE,
  show_column_names = TRUE,
  show_row_dend = FALSE,
  show_column_dend = FALSE,
  
  cluster_rows = FALSE,
  cluster_columns = FALSE,
  
  row_order = rownames(males_tri),
  row_names_side = "right",
  row_names_gp = gpar(col = "black", fontsize = 12),
  
  column_names_side = "top",   # ⬅ column names at bottom
  column_names_rot = 45,
  
  col = colorRamp2(
    c(-1, 0, 1),
    c("darkblue", "white", "firebrick4")
  ),
  
  column_order = 1:ncol(males_tri),
  
  height = unit(100, "mm"),
  width  = ncol(males_tri) * unit(7, "mm"),
  
  border_gp = gpar(col = "black"),
  
  na_col = "white",   # ⬅ blank triangle is white
  
  show_heatmap_legend = TRUE,
  heatmap_legend_param = list(
    title = " ",
    title_position = "topleft",
    at = c(-1, 0, 1),
    legend_height = unit(3, "cm")
  )
)


draw(heatmap)
pdf(file = 'Figures/Male correlation matrix.pdf',
    width = 10, 
    height = 10)


CairoSVG(file = "Figures/Male correlation matrix.svg", width = 10, height = 10)

#step 2 - draw heatmap in the saved file
draw(heatmap)
dev.off()


################# females
females_tri <- females
females_tri[lower.tri(females_tri)] <- NA

heatmap <- Heatmap(
  females_tri,
  
  show_row_names = TRUE,
  show_column_names = TRUE,
  show_row_dend = FALSE,
  show_column_dend = FALSE,
  
  cluster_rows = FALSE,
  cluster_columns = FALSE,
  
  row_order = rownames(females_tri),
  row_names_side = "right",
  row_names_gp = gpar(col = "black", fontsize = 12),
  
  column_names_side = "top",   # ⬅ column names at bottom
  column_names_rot = 45,
  
  col = colorRamp2(
    c(-1, 0, 1),
    c("darkblue", "white", "firebrick4")
  ),
  
  column_order = 1:ncol(females_tri),
  
  height = unit(100, "mm"),
  width  = ncol(males_tri) * unit(7, "mm"),
  
  border_gp = gpar(col = "black"),
  
  na_col = "white",   # ⬅ blank triangle is white
  
  show_heatmap_legend = TRUE,
  heatmap_legend_param = list(
    title = " ",
    title_position = "topleft",
    at = c(-1, 0, 1),
    legend_height = unit(3, "cm")
  )
)


draw(heatmap)
pdf(file = 'Figures/Female correlation matrix.pdf',
    width = 10, 
    height = 10)


CairoSVG(file = "Figures/Female correlation matrix.svg", width = 10, height = 10)

#step 2 - draw heatmap in the saved file
draw(heatmap)

dev.off()

#########################################################################################
###################################### Biomarker Discovery ##############################
#########################################################################################
#Data generated from LipidOne v 2.3
males <- read.csv("Input/M_Biomarker discovery.csv", check.names = F)
m_stat <- read.csv("Output/Limma lipid results_M_KO.csv", check.names = F)
names(m_stat)[names(m_stat) == "Name"] <- "Variable"
m_stat <- m_stat[c(1,2)]
males <- merge(males, m_stat, by = "Variable")

females <- read.csv("Input/F_Biomarker discovery.csv", check.names = F)
f_stat <- read.csv("Output/Limma lipid results_F_KO.csv", check.names = F)
names(f_stat)[names(f_stat) == "Name"] <- "Variable"
f_stat <- f_stat[c(1,2)]
females <- merge(females, f_stat, by = "Variable")


# Reorder Description based on cohen's d
males <- males %>%
  mutate(Variable = factor(Variable, levels = Variable[order(`Cohen's d`, decreasing = F)]))

females <- females %>%
  mutate(Variable = factor(Variable, levels = Variable[order(`Cohen's d`, decreasing = F)]))

# Plot male dot plot
biom.male <- ggplot(males,
                     aes(x = `Cohen's d`, y = Variable)) +
  geom_point(aes(size = AUC,
                 colour = logFC)) +
  scale_color_gradient2(midpoint = 0.45, low = "salmon", mid = "indianred2", high = "indianred4", space = "Lab") +
  theme_bw(base_size = 13) +
  ylab(NULL) +
  xlab("Cohen's d") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 13),
    axis.text.x = element_text(colour = "black", size = 13),
    strip.text = element_text(colour = "black")
  ) +
  labs(color = "LogFC", size = "AUC") +
  coord_cartesian(xlim = c(1, 6))   # <-- Set x-axis limits

biom.male

ggsave(filename="Male Biomarkers.pdf",width=4.5,height=4.36,units="in")
#ggsave(filename="Male Biomarkers.svg",width=6.03,height=4.78,units="in")

# Plot female dot plot
biom.female <- ggplot(females,
                    aes(x = `Cohen's d`, y = Variable)) +
  geom_point(aes(size = AUC,
                 colour = logFC)) +
  scale_color_gradient2(midpoint = 0.45, low = "salmon", mid = "indianred2", high = "indianred4", space = "Lab") +
  theme_bw(base_size = 13) +
  ylab(NULL) +
  xlab("Cohen's d") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 13),
    axis.text.x = element_text(colour = "black", size = 13),
    strip.text = element_text(colour = "black")
  ) +
  labs(color = "LogFC", size = "AUC") +
  coord_cartesian(xlim = c(1, 6))   # <-- Set x-axis limits

biom.female
ggsave(filename="Female Biomarkers.pdf",width=4.2,height=4.36,units="in")
#ggsave(filename="Female Biomarkers.svg",width=6.03,height=4.78,units="in")
#############################
####################################################################################################
####################################################################################################
######################Dot plot #################################################################

#import functional data Obtained using LipidOne. Only Females had statistical significance
female <- read.csv("Input/Female Functional Index data.csv")


#set p-value at 0.05 to threshold dot plot
female <- female %>% filter(pvalue < 0.05)

#convert to log10
female$logPval <- -log10(female$pvalue)


#split datasets into positive and negative.
female_down <- female %>%
  filter(log2FC < 0)

female_up <- female %>%
  filter(log2FC > 0)

# Reorder Description based on p-value
female_down <- female_down %>%
  mutate(Index = factor(Index, levels = Index[order(logPval, decreasing = F)]))

female_up <- female_up %>%
  mutate(Index = factor(Index, levels = Index[order(logPval, decreasing = F)]))

#male <- male %>%
#  mutate(Description = factor(Description, levels = Description[order(logPval, decreasing = F)]))

# Plot dot plot
p.reactome <- ggplot(female_down,
                     aes(x = logPval, y = Index)) +
  geom_point(aes(colour = log2FC), size = 4) +
  scale_color_gradient2(midpoint = -0.3, low = "skyblue4", mid = "skyblue3", high = "skyblue1", space = "Lab") +
  scale_x_continuous(limits = c(2, 4), breaks = seq(2, 4, by = 1)) +
  theme_bw(base_size = 14) +
  ylab(NULL) +
  xlab("-Log(p.adjust)") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 14),
    axis.text.x = element_text(colour = "black", size = 14),
    strip.text = element_text(colour = "black")
  ) +
  labs(color = "Log2FC")

p.reactome
ggsave(filename="Down Dot plot_Females KOvTam.pdf",width=4.5,height=4,units="in")
ggsave(filename="Down Dot plot_Females KOvTam.svg",width=4.5,height=4,units="in")


# Plot dot plot
p.reactome <- ggplot(female_up,
                     aes(x = logPval, y = Index)) +
  geom_point(aes(colour = log2FC), size = 4) +
  scale_color_gradient2(midpoint = 0.3, low = "salmon", mid = "indianred2", high = "indianred4", space = "Lab") +
  scale_x_continuous(limits = c(1, 4), breaks = seq(1, 4, by = 1)) +
  scale_size_continuous(range = c(3, 5)) +
  theme_bw(base_size = 14) +
  ylab(NULL) +
  xlab("-Log(p.adjust)") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 14),
    axis.text.x = element_text(colour = "black", size = 14),
    strip.text = element_text(colour = "black")
  ) +
  labs(color = "Log2FC")

p.reactome
ggsave(filename="Up Dot plot_Females KOvTam.pdf",width=4.8,height=4,units="in")
ggsave(filename="Up Dot plot_Females KOvTam.svg",width=4.8,height=4,units="in")

###################################################################################################################################
###################################################################################################################################
###################################################################################################################################
# Install and load required packages
library(ggplot2)
library(dplyr)

#import dataset
df <- read.csv("Input/lipid class sums.csv", check.names = F)

#split dataset into sample groups
fem_tam <- df[c(1:2,12:22)]
fem_ko <- df[c(1:2,30:39)]

mal_tam <- df[c(1:2,55:59)]
mal_ko <- df[c(1:2,72:81)]

# Calculate row means of lipid classes from column 3 onwards
fem_tam$Mean <- rowMeans(fem_tam[, 3:ncol(fem_tam)], na.rm = TRUE)
fem_ko$Mean <- rowMeans(fem_ko[, 3:ncol(fem_ko)], na.rm = TRUE)
mal_tam$Mean <- rowMeans(mal_tam[, 3:ncol(mal_tam)], na.rm = TRUE)
mal_ko$Mean <- rowMeans(mal_ko[, 3:ncol(mal_ko)], na.rm = TRUE)

write.csv(fem_tam, "Output/Female pooled Tam Lipid class sum.csv")
write.csv(fem_ko, "Output/Female KO Lipid class sum.csv")
write.csv(mal_tam, "Output/Male CreTam Lipid class sum.csv")
write.csv(mal_ko, "Output/Male KO Lipid class sum.csv")

# Preparing data for inner donut
inner_fem_tam <- fem_tam %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_fem_tam$`Lipid Categories`<- factor(inner_fem_tam$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

inner_fem_ko <- fem_ko %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_fem_ko$`Lipid Categories`<- factor(inner_fem_ko$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

inner_mal_tam <- mal_tam %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_mal_tam$`Lipid Categories`<- factor(inner_mal_tam$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

inner_mal_ko <- mal_ko %>%
  group_by(`Lipid Categories`) %>%
  summarize(inner_total = sum(Mean)) %>%
  arrange(inner_total) %>%
  mutate(inner_cumsum = cumsum(inner_total) - 0.5 * inner_total)
inner_mal_ko$`Lipid Categories`<- factor(inner_mal_ko$`Lipid Categories`, levels = c("GPL","GL","SP","ST"))

# Preparing data for outer donut
outer_fem_tam <- fem_tam %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_fem_tam$rank.order <- c(11,18,15,10,17,9,8,14,13,7,19,6,16,5,4,12,3,2,1)

outer_fem_tam <- outer_fem_tam %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_fem_tam$Class<- factor(outer_fem_tam$Class, levels = c("PE ", "PE-O", "PC ", "PI ", "PC-O", "PG ", "LPC ", "PE-P", "LPE ", "LPE-O", "LPC-P", "TG ", "TG-O", "DG ", "DG-O","SM ", "Cer ","HexCer ", "CE "))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG " = "lightblue",
  "DG-O" = "cadetblue",
  "TG " = "steelblue3",
  "TG-O" = "cornflowerblue",
  "LPC-P" = "chocolate2",
  "LPE-O" = "lightcoral",
  "PC-O" = "lightsalmon1",
  "PE-O" = "burlywood1",
  "PE-P" = "goldenrod2",
  "LPC " = "sandybrown",
  "LPE " = "hotpink3",
  "PC " = "peachpuff",
  "PE " = "indianred3",
  "PI " = "indianred1",
  "PG " = "burlywood",
  "SM " = "plum",
  "HexCer " = "rosybrown1",
  "Cer " = "thistle",
  "CE " = "lightgoldenrod1"
)

# Plot
ggplot() +
  geom_bar(data = inner_fem_tam, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "Female Control Lipid Distribution Chart") +
  geom_text(data = inner_fem_tam, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_fem_tam, aes(x = 3, y = Mean, fill = Class), 
           stat = "identity", color = "black", linewidth = 0.1) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_fem_tam, aes(x = 3, y = outer_cumsum, label = Class), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="Female control donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="Female control donut chart_I.svg",width=9.42,height=5.82,units="in")

#############################################################
# Preparing data for outer donut
outer_fem_ko <- fem_ko %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_fem_ko$rank.order <- c(11,15,18,10,17,9,8,14,13,7,19,6,5,16,4,12,3,2,1)

outer_fem_ko <- outer_fem_ko %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_fem_ko$Class<- factor(outer_fem_ko$Class, levels = c("PE ", "PC ", "PE-O", "PI ", "PC-O", "PG ", "LPC ", "PE-P", "LPE ", "LPE-O", "LPC-P", "TG ", "TG-O", "DG ", "DG-O","SM ", "Cer ","HexCer ", "CE "))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG " = "lightblue",
  "DG-O" = "cadetblue",
  "TG " = "steelblue3",
  "TG-O" = "cornflowerblue",
  "LPC-P" = "chocolate2",
  "LPE-O" = "lightcoral",
  "PC-O" = "lightsalmon1",
  "PE-O" = "burlywood1",
  "PE-P" = "goldenrod2",
  "LPC " = "sandybrown",
  "LPE " = "hotpink3",
  "PC " = "peachpuff",
  "PE " = "indianred3",
  "PI " = "indianred1",
  "PG " = "burlywood",
  "SM " = "plum",
  "HexCer " = "rosybrown1",
  "Cer " = "thistle",
  "CE " = "lightgoldenrod1"
)

# Plot
ggplot() +
  geom_bar(data = inner_fem_ko, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "Female KO Lipid Distribution Chart") +
  geom_text(data = inner_fem_ko, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_fem_ko, aes(x = 3, y = Mean, fill = Class), 
           stat = "identity", color = "black", linewidth = 0.1) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_fem_ko, aes(x = 3, y = outer_cumsum, label = Class), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="Female KO donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="Female KO donut chart_I.svg",width=9.42,height=5.82,units="in")

#############################################################
# Preparing data for outer donut
outer_mal_tam <- mal_tam %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_mal_tam$rank.order <- c(11,15,18,10,17,9,8,14,13,7,19,6,16,5,4,12,3,2,1)

outer_mal_tam <- outer_mal_tam %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_mal_tam$Class<- factor(outer_mal_tam$Class, levels = c("PE ", "PC ", "PE-O", "PI ", "PC-O", "PG ", "LPC ", "PE-P", "LPE ", "LPE-O", "LPC-P", "TG ", "TG-O", "DG ", "DG-O","SM ", "Cer ","HexCer ", "CE "))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG " = "lightblue",
  "DG-O" = "cadetblue",
  "TG " = "steelblue3",
  "TG-O" = "cornflowerblue",
  "LPC-P" = "chocolate2",
  "LPE-O" = "lightcoral",
  "PC-O" = "lightsalmon1",
  "PE-O" = "burlywood1",
  "PE-P" = "goldenrod2",
  "LPC " = "sandybrown",
  "LPE " = "hotpink3",
  "PC " = "peachpuff",
  "PE " = "indianred3",
  "PI " = "indianred1",
  "PG " = "burlywood",
  "SM " = "plum",
  "HexCer " = "rosybrown1",
  "Cer " = "thistle",
  "CE " = "lightgoldenrod1"
)

# Plot
ggplot() +
  geom_bar(data = inner_mal_tam, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "male control Lipid Distribution Chart") +
  geom_text(data = inner_mal_tam, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_mal_tam, aes(x = 3, y = Mean, fill = Class), 
           stat = "identity", color = "black", linewidth = 0.1) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_mal_tam, aes(x = 3, y = outer_cumsum, label = Class), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="male control donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="male control donut chart_I.svg",width=9.42,height=5.82,units="in")

#############################################################
# Preparing data for outer donut
outer_mal_ko <- mal_ko %>%
  arrange(Mean) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)
outer_mal_ko$rank.order <- c(11,15,18,10,17,9,8,14,13,7,19,6,16,5,4,12,3,2,1)

outer_mal_ko <- outer_mal_ko %>%
  arrange(desc(rank.order)) %>%
  mutate(outer_cumsum = cumsum(Mean) - 0.5 * Mean)

outer_mal_ko$Class<- factor(outer_mal_ko$Class, levels = c("PE ", "PE-O", "PC ", "PI ", "PC-O", "PG ", "LPC ", "PE-P", "LPE ", "LPE-O", "LPC-P", "TG ", "TG-O", "DG ", "DG-O","SM ", "Cer ","HexCer ", "CE "))


# Define custom colors for Lipid Categories and Lipid Class
lipid_categories_colors <- c(
  "GL" = "dodgerblue4",
  "GPL" = "darkred",
  "SP" = "palevioletred4",
  "ST" = "lightgoldenrod3"
)

lipid_class_colors <- c(
  "DG " = "lightblue",
  "DG-O" = "cadetblue",
  "TG " = "steelblue3",
  "TG-O" = "cornflowerblue",
  "LPC-P" = "chocolate2",
  "LPE-O" = "lightcoral",
  "PC-O" = "lightsalmon1",
  "PE-O" = "burlywood1",
  "PE-P" = "goldenrod2",
  "LPC " = "sandybrown",
  "LPE " = "hotpink3",
  "PC " = "peachpuff",
  "PE " = "indianred3",
  "PI " = "indianred1",
  "PG " = "burlywood",
  "SM " = "plum",
  "HexCer " = "rosybrown1",
  "Cer " = "thistle",
  "CE " = "lightgoldenrod1"
)

# Plot
ggplot() +
  geom_bar(data = inner_mal_ko, aes( x= 2, y = inner_total, fill = `Lipid Categories`, group = `Lipid Categories`), 
           stat = "identity", color = "black", linewidth = 0.25) +
  theme_void() +
  theme(legend.position = "bottom") +
  labs(title = "male KO Lipid Distribution Chart") +
  geom_text(data = inner_mal_ko, aes( x = 2, y = inner_cumsum, label = `Lipid Categories`), color = "white", size = 4) +
  geom_bar(data = outer_mal_ko, aes(x = 3, y = Mean, fill = Class), 
           stat = "identity", color = "black", linewidth = 0.1) +
  coord_polar(theta = "y") +
  xlim(1, 4) +
  geom_text(data = outer_mal_ko, aes(x = 3, y = outer_cumsum, label = Class), color = "white", size = 3) +
  scale_fill_manual(values = c(lipid_categories_colors, lipid_class_colors))

ggsave(filename="male ko donut chart_I.pdf",width=9.42,height=5.82,units="in")
ggsave(filename="male ko donut chart_I.svg",width=9.42,height=5.82,units="in")

#########################################################################################
#########################################################################################
#########################################################################################
#TG and PC chain type - imported from LipidOne
fem_tg <- read.csv("Input/Female_TG chain type.csv", check.names = F)
fem_pc <- read.csv("Input/Female_PC chain type.csv", check.names = F)

mal_tg <- read.csv("Input/Male_TG chain type.csv", check.names = F)
mal_pc <- read.csv("Input/Male_PC chain type.csv", check.names = F)

# Get top chains by highest mean (averaged across groups if chain appears twice)
top_pc.f <- fem_pc %>%
  group_by(Chain) %>%
  summarise(overall_mean = mean(Mean, na.rm = TRUE)) %>%  
  slice_max(overall_mean, n = 10) %>%
  pull(Chain)
# Filter original data to keep only those top 10 chains
fem_pc.top <- fem_pc %>%
  filter(Chain %in% top_pc.f)

# Get top chains by highest mean (averaged across groups if chain appears twice)
top_pc.m <- mal_pc %>%
  group_by(Chain) %>%
  summarise(overall_mean = mean(Mean, na.rm = TRUE)) %>%  
  slice_max(overall_mean, n = 10) %>%
  pull(Chain)
# Filter original data to keep only those top 10 chains
mal_pc.top <- mal_pc %>%
  filter(Chain %in% top_pc.m)

# Get top chains by highest mean (averaged across groups if chain appears twice)
top_tg.m <- mal_tg %>%
  group_by(Chain) %>%
  summarise(overall_mean = mean(Mean, na.rm = TRUE)) %>%  
  slice_max(overall_mean, n = 5) %>%
  pull(Chain)
# Filter original data to keep only those top 5 chains
mal_tg.top <- mal_tg %>%
  filter(Chain %in% top_tg.m)

# Get top chains by highest mean (averaged across groups if chain appears twice)
top_tg.f <- fem_tg %>%
  group_by(Chain) %>%
  summarise(overall_mean = mean(Mean, na.rm = TRUE)) %>%  
  slice_max(overall_mean, n = 5) %>%
  pull(Chain)
# Filter original data to keep only those top 5 chains
fem_tg.top <- fem_tg %>%
  filter(Chain %in% top_tg.f)

write.csv(fem_pc.top,"Output/Female PC chain type.csv")
write.csv(fem_tg.top,"Output/Female TG chain type.csv")
write.csv(mal_pc.top,"Output/Male PC chain type.csv")
write.csv(mal_tg.top,"Output/Male TG chain type.csv")


#plotting the data
ggplot(fem_pc.top, aes(x = reorder(Chain, -Mean), y = Mean, fill = Group)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = " ", x = "Chain", y = "Mean Peak Area", fill = "Group") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        plot.title = element_text(hjust = 0.5, face = "bold"))













