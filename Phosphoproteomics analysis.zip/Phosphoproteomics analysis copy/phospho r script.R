#install_github("jokergoo/ComplexHeatmap")
library(ComplexHeatmap)
library(circlize)
library(gridtext)
library(scales)
library(emmeans)
library(multcomp)
#BiocManager::install("clusterProfiler")
library(clusterProfiler)
library(ggplot2)
library(tidyr)
library(ggrepel)
library(ggfortify)
library(ggforce)
library(extrafont)
extrafont::loadfonts()
#install.packages("cluster")
library(cluster)
library(factoextra)
library(tidyverse)
library(devtools)
library(readxl)
library(dplyr)
library(writexl)
library(Cairo)
#install.packages("Cairo")

#import phosphoproteomics data
phospho <- read.csv('Input/Phosphoproteomics data.csv', check.names = F)

#filter for sample columns
phospho1 <- phospho[c(63,1,2:52)]

# Remove "No_" from column names of prot1
colnames(phospho1) <- gsub("^No_", "", colnames(phospho1))

#remove".intensity" from column names
colnames(phospho1) <- gsub("\\.Intensity$", "", colnames(phospho1))

#import labelling key
lab <- read_excel("Input/Labelling Key.xlsx")
lab <- lab[c(1,4)]

# Reorder sample columns in ascending order
phospho1 <- phospho1[, c(1:2, order(colnames(phospho1)[3:53]) + 2)]

# Convert tube number column to character
lab$`Tube Number` <- as.character(lab$`Tube Number`)

# Replace matching column names in prot1
colnames(phospho1) <- sapply(colnames(phospho1), function(col) {
  match_index <- which(lab$`Tube Number` == col)
  if (length(match_index) > 0) {
    return(lab$Sample[match_index])
  } else {
    return(col)
  }
})

#rearrange columns
phospho1 <- phospho1[c(1,2,8:13,26:32,43:53,3:7,14:25,33:42)]


############ Normalize phosphoproteomics using proteomics abundance
#import phosphoproteomics data
prot <- read.csv('Input/Proteomics Dataset II.csv', check.names = F, row.names = 1)
prot <- prot[,-1]
phospho1 <- phospho1[phospho1$Genes != "" & !is.na(phospho1$Genes), ]
prot <- prot[prot$Genes != "" & !is.na(prot$Genes), ]

#Average duplicate gene rows
prot <- prot %>%
  group_by(Genes) %>%
  summarise(across(everything(), ~ if(is.numeric(.)) mean(., na.rm = TRUE) else first(.)))

# Merge the two data frames by the 'Gene' column
merged <- merge(phospho1, prot, by = "Genes", suffixes = c("_phospho", "_prot"))


# Subtract corresponding numeric columns (excluding 'Gene')
# This assumes the numeric columns start from column 2 onward
norm <- merged
norm[, -(1:2)] <- merged[, grep("_phospho$", colnames(merged))] - 
  merged[, grep("_prot$", colnames(merged))]

#call out only phospho columns
norm <- norm[c(1:53)]

#remove"_phospho" from column names
colnames(norm) <- gsub("\\_phospho$", "", colnames(norm))

#import phosphoproteomics data
pindex <- read.csv('Input/DDA-PASEF_results_table.csv', check.names = F)
pindex <- pindex[c(1,4)]

# merge by "name" to include phospho indez
norm <- merge(norm, pindex, by = "name")
norm <- norm[c(1,2,54,3:53)]

# merge by "name" to include phospho indez
phospho1 <- merge(phospho1, pindex, by = "name")
phospho1 <- phospho1[c(1,2,54,3:53)]

# merge by "name" to include phospho indez
merged <- merge(merged, pindex, by = "name")
#remove rows without phospho-site
merged <- merged %>% filter(!is.na(`Phospho Index`))
merged <- merged[-c(105)]

write.csv(phospho1, "Output/Phosphoproteomics Dataset II.csv")
write.csv(norm, "Output/Prot normalized_Phosphoproteomics Dataset.csv")

#########################################################################################################################
#########################################################################################################################
phospho1 <- read.csv("Output/Phosphoproteomics Dataset II.csv", row.names = 1, check.names = F)
#remove rows without phospho-site
phospho1 <- phospho1 %>% filter(!is.na(`Phospho Index`))
write.csv(phospho1, "Output/Filtered Phosphoproteomics Dataset II.csv")

norm <- read.csv("Output/Prot normalized_Phosphoproteomics Dataset.csv", row.names = 1, check.names = F)
#remove rows without phospho-site
norm <- norm %>% filter(!is.na(`Phospho Index`))
write.csv(norm, "Output/Filtered Prot normalized_Phosphoproteomics Dataset.csv")


#########################################################################################################################
#########################################################################################################################
################# Evaluate variance of ratio normalized method
norm <- read.csv("Output/Filtered Prot normalized_Phosphoproteomics Dataset II.csv", check.names = F, row.names = 1)
unorm <- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", check.names = F, row.names = 1)

#evaluate variance
var_raw <- unorm %>%
  pivot_longer(7:57, names_to = "Sample", values_to = "Intensity") %>%
  group_by(name) %>%
  summarise(variance = var(Intensity, na.rm = TRUE), dataset = "raw_phospho")

var_norm <- norm %>%
  pivot_longer(7:57, names_to = "Sample", values_to = "Intensity") %>%
  group_by(name) %>%
  summarise(variance = var(Intensity, na.rm = TRUE), dataset = "normalized")

# Compare distributions
bind_rows(var_raw, var_norm) %>%
  ggplot(aes(x = variance, fill = dataset)) +
  geom_density(alpha = 0.5) +
  scale_x_log10() +
  geom_vline(data = . %>% group_by(dataset) %>% summarise(med = median(variance, na.rm = TRUE)),
             aes(xintercept = med, color = dataset), linetype = "dashed", linewidth = 1) +
  labs(title = "Per-site variance: raw vs ratio-normalized",
       subtitle = "Dashed lines = median variance per dataset")

bind_rows(var_raw, var_norm) %>%
  group_by(dataset) %>%
  summarise(median = median(variance, na.rm = TRUE),
            p90    = quantile(variance, 0.9, na.rm = TRUE),
            p95    = quantile(variance, 0.95, na.rm = TRUE))

#slope check
slope_check <- merged %>%
  pivot_longer(cols = grep("_phospho$", colnames(merged)), names_to = "Sample", values_to = "phospho") %>%
  mutate(Sample = gsub("_phospho$", "", Sample)) %>%
  left_join(
    merged %>%
      pivot_longer(cols = grep("_prot$", colnames(merged)), names_to = "Sample", values_to = "protein") %>%
      mutate(Sample = gsub("_prot$", "", Sample)) %>%
      dplyr::select(Genes, Sample, protein),
    by = c("Genes", "Sample")
  ) %>%
  group_by(Genes) %>%
  summarise(slope = coef(lm(phospho ~ protein))[2],
            r2    = summary(lm(phospho ~ protein))$r.squared,
            n     = n())

# Distribution of slopes
ggplot(slope_check, aes(x = slope)) +
  geom_histogram(bins = 50, fill = "steelblue", color = "white") +
  geom_vline(xintercept = 1, linetype = "dashed", color = "red", linewidth = 1) +
  labs(title = "Phospho-protein slope per gene",
       subtitle = "Red dashed line = slope of 1 (ratio normalization assumption)",
       x = "Slope", y = "Count")

# Summary
slope_check %>%
  summarise(median_slope = median(slope, na.rm = TRUE),
            pct_near_1   = mean(abs(slope - 1) < 0.2, na.rm = TRUE))

# For each gene, compute correlation between phospho and protein across samples
cor_by_gene <- merged %>%
  pivot_longer(cols = grep("_phospho$", colnames(merged)), names_to = "Sample", values_to = "phospho") %>%
  mutate(Sample = gsub("_phospho$", "", Sample)) %>%
  left_join(
    merged %>%
      pivot_longer(cols = grep("_prot$", colnames(merged)), names_to = "Sample", values_to = "protein") %>%
      mutate(Sample = gsub("_prot$", "", Sample)) %>%
      dplyr::select(Genes, Sample, protein),
    by = c("Genes", "Sample")
  ) %>%
  group_by(Genes) %>%
  summarise(cor_pp = cor(phospho, protein, use = "complete.obs"))

ggplot(cor_by_gene, aes(x = cor_pp)) +
  geom_histogram(bins = 40) +
  geom_vline(xintercept = 0.5, linetype = "dashed", color = "red") +
  labs(title = "Phospho-protein correlation per gene",
       subtitle = "Correlation > 0.5 means normalization likely reduces variance",
       x = "Pearson r (phospho vs protein)")
#########################################################################################################################
########### HEAT MAP ################################
#mf1 <- read.csv("Output/Phosphoproteomics Dataset II.csv", row.names = 1, check.names = F)
mf1 <- read.csv("Output/Filtered Phosphoproteomics Dataset II.csv", row.names = 1, check.names = F)
#mf1 <- read.csv("Output/Prot normalized_Phosphoproteomics Dataset.csv", row.names = 1, check.names = F)

#removed Gene column
mf1 <- mf1[,-(2:3)]

m1 <- as.matrix(mf1)
m2 <- m1 [,2:52]
rownames(m2) <- mf1$name

#rename columns
m3 <- as.data.frame(m2) %>%
  mutate(across(1:51, as.numeric))

suffixes <- sub(".*?(\\(.*)", "\\1", colnames(m3))
group_ids <- match(suffixes, unique(suffixes))
letters <- ave(suffixes, suffixes, FUN = \(x) LETTERS[seq_along(x)])

colnames(m3) <- paste0(group_ids, letters)
#write.csv(m3, "Output/Heatmap data matrix.csv")

#calculate row z-score
m3.z <- t(scale(t(m3)))

m4 <- as.matrix(m3.z)
m4[is.na(m4)] <- 0

# plot heat maps

FnTam <- length(grep("1", colnames(m4)))
FnHet <- length(grep("2", colnames(m4)))
FnKO <- length(grep("3", colnames(m4)))
MnTam <- length(grep("4", colnames(m4)))
MnHet <- length(grep("5", colnames(m4)))
MnKO <- length(grep("6", colnames(m4)))



end_index_FnTam <- grep("1", colnames(m4)) [FnTam]
end_index_FnHet <- grep("2", colnames(m4)) [FnHet]
end_index_FnKO <- grep("3", colnames(m4)) [FnKO]
end_index_MnTam <- grep("4", colnames(m4)) [MnTam]
end_index_MnHet <- grep("5", colnames(m4)) [MnHet]
end_index_MnKO <- grep("6", colnames(m4)) [MnKO]


#row_order <- order(class_factor)

heatmap <- Heatmap(m4,
                   use_raster = F,
                   show_row_names = F,
                   show_column_names = F,
                   show_row_dend = TRUE,
                   show_column_dend = F,
                   
                   cluster_rows = TRUE,
                   #cluster_columns = T,
                   #row_order = row_order,
                   
                   clustering_distance_rows = "euclidean",
                   clustering_method_rows = "ward.D2",
                   
                   #row_order = rownames(m4),
                   row_names_side = "left",
                   row_names_gp = gpar(col = "black", fontsize = 8),
                   
                   row_dend_side = "left",
                   row_dend_width = unit(20, "mm"),
                   
                   column_names_side = "top",
                   column_dend_side = "bottom",
                   
                   col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                   
                   
                   column_order = 1:ncol(m4),
                   
                   height = unit(100, "mm"),
                   width = ncol(m4)*unit(3, "mm"),
                   
                   
                   top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                        height = unit(6, "mm"))),
                   border_gp = gpar(col = "black"), # set border color
                   
                   show_heatmap_legend = TRUE,
                   heatmap_legend_param = list(
                     title = "Z-score",
                     title_position = "topleft",
                     at = c(-3, 0, 3), # set ticks/numbers of legend
                     legend_height = unit(3, "cm")),
                   
                   #split = 4, # split the heatmap into separate blocks by hierarchical clustering
                   #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                   ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                   
                   layer_fun = function(j, i, x, y, width, height, fill) {
                     mat = restore_matrix(j, i, x, y)
                     
                     ind = unique(c(mat[, c(end_index_FnTam,
                                            end_index_FnHet,
                                            end_index_FnKO,
                                            end_index_MnTam,
                                            end_index_MnHet,
                                            end_index_MnKO
                     ) # enter the number where you want a gap between columns
                     ])) 
                     
                     grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                               y = y[ind], 
                               width = unit(0.03, "inches"), # width of the gap
                               height = unit(1/nrow(m4), "npc"),
                               gp = gpar(col = "white", fill = "white") # color of the gap
                     )
                   }
) 

draw(heatmap)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"


#Condition label 2
grid.rect(x = (end_index_FnTam )/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("F_Tam", 
          x = (end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("F_Het", 
          x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("F_KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 8
grid.rect(x = (end_index_MnTam + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_Tam", 
          x = (end_index_MnTam + end_index_FnKO)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))


#Condition label 11
grid.rect(x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("M_Het", 
          x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))

#Condition label 12
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("M_KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))
## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnKO/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
# step 4 - end by closing the saved file

pdf(file = 'Figures/Heart Phosphoproteomics_filt.pdf',
    width = 12, 
    height = 12)


CairoSVG(file = "Figures/Heart Phosphoproteomics_filt.svg", width = 12, height = 12)

#step 2 - draw heatmap in the saved file
draw(heatmap)

dev.off()

######################################################################################
######################################################################################
################### Plot Males and Females separately #################################
#Split data frame into males and females
m3.f <- m3[, grepl("1|2|3", colnames(m3))]
m3.m <- m3[, grepl("4|5|6", colnames(m3))]

############females
#calculate row z-score
m3.z <- t(scale(t(m3.f)))

m4 <- as.matrix(m3.z)

# plot heat maps

FnTam <- length(grep("1", colnames(m4)))
FnHet <- length(grep("2", colnames(m4)))
FnKO <- length(grep("3", colnames(m4)))

end_index_FnTam <- grep("1", colnames(m4)) [FnTam]
end_index_FnHet <- grep("2", colnames(m4)) [FnHet]
end_index_FnKO <- grep("3", colnames(m4)) [FnKO]


heatmap.f <- Heatmap(m4,
                     use_raster = F,
                     show_row_names = F,
                     show_column_names = F,
                     show_row_dend = TRUE,
                     show_column_dend = F,
                     
                     cluster_rows = TRUE,
                     #cluster_columns = T,
                     #row_order = row_order,
                     
                     clustering_distance_rows = "euclidean",
                     clustering_method_rows = "ward.D2",
                     
                     #row_order = rownames(m4),
                     row_names_side = "left",
                     row_names_gp = gpar(col = "black", fontsize = 8),
                     
                     row_dend_side = "left",
                     row_dend_width = unit(20, "mm"),
                     
                     column_names_side = "top",
                     column_dend_side = "bottom",
                     
                     col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                     
                     
                     column_order = 1:ncol(m4),
                     
                     height = unit(100, "mm"),
                     width = ncol(m4)*unit(3, "mm"),
                     
                     
                     top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                          height = unit(6, "mm"))),
                     border_gp = gpar(col = "black"), # set border color
                     
                     show_heatmap_legend = TRUE,
                     heatmap_legend_param = list(
                       title = "Z-score",
                       title_position = "topleft",
                       at = c(-3, 0, 3), # set ticks/numbers of legend
                       legend_height = unit(3, "cm")),
                     
                     #split = 2, # split the heatmap into separate blocks by hierarchical clustering
                     #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                     ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                     
                     layer_fun = function(j, i, x, y, width, height, fill) {
                       mat = restore_matrix(j, i, x, y)
                       
                       ind = unique(c(mat[, c(end_index_FnTam,
                                              end_index_FnHet,
                                              end_index_FnKO
                       ) # enter the number where you want a gap between columns
                       ])) 
                       
                       grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                 y = y[ind], 
                                 width = unit(0.03, "inches"), # width of the gap
                                 height = unit(1/nrow(m4), "npc"),
                                 gp = gpar(col = "white", fill = "white") # color of the gap
                       )
                     }
) 

draw(heatmap.f)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"


#Condition label 2
grid.rect(x = (end_index_FnTam )/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("F_Tam", 
          x = (end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("F_Het", 
          x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("F_KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 


## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

# step 4 - end by closing the saved file

pdf(file = 'Figures/Female Heart Proteomics_filt.pdf',
    width = 12, 
    height = 12)


CairoSVG(file = "Figures/Female Heart Proteomics_filt.svg", width = 12, height = 12)

#step 2 - draw heatmap in the saved file
draw(heatmap.f)

dev.off()


############Males
#calculate row z-score
m3.z <- t(scale(t(m3.m)))

m4 <- as.matrix(m3.z)

# plot heat maps

MnTam <- length(grep("4", colnames(m4)))
MnHet <- length(grep("5", colnames(m4)))
MnKO <- length(grep("6", colnames(m4)))

end_index_MnTam <- grep("4", colnames(m4)) [MnTam]
end_index_MnHet <- grep("5", colnames(m4)) [MnHet]
end_index_MnKO <- grep("6", colnames(m4)) [MnKO]


heatmap.m <- Heatmap(m4,
                     use_raster = F,
                     show_row_names = F,
                     show_column_names = F,
                     show_row_dend = TRUE,
                     show_column_dend = F,
                     
                     cluster_rows = TRUE,
                     #cluster_columns = T,
                     #row_order = row_order,
                     
                     clustering_distance_rows = "euclidean",
                     clustering_method_rows = "ward.D2",
                     
                     #row_order = rownames(m4),
                     row_names_side = "left",
                     row_names_gp = gpar(col = "black", fontsize = 8),
                     
                     row_dend_side = "left",
                     row_dend_width = unit(20, "mm"),
                     
                     column_names_side = "top",
                     column_dend_side = "bottom",
                     
                     col = colorRamp2(c(-2,0,2), c("darkblue", "white", "firebrick4")),
                     
                     
                     column_order = 1:ncol(m4),
                     
                     height = unit(100, "mm"),
                     width = ncol(m4)*unit(3, "mm"),
                     
                     
                     top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                          height = unit(6, "mm"))),
                     border_gp = gpar(col = "black"), # set border color
                     
                     show_heatmap_legend = TRUE,
                     heatmap_legend_param = list(
                       title = "Z-score",
                       title_position = "topleft",
                       at = c(-3, 0, 3), # set ticks/numbers of legend
                       legend_height = unit(3, "cm")),
                     
                     #split = 2, # split the heatmap into separate blocks by hierarchical clustering
                     #row_km = 4, # or split the heatmap into separate blocks by k-means clustering
                     ## determine the number of clusters: https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
                     
                     layer_fun = function(j, i, x, y, width, height, fill) {
                       mat = restore_matrix(j, i, x, y)
                       
                       ind = unique(c(mat[, c(end_index_MnTam,
                                              end_index_MnHet,
                                              end_index_MnKO
                       ) # enter the number where you want a gap between columns
                       ])) 
                       
                       grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                 y = y[ind], 
                                 width = unit(0.03, "inches"), # width of the gap
                                 height = unit(1/nrow(m4), "npc"),
                                 gp = gpar(col = "white", fill = "white") # color of the gap
                       )
                     }
) 

draw(heatmap.m)


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"


#Condition label 2
grid.rect(x = (end_index_MnTam )/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_Tam", 
          x = (end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#b57c76",
                    col = "#b57c76"
          )
)
grid.text("M_Het", 
          x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#5D94A5",
                    col = "#5D94A5"
          )
)
grid.text("M_KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 


## Top label gaps
#Vertical lines
grid.rect(x = end_index_MnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

# step 4 - end by closing the saved file

pdf(file = 'Figures/Male Heart Phospho Proteomics_filt.pdf',
    width = 12, 
    height = 12)


CairoSVG(file = "Figures/Male Heart Phospho Proteomics_filt.svg", width = 12, height = 12)

#step 2 - draw heatmap in the saved file
draw(heatmap.m)

dev.off()
######################################################################################
######################################################################################
phos.f <- read.csv("Output/Filtered Phosphoproteomics Dataset II.csv", row.names = 1, check.names = F)
phos <- read.csv("Output/Phosphoproteomics Dataset II.csv", check.names = F, row.names = 1) 
#phos.n <- read.csv("Output/Prot normalized_Phosphoproteomics Dataset.csv", check.names = F, row.names = 1) 
phos.n <- read.csv("Output/Filtered Prot normalized_Phosphoproteomics Dataset.csv", check.names = F, row.names = 1) 

phos <- phos %>%
  separate(`Phospho Index`, into = c("Protein", "Site"), sep = "_", remove = FALSE)
phos <- phos %>%
  mutate(`Phospho Site` = ifelse(is.na(Site), 
                                  NA, 
                                  paste(Genes, Site, sep = "_")))
phos <- phos[c(1, 57, 2:56)]


phos.f <- phos.f %>%
  separate(`Phospho Index`, into = c("Protein", "Site"), sep = "_", remove = FALSE)
phos.f <- phos.f %>%
  unite("Phospho Site", Genes, Site, sep = "_", remove = FALSE)


phos.n <- phos.n %>%
  separate(`Phospho Index`, into = c("Protein", "Site"), sep = "_", remove = FALSE)
phos.n <- phos.n %>%
  mutate(`Phospho Site` = ifelse(is.na(Site), 
                                 NA, 
                                 paste(Genes, Site, sep = "_")))
phos.n <- phos.n[c(1, 57, 2:56)]

write.csv(phos, "Output/Phosphoproteomics Dataset III.csv")
write.csv(phos.n, "Output/Filtered Prot normalized_Phosphoproteomics Dataset II.csv")
write.csv(phos.f, "Output/Filtered Phosphoproteomics Dataset III.csv")
######################################################################################
################### Princiipal Component Analysis (PCA) ##############################
#PCA plot

#Loading required packages
library(cluster)
library(factoextra)
library(RColorBrewer)

#Loading both normalized and unnormalized dataset
#phos <- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", row.names = 1, check.names = F)
#phos <- read.csv("Output/Phosphoproteomics Dataset II.csv", check.names = F, row.names = 1) #unnormalized
#phos.n <- read.csv("Output/Prot normalized_Phosphoproteomics Dataset.csv", check.names = F, row.names = 1) #normalized
phos <- read.csv("Output/Filtered Prot normalized_Phosphoproteomics Dataset II.csv", row.names = 1, check.names = F)


#remove genotype and sex info from column name
colnames(phos) <- sub("_.*", "", colnames(phos))
#colnames(phos.n) <- sub("_.*", "", colnames(phos.n))

#remove gene and phosphoindex column
phos <- phos[-c(1,3:6)]
#phos.n <- phos.n[-c(2:3)]

# Replace NA values with one-fifth of the smallest value in the same row (excluding first column)
phos[,-1] <- t(apply(phos[,-1], 1, function(row) {
  row[is.na(row)] <- min(row, na.rm = TRUE) / 5
  row
}))

#phos.n[,-1] <- t(apply(phos.n[,-1], 1, function(row) {
#  row[is.na(row)] <- min(row, na.rm = TRUE) / 5
#  row
#}))

           
# Extract the first column as column names
col_phos <- phos[, 1]
#col_phos.n <- phos.n[, 1]

# Transpose the dataframe and set column names
transform_phos <- t(phos[,-1])
colnames(transform_phos) <- col_phos

#transform_phos.n <- t(phos.n[,-1])
#colnames(transform_phos.n) <- col_phos.n


# Converting matrix to data frame
transform_phos <- as.data.frame(transform_phos)
#transform_phos.n <- as.data.frame(transform_phos.n)

#Loading labelling key
lab <- read_excel("Input/Labelling Key II.xlsx")

#merge labelling key to lipidomics data
transform_phos$Sample <- rownames(transform_phos)
#transform_phos.n$Sample <- rownames(transform_phos.n)

# Then, merge by "Sample"
transform_phos <- merge(lab, transform_phos, by = "Sample")
#transform_phos.n <- merge(lab, transform_phos.n, by = "Sample")

#reorder dataframe
transform_phos <- transform_phos[order(transform_phos$Sex, transform_phos$Genotype), ]
#transform_phos.n <- transform_phos.n[order(transform_phos.n$Sex, transform_phos.n$Genotype), ]

#write.csv(transform_phos, "Output/Log2 phosphoproteomics_wide.csv")
#write.csv(transform_phos.n, "Output/Log2 prot norm_phosphoproteomics_wide.csv")
#write.csv(transform_phos, "Output/Filtered Log2 phosphoproteomics_wide.csv")
write.csv(transform_phos, "Output/Filtered Prot norm Log2 phosphoproteomics_wide.csv")

df1 <- transform_phos
#df2 <- transform_phos.n
######################Plotting PCA##################################
pca_plot <- prcomp(df1[,-(1:3)], scale. = TRUE)

# Define your custom colors for each Genotype
genotype_colors <- c(
  "KO" = "#5D94A5",
  "Tam" = "#B5A6B0",
  "HET" = "#b57c76")

# Plot with manual color and shape mapping
autoplot(pca_plot, data = df1, colour = 'Genotype', shape = 'Sex', size = 3) +
  theme_bw() +
  scale_colour_manual(values = genotype_colors) +
  scale_shape_manual(values = c("F" = 16, "M" = 17, "QC" = 15)) +  
  ggtitle("Heart Proteomics") +
  guides(colour = guide_legend(title = "Genotype"),
         shape = guide_legend(title = "Sex"))


# Save plot
ggsave(filename = "Heart Phospho Proteomics.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Phospho Proteomics.svg",width=5.98,height=4.36,units="in")

###################
pca_plot <- prcomp(df2[,-(1:3)], scale. = TRUE)

# Define your custom colors for each Genotype
genotype_colors <- c(
  "KO" = "#5D94A5",
  "Tam" = "#B5A6B0",
  "HET" = "#b57c76")

# Plot with manual color and shape mapping
autoplot(pca_plot, data = df1, colour = 'Genotype', shape = 'Sex', size = 3) +
  theme_bw() +
  scale_colour_manual(values = genotype_colors) +
  scale_shape_manual(values = c("F" = 16, "M" = 17, "QC" = 15)) +  
  ggtitle("Heart Proteomics") +
  guides(colour = guide_legend(title = "Genotype"),
         shape = guide_legend(title = "Sex"))


# Save plot
ggsave(filename = "Heart Phospho Proteomics_norm.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Phospho Proteomics_norm.svg",width=5.98,height=4.36,units="in")

######################################################################################
######################################################################################
################### PLS-DA ##########################################################
# Install and load required packages
#BiocManager::install("mixOmics")
library(mixOmics)

##################################### Sex and Genotype as response variable
#df2 <- read.csv("Output/Filtered Log2 phosphoproteomics_wide.csv", check.names = F, row.names = 1)

df2 <- read.csv("Output/Filtered Prot norm Log2 phosphoproteomics_wide.csv", check.names = F, row.names = 1)


#remove HET groups so one can better visualize male and female controls/KO
df2 <- df2 %>%
  filter(!grepl("HET", Genotype))

#combine sex and genotype columns into a single column
df2 <- df2 %>%
  mutate(Groups = paste(Sex, Genotype, sep = "_"))

#rearrange columns
df2 <- df2[c(1:3,3597,4:3596)]

X <- df2[, 5:3597]  # predictors
Y <- as.factor(df2[, 4])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Protein = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
write.csv(vip_filtered, "Output/PLSDA VIP_Sex and Genotype response variable.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Phosphoproteomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 14%` = scores[, 1],`X-Variate2: 6%` = scores[, 2],Group = Y, check.names = F) 
df_scores$Sex <- df2$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 14%`, y = `X-Variate2: 6%`, color = Group)) +
  geom_point(aes(shape = df2$Sex), size = 3, alpha = 0.9) +  # Shape mapped here only
  stat_ellipse(type = "norm", linewidth = 0.5) +             # Ellipses by Group only
  scale_color_manual(values = c("#ffb380ff", "#dc5e0b", "#8dd35fff", "#3E7F64")) +
  scale_shape_manual(values = c("F" = 16, "M" = 17)) +
  theme_bw(base_size = 14) +  # Sets a larger base font size for the whole plot
  theme(
    axis.title = element_text(size = 14),     # Axis labels
    axis.text  = element_text(size = 14),   # Axis tick labels
    legend.title = element_text(size = 14),   # Legend title
    legend.text  = element_text(size = 14),                  # Legend items
  ) +
  labs(title = "Heart Phosphoproteomics PLS-DA", shape = "Sex")

# Create plot with custom point shape and ellipse line width
ggplot(df_scores,aes(x=`X-Variate1: 14%`,y=`X-Variate2: 6%`))+
  geom_point(aes(fill=Group),shape=21,size=3,alpha=0.85,stroke=0.5,color="black")+
  stat_ellipse(aes(color=Group),type="norm",linewidth=0.4)+
  scale_color_manual(values=c("#359099","black","#AA4611","grey50"))+
  scale_fill_manual(values=c("#359099","white","#AA4611","grey"))+
  theme_bw(base_size=14)+
  theme(
    legend.position="none",
    panel.grid=element_blank(),
    axis.title=element_text(size=14),
    axis.text=element_text(size=14)
  )+
  labs(title="")

# Save plot
#ggsave(filename = "Heart Phosphoproteomics PLSDA_Sex and Genotype.pdf", width = 5, height = 4.75, units = "in")
ggsave(filename = "Heart Phosphoproteomics PLSDA_Sex and Genotype_norm.pdf", width = 5, height = 4.75, units = "in")
#ggsave(filename="Heart Phosphoproteomics PLSDA_Sex and Genotype.svg",width=5,height=4.75,units="in")











##################################### Genotype as response variable unnormalized
df1 <- read.csv("Output/Filtered Log2 phosphoproteomics_wide.csv", check.names = F, row.names = 1)
X <- df1[, 4:4546]  # predictors
Y <- as.factor(df1[, 3])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Phos = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
#write.csv(vip_filtered, "Output/PLSDA VIP_Genotype response variable.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Phosphoproteomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 21%` = scores[, 1],`X-Variate2: 5%` = scores[, 2],Group = Y, check.names = F) 
df_scores$Sex <- df1$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 21%`, y = `X-Variate2: 5%`, color = Group)) +
  geom_point(aes(shape = df1$Sex), size = 3, alpha = 0.9) +  # Shape mapped here only
  stat_ellipse(type = "norm", linewidth = 0.5) +             # Ellipses by Group only
  scale_color_manual(values = c("#7CD8AD", "#1C4649", "#B5A6B0")) +
  scale_shape_manual(values = c("F" = 16, "M" = 17)) +
  theme_bw(base_size = 14) +  # Sets a larger base font size for the whole plot
  theme(
    axis.title = element_text(size = 14),     # Axis labels
    axis.text  = element_text(size = 14),   # Axis tick labels
    legend.title = element_text(size = 14),   # Legend title
    legend.text  = element_text(size = 14),                  # Legend items
  ) +
  labs(title = "Heart Phospho Proteomics PLS-DA", shape = "Sex")


# Save plot
ggsave(filename = "Filtered Heart Phospho Proteomics PLSDA_Genotype.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Filtered Heart Phospho Proteomics PLSDA_Genotype.svg",width=5.98,height=4.36,units="in")

##################################### Normalized
X <- df2[, 4:7429]  # predictors
Y <- as.factor(df2[, 3])  # response variable (class)

# Run PLS-DA
plsda_result <- plsda(X, Y, ncomp = 2)  # use 2 components, adjust as needed
#obtain VIP scores
vip_scores <- vip(plsda_result)
vip_scores <- data.frame(Protein = rownames(vip_scores), vip_scores, row.names = NULL)

#filter for lipids most important to the model
vip_filtered <- vip_scores[vip_scores$comp1 >= 1, ]

#reorder dataframe
vip_filtered <- vip_filtered[order(-vip_filtered$comp1), ]
write.csv(vip_filtered, "Output/PLSDA VIP_Genotype response variable_norm.csv")

# Plot with manual color and shape
plotIndiv(plsda_result,
          comp = c(1, 2),
          group = Y,
          ind.names = FALSE,
          ellipse = TRUE,
          #col = custom_colors,
          #pch = custom_shapes,
          lwd = 0.25,
          legend = TRUE,
          title = "Heart Lipidomics PLS-DA")

# Extract scores (coordinates for individuals)
scores <- plsda_result$variates$X
df_scores <- data.frame(`X-Variate1: 13%` = scores[, 1],`X-Variate2: 6%` = scores[, 2],Group = Y, check.names = F) 
df_scores$Sex <- df2$Sex  

# Create plot with custom point shape and ellipse line width
ggplot(df_scores, aes(x = `X-Variate1: 13%`, y = `X-Variate2: 6%`, color = Group)) +
  geom_point(aes(shape = df2$Sex), size = 3, alpha = 0.9) +  # Shape mapped here only
  stat_ellipse(type = "norm", linewidth = 0.5) +             # Ellipses by Group only
  scale_color_manual(values = c("#b57c76", "#5D94A5", "#B5A6B0")) +
  scale_shape_manual(values = c("F" = 16, "M" = 17)) +
  theme_bw() +
  theme(legend.title = element_text(size = 12)) +
  labs(title = "Heart Phospho Proteomics PLS-DA", shape = "Sex")


# Save plot
ggsave(filename = "Heart Phospho Proteomics PLSDA_Genotype_norm.pdf", width = 5.98, height = 4.36, units = "in")
ggsave(filename="Heart Phospho Proteomics PLSDA_Genotype_norm.svg",width=5.98,height=4.36,units="in")

################################################################################
################################################################################
#import of data
vip <- read.csv("Output/PLSDA VIP_Sex and Genotype response variable.csv", row.names = 1)
stat <- read.csv("Output/Filt norm Limma phospho results_F KOvTam.csv")

#change protein.names to match VIP list
names(vip)[names(vip) == "Protein"] <- "Phospho.Site"

#merge in logFC from stat 
vips <- merge(vip, stat[, c("Phospho.Site", "logFC", "adj.P.Val")], by = "Phospho.Site")

#set logFC to NA for non-significant proteins so they render as a fixed color
vips <- vips %>%
  mutate(logFC_plot = ifelse(adj.P.Val < 0.05, logFC, NA))

#Identify the top 40 vips
strong_vip <- vips %>%
  arrange(-comp1) %>%
  slice_head(n = 20) 


# Reorder Description based on comp1
strong_vip <- strong_vip %>%
  mutate(Phospho.Site = factor(Phospho.Site, levels = Phospho.Site[order(comp1, decreasing = F)]))

p.vip <- ggplot(strong_vip, aes(x = comp1, y = Phospho.Site, fill = logFC_plot)) +
  geom_point(size = 3, shape = 21, color = "black", stroke = 0.2) +
  scale_fill_gradient2(
    low = "blue", mid = "white", high = "red4", midpoint = 0,
    na.value = "white",
    name = "logFC"
  ) +
  theme_bw(base_size = 12) +
  ylab(NULL) +
  xlab("VIP Score") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 12),
    axis.text.x = element_text(colour = "black", size = 12),
    strip.text = element_text(colour = "black"),
    legend.position = "right"
  )
p.vip
ggsave(filename="vip dotplot_Sex and Genotype response_norm.pdf",width=3.5,height=4.36,units="in")
ggsave(filename="vip dotplot_Genotype response_norm.svg",width=4,height=4.36,units="in")
################################################################################
################################################################################
df <- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", check.names = F, row.names = 1) 
df<- df[-c(1,3:6)]

#import missingness female stat data
df.f <- read.csv("Output/Missingness Test Female KOvTam.csv", check.names = F, row.names = 1)
#filter out sig hits
df.f <- df.f %>% filter (barnard_p_value < 0.05)

#import missingness male stat data
df.m <- read.csv("Output/Missingness Test Male KOvTam.csv", check.names = F, row.names = 1)
#filter out sig hits
df.m <- df.m %>% filter (barnard_p_value < 0.05)

#convert row names to column
df.f$`Phospho Site` <- rownames(df.f)
rownames(df.f) <- NULL
df.m$`Phospho Site` <- rownames(df.m)
rownames(df.m) <- NULL

#split dataframes into male and females
female <- df[c(1:25)]
male <- df[c(1,26:52)]

#filter the datasheet for rows that are matched between sig hits from missingness test
female_filt <- female[female$`Phospho Site` %in% df.f$`Phospho Site`, ]
male_filt <- male[male$`Phospho Site` %in% df.m$`Phospho Site`, ]

write.csv(female_filt, "Output/Phospho Female Extreme Filtered.csv", row.names = F)
write.csv(male_filt, "Output/Phospho Male Extreme Filtered.csv", row.names = F)

m3.m <- read.csv("Input/Phospho Male Extreme Filtered_rd.csv", check.names = F)
m3.f <- read.csv("Input/Phospho Female Extreme Filtered_rd.csv", check.names = F)

# Define columns for each group (adjust names as needed)
group1_cols <- colnames(df.f)[1:2]
group2_cols <- colnames(df.f)[3:4]

# Identify the ".absent" columns in each group
group1_absent <- grep("\\.absent$", group1_cols, value = TRUE)
group2_absent <- grep("\\.absent$", group2_cols, value = TRUE)

# Sum across groups and filter
result.f <- df.f %>%
  mutate(
    group1_total = rowSums(across(all_of(group1_cols)), na.rm = TRUE),
    group2_total = rowSums(across(all_of(group2_cols)), na.rm = TRUE),
    group1_absent_sum = rowSums(across(all_of(group1_absent)), na.rm = TRUE),
    group2_absent_sum = rowSums(across(all_of(group2_absent)), na.rm = TRUE),
    group1_absent_pct = group1_absent_sum / group1_total,
    group2_absent_pct = group2_absent_sum / group2_total
  ) %>%
  filter(group1_absent_pct >= 0.7 | group2_absent_pct >= 0.7)

# Define columns for each group (adjust names as needed)
group1_cols <- colnames(df.m)[1:2]
group2_cols <- colnames(df.m)[3:4]

# Identify the ".absent" columns in each group
group1_absent <- grep("\\.absent$", group1_cols, value = TRUE)
group2_absent <- grep("\\.absent$", group2_cols, value = TRUE)

# Sum across groups and filter
result.m <- df.m %>%
  mutate(
    group1_total = rowSums(across(all_of(group1_cols)), na.rm = TRUE),
    group2_total = rowSums(across(all_of(group2_cols)), na.rm = TRUE),
    group1_absent_sum = rowSums(across(all_of(group1_absent)), na.rm = TRUE),
    group2_absent_sum = rowSums(across(all_of(group2_absent)), na.rm = TRUE),
    group1_absent_pct = group1_absent_sum / group1_total,
    group2_absent_pct = group2_absent_sum / group2_total
  ) %>%
  filter(group1_absent_pct >= 0.7 | group2_absent_pct >= 0.7)

#filter the datasheet for rows that are matched between sig hits from missingness test
m3.f <- m3.f[m3.f$`Phospho Site` %in% result.f$`Phospho Site`, ]
m3.m <- m3.m[m3.m$`Phospho Site` %in% result.m$`Phospho Site`, ]



#rename the columns
suffixes <- sub(".*?(\\(.*)", "\\1", colnames(m3.f)[-1])
group_ids <- match(suffixes, unique(suffixes))
letters <- ave(suffixes, suffixes, FUN = \(x) LETTERS[seq_along(x)])
colnames(m3.f)[-1] <- paste0(group_ids, letters)


suffixes <- sub(".*?(\\(.*)", "\\1", colnames(m3.m)[-1])
group_ids <- match(suffixes, unique(suffixes))
letters <- ave(suffixes, suffixes, FUN = \(x) LETTERS[seq_along(x)])
colnames(m3.m)[-1] <- paste0(group_ids, letters)

################### Plot Males and Females separately #################################


############females
m3.f1 <- as.matrix(m3.f)
m3.f2 <- m3.f [,2:25]
rownames(m3.f2) <- m3.f$`Phospho Site`

m4 <- as.matrix(m3.f2)


# plot heat maps

FnTam <- length(grep("1", colnames(m4)))
FnHet <- length(grep("2", colnames(m4)))
FnKO <- length(grep("3", colnames(m4)))

end_index_FnTam <- grep("1", colnames(m4)) [FnTam]
end_index_FnHet <- grep("2", colnames(m4)) [FnHet]
end_index_FnKO <- grep("3", colnames(m4)) [FnKO]

heatmap.f <- Heatmap(m4,
                     use_raster = F,
                     show_row_names = T,
                     show_column_names = F,
                     show_row_dend = F,
                     show_column_dend = F,
                     
                     cluster_rows = F,
                     #clustering_distance_rows = "euclidean",
                     #clustering_method_rows = "ward.D2",
                     
                     row_names_side = "left",
                     row_names_gp = gpar(col = "black", fontsize = 10),
                     
                     row_dend_side = "left",
                     row_dend_width = unit(20, "mm"),
                     
                     column_names_side = "top",
                     column_dend_side = "bottom",
                     
                     col = colorRamp2(c(14,17), c("moccasin", "navajowhite3")),
                     
                     column_order = 1:ncol(m4),
                     
                     height = unit(100, "mm"),
                     width = ncol(m4)*unit(3, "mm"),
                     
                     top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                          height = unit(6, "mm"))),
                     border_gp = gpar(col = "black"), 
                     
                     show_heatmap_legend = TRUE,
                     heatmap_legend_param = list(
                       title = "Log Abundance",
                       title_position = "topleft",
                       at = c(10, 20),
                       legend_width = unit(3, "cm"),
                       direction = "horizontal"),
                     
                     layer_fun = function(j, i, x, y, width, height, fill) {
                       mat = restore_matrix(j, i, x, y)
                       
                       # draw each heatmap cell with a thin black border
                       grid.rect(x = x, y = y, 
                                 width = width, height = height, 
                                 gp = gpar(fill = fill, col = "black", lwd = 0.2))
                       
                       # add white vertical gaps between selected groups
                       ind = unique(c(mat[, c(end_index_FnTam, end_index_FnHet)]))
                       grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                 y = y[ind], 
                                 width = unit(0.03, "inches"), 
                                 height = unit(1/nrow(m4), "npc"),
                                 gp = gpar(col = "white", fill = "white"))
                     }
)

draw(heatmap.f, heatmap_legend_side = "bottom")

#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"


#Condition label 2
grid.rect(x = (end_index_FnTam )/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("CreTam", 
          x = (end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#7CD8AD",
                    col = "#7CD8AD"
          )
)
grid.text("Het", 
          x = (end_index_FnHet + end_index_FnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (FnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#1C4649",
                    col = "#1C4649"
          )
)
grid.text("KO", 
          x = (end_index_FnKO + end_index_FnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 


## Top label gaps
#Vertical lines
grid.rect(x = end_index_FnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_FnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

# step 4 - end by closing the saved file

pdf(file = 'Figures/Female phospho extreme filt.pdf',
    width = 12, 
    height = 24)


CairoSVG(file = "Figures/Female phospho extreme filt.svg", width = 12, height = 24)

#step 2 - draw heatmap in the saved file
#draw(heatmap.f)

dev.off()


############Males
m3.m1 <- as.matrix(m3.m)
m3.m2 <- m3.m [,2:28]
rownames(m3.m2) <- m3.m$`Phospho Site`

m4 <- as.matrix(m3.m2)


# plot heat maps

MnTam <- length(grep("1", colnames(m4)))
MnHet <- length(grep("2", colnames(m4)))
MnKO <- length(grep("3", colnames(m4)))

end_index_MnTam <- grep("1", colnames(m4)) [MnTam]
end_index_MnHet <- grep("2", colnames(m4)) [MnHet]
end_index_MnKO <- grep("3", colnames(m4)) [MnKO]


heatmap.m <- Heatmap(m4,
                     use_raster = F,
                     show_row_names = T,
                     show_column_names = F,
                     show_row_dend = F,
                     show_column_dend = F,
                     
                     cluster_rows = F,
                     #clustering_distance_rows = "euclidean",
                     #clustering_method_rows = "ward.D2",
                     
                     row_names_side = "left",
                     row_names_gp = gpar(col = "black", fontsize = 10),
                     
                     row_dend_side = "left",
                     row_dend_width = unit(20, "mm"),
                     
                     column_names_side = "top",
                     column_dend_side = "bottom",
                     
                     col = colorRamp2(c(14,17), c("moccasin", "navajowhite3")),
                     
                     column_order = 1:ncol(m4),
                     
                     height = unit(100, "mm"),
                     width = ncol(m4)*unit(3, "mm"),
                     
                     top_annotation = columnAnnotation(empty = anno_empty(border = FALSE,
                                                                          height = unit(6, "mm"))),
                     border_gp = gpar(col = "black"), 
                     
                     show_heatmap_legend = TRUE,
                     heatmap_legend_param = list(
                       title = "Log Abundance",
                       title_position = "topleft",
                       at = c(10, 20),
                       legend_width = unit(3, "cm"),
                       direction = "horizontal"),
                     
                     layer_fun = function(j, i, x, y, width, height, fill) {
                       mat = restore_matrix(j, i, x, y)
                       
                       # draw each heatmap cell with a thin black border
                       grid.rect(x = x, y = y, 
                                 width = width, height = height, 
                                 gp = gpar(fill = fill, col = "black", lwd = 0.2))
                       
                       # add white vertical gaps between selected groups
                       ind = unique(c(mat[, c(end_index_MnTam, end_index_MnHet)]))
                       grid.rect(x = x[ind] + unit(0.5/ncol(m4), "npc"), 
                                 y = y[ind], 
                                 width = unit(0.03, "inches"), 
                                 height = unit(1/nrow(m4), "npc"),
                                 gp = gpar(col = "white", fill = "white"))
                     }
)

draw(heatmap.m, heatmap_legend_side = "bottom")


#step 3 - draw the labeling on the heatmap in the saved file

# labeling heatmap
list_components() # get the viewport names
seekViewport("annotation_empty_1") # seek the empty space we saved at the top of heatmap, called "annotation_empty_1"


#Condition label 2
grid.rect(x = (end_index_MnTam )/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnTam)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#B5A6B0",
                    col = "#B5A6B0"
          )
)
grid.text("M_Ctrl", 
          x = (end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black"))



#Condition label 5
grid.rect(x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnHet)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#7CD8AD",
                    col = "#7CD8AD"
          )
)
grid.text("M_Het", 
          x = (end_index_MnHet + end_index_MnTam)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 

#Condition label 6
grid.rect(x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 0,
          width = (MnKO)/ncol(m4),  # the width of DN
          height = 1,
          just = c("center", "bottom"),
          gp = gpar(fill = "#1C4649",
                    col = "#1C4649"
          )
)
grid.text("M_KO", 
          x = (end_index_MnKO + end_index_MnHet)/2/ncol(m4), # location at the middle of DN
          y = 1.55,
          #just = "left",
          rot = 0,
          gp = gpar(fontsize = 12,
                    col = "black")) 


## Top label gaps
#Vertical lines
grid.rect(x = end_index_MnTam/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))
grid.rect(x = end_index_MnHet/ncol(m4),
          y = 0,
          height = 1,
          width = unit(0.03, "inches"), # same width as the width of gaps in heatmap
          just = c("center", "bottom"),
          gp = gpar(fill = "white", 
                    col = "white", 
                    lwd = 1
          ))

# step 4 - end by closing the saved file

pdf(file = 'Figures/Male phospho extreme filt.pdf',
    width = 12, 
    height = 24)


CairoSVG(file = "Figures/Male phospho extreme filt.svg", width = 12, height = 24)

#step 2 - draw heatmap in the saved file
draw(heatmap.m)

dev.off()

#########################################################################################
#########################################################################################
#########################################################################################
################################## Venn Diagram ############################################
library(tidyverse)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(gridtext)
library(ggforce)

#import sheets
male <- read.csv("Input/Phospho Male Extreme Filtered_rd.csv", check.names = F)
#male <- male[c(1)]
female <- read.csv("Input/Phospho Female Extreme Filtered_rd.csv", check.names = F)
#female <- female[c(1)]

Male <- male$`Phospho Site`
Female <- female$`Phospho Site`

# Manually define the intersections
intersections <- list(
  m_only = setdiff(Male, Female),   # in Male only
  f_only = setdiff(Female, Male),   # in Female only
  mf     = intersect(Male, Female)  # in both
)

# Coordinates for the labels
coords <- data.frame(
  segment = names(intersections),
  x = c(-1, 1, 0),  # left, right, overlap
  y = c(0, 0, 0)    # same vertical level (adjust if needed)
)

# Combine labels (newline between items)
coords$label <- sapply(intersections, function(x) paste(x, collapse = "\n"))

# Draw Venn diagram
p_venn <- ggplot() +
  geom_circle(aes(x0=-1, y0=0, r=2), fill="lightblue", alpha=0.3) +
  geom_circle(aes(x0=1, y0=0, r=2), fill="lightgreen", alpha=0.3) +
  geom_text(data=coords, aes(x=x, y=y, label=label), size=3) +
  xlim(-3, 3) + ylim(-3, 3) +
  theme_void()

p_venn
################################################################################
################################################################################
################################## Statistical Test ############################

###############Missingness Test ###############################################
#install.packages("exact2x2")
library(exact2x2)

data <- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", check.names = F, row.names = 1) #expression data
data <- data[c(2,7:57)]

pheno <- read_excel("Input/Metadata.xlsx")

data.bin <- column_to_rownames(data, var = "Phospho Site") #Move protein ID information to rownames
data.bin[data.bin > 0] <- 1 #Convert detection events to "1"
data.bin[is.na(data.bin)] <- 0 #Convert non-detection events to "0"

#Define the list samples that belong to the Genotypes
M_Ctrl <- pheno[pheno$Genotype == "M_Ctrl",]
M_Ctrl.samples <- M_Ctrl$Sample

M_KO <- pheno[pheno$Genotype == "M_KO",]
M_KO.samples <- M_KO$Sample

F_Ctrl <- pheno[pheno$Genotype == "F_Ctrl",]
F_Ctrl.samples <- F_Ctrl$Sample

F_KO <- pheno[pheno$Genotype == "F_KO",]
F_KO.samples <- F_KO$Sample

#Summarize presence/absence data for each genotype group and use this to build a new data frame (from which contingency tables can be produced for the Fisher test)
M_Ctrl.dat <- data.bin[,names(data.bin) %in% M_Ctrl.samples]
M_Ctrl.present <- apply(M_Ctrl.dat, 1, sum) #count the number of detections for each protein/row
M_Ctrl.absent <- ncol(M_Ctrl.dat) - M_Ctrl.present #calculate absentees

M_KO.dat <- data.bin[,names(data.bin) %in% M_KO.samples]
M_KO.present <- apply(M_KO.dat, 1, sum) #count the number of detections for each protein/row
M_KO.absent <- ncol(M_KO.dat) - M_KO.present #calculate absentees


F_Ctrl.dat <- data.bin[,names(data.bin) %in% F_Ctrl.samples]
F_Ctrl.present <- apply(F_Ctrl.dat, 1, sum) #count the number of detections for each protein/row
F_Ctrl.absent <- ncol(F_Ctrl.dat) - F_Ctrl.present #calculate absentees


F_KO.dat <- data.bin[,names(data.bin) %in% F_KO.samples]
F_KO.present <- apply(F_KO.dat, 1, sum) #count the number of detections for each protein/row
F_KO.absent <- ncol(F_KO.dat) - F_KO.present #calculate absentees

#Combine presence/absence summary values into a new data frame
df_M <- data.frame(cbind(M_Ctrl.present, M_Ctrl.absent, M_KO.present, M_KO.absent))
rownames(df_M) <- rownames(data.bin) #keep track of which protein is which!

df_F <- data.frame(cbind(F_Ctrl.present, F_Ctrl.absent, F_KO.present, F_KO.absent))
rownames(df_F) <- rownames(data.bin) #keep track of which protein is which!

# Define function using an unconditional exact (Barnard-type) test
apply_barnard_row <- function(row) {
  
  # Successes and totals for each group
  x1 <- row["M_Ctrl.present"]
  n1 <- row["M_Ctrl.present"] + row["M_Ctrl.absent"]
  
  x2 <- row["M_KO.present"]
  n2 <- row["M_KO.present"] + row["M_KO.absent"]
  
  # Run unconditional exact (Barnard-type) test
  barnard_result <- uncondExact2x2(x1 = x1, n1 = n1,
                                   x2 = x2, n2 = n2,
                                   alternative = "two.sided",
                                   tsmethod = "central")
  
  return(c(p_value = barnard_result$p.value,
           estimate = barnard_result$estimate))
}

# Execute for all rows
tmp <- apply(df_M[, c("M_Ctrl.present", "M_Ctrl.absent",
                      "M_KO.present",  "M_KO.absent")],
             1, apply_barnard_row)

temp <- data.frame(t(tmp))
df_M$barnard_p_value <- temp$p_value
df_M$odds <- temp$estimate

# View and histogram
head(df_M)
hist(df_M$barnard_p_value, breaks = 100)

df_M$P.adj <- p.adjust(df_M$barnard_p_value, method = "BH") #Control for multiple hypothesis testing

df_M2 <- df_M %>% filter(barnard_p_value < 0.05)



#save datasheet
#write.csv(df_M, "Output/Missingness Test Male KOvTam.csv")

#######Female Dataset

#Define the function
apply_barnard_row <- function(row) {
  
  # Successes and totals for each group
  x1 <- row["F_Ctrl.present"]
  n1 <- row["F_Ctrl.present"] + row["F_Ctrl.absent"]
  
  x2 <- row["F_KO.present"]
  n2 <- row["F_KO.present"] + row["F_KO.absent"]
  
  # Run unconditional exact (Barnard-type) test
  barnard_result <- uncondExact2x2(x1 = x1, n1 = n1,
                                   x2 = x2, n2 = n2,
                                   alternative = "two.sided",
                                   tsmethod = "central")
  
  return(c(p_value = barnard_result$p.value,
           estimate = barnard_result$estimate))
}

# Execute for all rows
tmp <- apply(df_F[, c("F_Ctrl.present", "F_Ctrl.absent",
                      "F_KO.present",  "F_KO.absent")],
             1, apply_barnard_row)

temp <- data.frame(t(tmp))
df_F$barnard_p_value <- temp$p_value
df_F$odds <- temp$estimate

# View and histogram
head(df_F)
hist(df_F$barnard_p_value, breaks = 100)
summary(df_F$barnard_p_value)

df_F$P.adj <- p.adjust(df_F$barnard_p_value, method = "BH") #Control for multiple hypothesis testing

df_F2 <- df_F %>% filter(barnard_p_value < 0.05)
#save datasheet
#write.csv(df_F, "Output/Missingness Test Female KOvTam.csv")
###########################################################################################
########################randomized missingness test########################################
library(exact2x2)
library(dplyr)

set.seed(NULL) # truly random

# ---- Parameters ----
n_sites   <- 4543  # number of phosphosites (rows)
n_F_Ctrl  <- 6
n_F_KO    <- 11
n_M_Ctrl  <- 5
n_M_KO    <- 10

# ---- Generate random binary matrices ----
F_Ctrl.rand <- matrix(sample(0:1, n_sites * n_F_Ctrl,  replace = TRUE), nrow = n_sites)
F_KO.rand   <- matrix(sample(0:1, n_sites * n_F_KO,    replace = TRUE), nrow = n_sites)
M_Ctrl.rand <- matrix(sample(0:1, n_sites * n_M_Ctrl,  replace = TRUE), nrow = n_sites)
M_KO.rand   <- matrix(sample(0:1, n_sites * n_M_KO,    replace = TRUE), nrow = n_sites)

# ---- Summarize presence/absence ----
F_Ctrl.present <- rowSums(F_Ctrl.rand); F_Ctrl.absent <- n_F_Ctrl - F_Ctrl.present
F_KO.present   <- rowSums(F_KO.rand);   F_KO.absent   <- n_F_KO   - F_KO.present
M_Ctrl.present <- rowSums(M_Ctrl.rand); M_Ctrl.absent <- n_M_Ctrl - M_Ctrl.present
M_KO.present   <- rowSums(M_KO.rand);   M_KO.absent   <- n_M_KO   - M_KO.present

df_M.rand <- data.frame(M_Ctrl.present, M_Ctrl.absent, M_KO.present, M_KO.absent)
df_F.rand <- data.frame(F_Ctrl.present, F_Ctrl.absent, F_KO.present, F_KO.absent)

# ---- Barnard test function (Male) ----
apply_barnard_M <- function(row) {
  barnard_result <- uncondExact2x2(
    x1 = row["M_Ctrl.present"], n1 = row["M_Ctrl.present"] + row["M_Ctrl.absent"],
    x2 = row["M_KO.present"],   n2 = row["M_KO.present"]   + row["M_KO.absent"],
    alternative = "two.sided", tsmethod = "central"
  )
  return(c(p_value = barnard_result$p.value, estimate = barnard_result$estimate))
}

# ---- Barnard test function (Female) ----
apply_barnard_F <- function(row) {
  barnard_result <- uncondExact2x2(
    x1 = row["F_Ctrl.present"], n1 = row["F_Ctrl.present"] + row["F_Ctrl.absent"],
    x2 = row["F_KO.present"],   n2 = row["F_KO.present"]   + row["F_KO.absent"],
    alternative = "two.sided", tsmethod = "central"
  )
  return(c(p_value = barnard_result$p.value, estimate = barnard_result$estimate))
}

# ---- Run tests ----
tmp_M <- apply(df_M.rand[, c("M_Ctrl.present","M_Ctrl.absent","M_KO.present","M_KO.absent")], 1, apply_barnard_M)
tmp_F <- apply(df_F.rand[, c("F_Ctrl.present","F_Ctrl.absent","F_KO.present","F_KO.absent")], 1, apply_barnard_F)

df_M.rand$barnard_p_value <- data.frame(t(tmp_M))$p_value
df_F.rand$barnard_p_value <- data.frame(t(tmp_F))$p_value

# ---- BH correction ----
df_M.rand$P.adj <- p.adjust(df_M.rand$barnard_p_value, method = "BH")
df_F.rand$P.adj <- p.adjust(df_F.rand$barnard_p_value, method = "BH")

# ---- Visualize & compare ----

hist(df_M.rand$barnard_p_value, breaks = 100, main = "Male NULL: Raw p",      xlab = "p-value", col = "steelblue")
hist(df_F.rand$barnard_p_value, breaks = 100, main = "Female NULL: Raw p",    xlab = "p-value", col = "salmon")

# ---- Null hit counts vs. your real results ----
cat("=== MALE ===\n")
cat("Null significant (p < 0.05):        ", sum(df_M.rand$barnard_p_value < 0.05), "\n")

cat("=== FEMALE ===\n")
cat("Null significant (p < 0.05):        ", sum(df_F.rand$barnard_p_value < 0.05), "\n")

################################################################################
################################################################################
################################### LIMMA ######################################
#BiocManager::install("limma")
library(limma)
# ============================================================
# Sex x Genotype Interaction Analysis using limma
# ============================================================
exprs1 <- read.csv("Output/Filtered Prot normalized_Phosphoproteomics Dataset II.csv", check.names = F, row.names = 1) #expression data
#cols <- exprs[c(1:3)]
exprs1 <- exprs1[-c(1,3:6)]
exprs <- exprs1
sample_info <- read.csv("Input/Phosphoproteomics metadata.csv", check.names = F) #metadata

#remove HET samples
sample_info <- sample_info %>%
  filter(Genotype != "HET")

exprs <- exprs[, !grepl("HET", colnames(exprs))]

#set factors
sample_info$Sex      <- factor(sample_info$Sex, levels = c("M", "F"))      # Male is reference
sample_info$Genotype <- factor(sample_info$Genotype, levels = c("Tam", "KO"))       # WT is reference

# ============================================================
# 2. CREATE THE INTERACTION GROUP VARIABLE
# ============================================================
sample_info$group <- factor(paste(sample_info$Sex, sample_info$Genotype, sep = "_"),
                            levels = c("M_Tam", "M_KO", 
                                       "F_Tam", "F_KO"))

# ============================================================
# 3. BUILD THE DESIGN MATRIX
# ============================================================

# Using the group factor with no intercept (~0 + group)
# This makes contrasts more intuitive to specify

design <- model.matrix(~ 0 + group, data = sample_info)
colnames(design) <- levels(sample_info$group)  # clean up column names

# Create weights matrix: 1 = observed, 0.0001 = imputed
weights <- ifelse(is.na(exprs[-c(1)]), 0.0001, 1)

# ============================================================
# 4. DEFINE CONTRASTS
# ============================================================

contrast.matrix <- makeContrasts(
  Interaction_SexByGenotype = (F_KO - F_Tam) - (M_KO - M_Tam),
  levels = design)

# ============================================================
# 6. FIT CONTRASTS AND APPLY EMPIRICAL BAYES
# ============================================================
# Fit the linear model directly to your normalized proteomics expression matrix
fit <- lmFit(exprs, design, weights = weights)
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)

# ============================================================
# 7. EXTRACT RESULTS
# ============================================================
results_interaction <- topTable(fit2, coef = 1, number = nrow(exprs))
results_interaction <- results_interaction %>%
  separate(Phospho.Site, into = c("Gene", "Site"), sep = "_", remove = FALSE)

write.csv(results_interaction, "Output/Limma_Interaction_SexByGenotype phosphosite_norm.csv", row.names = TRUE)

hist(results_interaction$P.Value, breaks = 50,
     main = "P-value distribution - Interaction term",
     xlab = "p-value")

sig_interaction <- results_interaction %>% filter(P.Value < 0.01)
sig_interaction <- sig_interaction[order(-abs(sig_interaction$logFC)), ]
unique_genes <- unique(sig_interaction$Gene)
length(unique_genes)
unique_genes

write.csv(sig_interaction, "Output/Sig hits_Limma_Interaction_SexByGenotype phosphosite_norm.csv", row.names = TRUE)

#########Unnormalized phosphoproteomics dataset
exprs1 <- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", check.names = F, row.names = 1) #expression data
#cols <- exprs[c(1:3)]
exprs <- exprs1
exprs1 <- exprs1[-c(1,3:6)]
sample_info <- read.csv("Input/Phosphoproteomics metadata.csv", check.names = F) #metadata

# Replace NA values with one-fifth of the smallest value in the same row (excluding first column)
#exprs[,-1] <- t(apply(exprs[,-1], 1, function(row) {
#  row[is.na(row)] <- min(row, na.rm = TRUE) / 5
#  row
#}))


# Create weights matrix: 1 = observed, 0.0001 = imputed
weights <- ifelse(is.na(exprs1[-c(1)]), 0.0001, 1)

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)

# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:4)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix, weights = weights)
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeKO - SexF_GenotypeTam,
  levels = design_matrix
)
 #fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
# Add the gene and phosphoindex columns
#results <- merge(cols, results, by = "name")

write.csv(results, "Output/Filt Limma phospho results_F KOvTam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)

#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Filt Sig hits_Limma phospho results_F KOvTam.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexM_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
# Add the gene and phosphoindex columns
#results <- merge(cols, results, by = "name")

write.csv(results, "Output/Filt Limma phospho results_M KOvTam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)

#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Filt Sig hits_Limma phospho results_M KOvTam.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexF_GenotypeKO,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))


write.csv(results, "Output/Filt Limma phospho results_Male v Female KO.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)

#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Filt Sig hits_Limma phospho results_Male v Female KO.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeTam - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))


write.csv(results, "Output/Filt Limma phospho results_Male v Female Tam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)

#########Protein normalized phosphoproteomics dataset
exprs1 <- read.csv("Output/Filtered Prot normalized_Phosphoproteomics Dataset II.csv", check.names = F, row.names = 1) #expression data
#cols <- exprs[c(1:3)]
exprs1 <- exprs1[-c(1,3:6)]
exprs <- exprs1
sample_info <- read.csv("Input/Phosphoproteomics metadata.csv", check.names = F) #metadata

# Replace NA values with one-fifth of the smallest value in the same row (excluding first column)
exprs[,-1] <- t(apply(exprs[,-1], 1, function(row) {
  row[is.na(row)] <- min(row, na.rm = TRUE) / 5
  row
}))


# Create weights matrix: 1 = observed, 0.0001 = imputed
weights <- ifelse(is.na(exprs1[-c(1)]), 0.0001, 1)

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:4)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix, weights = weights)
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeKO - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
# Add the gene and phosphoindex columns
#results <- merge(cols, results, by = "name")

write.csv(results, "Output/Filt norm Limma phospho results_F KOvTam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)

#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Filt norm Sig hits_Limma phospho results_F KOvTam.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexM_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))
# Add the gene and phosphoindex columns
#results <- merge(cols, results, by = "name")

write.csv(results, "Output/Filt norm Limma phospho results_M KOvTam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)

#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Filt norm Sig hits_Limma phospho results_M KOvTam.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexF_GenotypeKO,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))


write.csv(results, "Output/Filt norm Limma phospho results_Male v Female KO.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)

#reorder dataframe
results <- results[order(-abs(results$logFC)), ]
write.csv(results, "Output/Filt norm Sig hits_Limma phospho results_Male v Female KO.csv", row.names = F)
##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeTam - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
results <- topTable(fit2, coef = 1, number = nrow(exprs))


write.csv(results, "Output/Filt norm Limma phospho results_Male v Female Tam.csv", row.names = F)
results <- results %>% filter(adj.P.Val < 0.05)
write.csv(results, "Output/Filt norm Sig hits_Limma phospho results_Male v Female Tam.csv", row.names = F)
################################################################################
################################################################################
#Volcano Plots

library(ggplot2)
library(ggrepel)

########################## Male v Female Control
df <- read.csv("Output/Filt Limma phospho results_Male v Female Tam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05


# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(df$logFC), max(df$logFC))))

#label dots with biggest positive FC
label_point <- df %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 15) 

#label dots with smallest negative FC
label_point2 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 15) 

#label dots with highest logP val
label_point3 <- df %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 15) 


# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(df, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey")), size = 3) +
  xlab(expression(paste("Log"[2]*"FC"*"(Male/Female)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "#3E7F64", "Blue" = "#dc5e0b", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = " ") +  
  theme(
    legend.position = 'none',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  #scale_size_continuous(range = c(1,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,10)) +
  xlim(c(-7,7)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Phospho.Site),
    ylim=c(-log10(0.05), NA),
    color = "#3E7F64",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Phospho.Site),
    ylim=c(-log10(0.05), NA),
    color = "#dc5e0b",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -5-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot
ggsave(filename="Male v Female Tam.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Male v Female Tam.svg",width=6.28,height=5.28,units="in")


########################## Female
#female <- read.csv("Output/Limma lipid results_F_KO.csv", check.names = F)
#female <- read.csv("Output/Filt Limma phospho results_F KOvTam.csv", check.names = F)
female <- read.csv("Output/Filt norm Limma phospho results_F KOvTam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05


# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(female$logFC), max(female$logFC))))

#label dots with biggest positive FC
label_point <- female %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 15) 

#label dots with smallest negative FC
label_point2 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 15) 

#label dots with highest logP val
label_point3 <- female %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(adj.P.Val) %>%
  slice_head(n = 15) 

label_point4 <- female[197,]
# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3, label_point4)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(female, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Log"[2]*"FC"*"(female KO/female CreTam)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = " ") +  
  theme(
    legend.position = 'none',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  #scale_size_continuous(range = c(1,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,10)) +
  xlim(c(-7,7)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Phospho.Site),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Phospho.Site),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -5-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot
ggsave(filename="Female KO v Tam_norm.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Female KO v Tam_norm.svg",width=6.28,height=5.28,units="in")


##################Males
#male <- read.csv("Output/Limma lipid results_M_KO.csv", check.names = F)
#male <- read.csv("Output/Filt Limma phospho results_M KOvTam.csv", check.names = F)
male <- read.csv("Output/Filt norm Limma phospho results_M KOvTam.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(male$logFC), max(male$logFC))))

#convert log average expression to linear scale
#male$meanexpression <- 2^male$AveExpr

#label dots with biggest positive FC
label_point <- male %>%
  filter(adj.P.Val < 0.05 ) %>%
  arrange(desc(logFC)) %>%
  filter(logFC > 0) %>%
  slice_head(n = 10) 

#label dots with smallest negative FC
label_point2 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(logFC) %>%
  filter(logFC < 0) %>%
  slice_head(n = 10) 

#label dots with highest logP val
label_point3 <- male %>%
  filter(adj.P.Val < 0.05) %>%
  arrange(P.Value) %>%
  slice_head(n = 10) 


# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (logFC > 0)
unique_labels2 <- unique_labels %>% filter (logFC < 0)

# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(male, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Log"[2]*"FC"*"(male KO/male CreTam)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = " ") +  
  theme(
    legend.position = 'none',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  #scale_size_continuous(range = c(1,10), limits = range(male$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,8)) +
  xlim(c(-7,7)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Phospho.Site),
    ylim=c(-log10(0.05), NA),
    color = "indianred",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 3-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Phospho.Site),
    ylim=c(-log10(0.05), NA),
    color = "skyblue2",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -3-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot
ggsave(filename="Male KO v Tam_norm.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Male KO v Tam_norm.svg",width=6.28,height=5.28,units="in")
#################################################################################################
#################################################################################################
#################################################################################################
female <- read.csv("Output/Filt norm Limma phospho results_F KOvTam.csv", check.names = F)
df <- read.csv("Input/FA metabolic genes.csv")

#create a new column
female <- female %>%
  mutate(Genes = sub("_.*", "", `Phospho.Site`))

#filter for phosphosites that correspond to the FA metabolic genes
female <- merge(df, female, by = "Genes")

# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05


# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(female$logFC), max(female$logFC))))




# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(female, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"),size = 4)) +
  xlab(expression(paste("Log"[2]*"FC"*"(female KO/female CreTam)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = " ") +  
  theme(
    legend.position = 'none',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  #scale_size_continuous(range = c(1,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,5)) +
  xlim(c(-3,3)) +
  #add label to graph
  geom_text_repel(
    data = female,
    aes(label = Phospho.Site),
    color = "black",
    #box.padding = 0.5,
    point.padding = 0.25,
    max.overlaps = Inf,
    size = 5,
    show.legend = F
  ) 

volcano_plot
ggsave(filename="Female KO v Tam_norm_FA.pdf",width=4,height=4,units="in")
ggsave(filename="Female KO v Tam_norm_FA.svg",width=4,height=4,units="in")




#########################################################################################
#########################################################################################
#########################################################################################
################################## UpSet Plot############################################
library(tidyverse)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(gridtext)
#install.packages("ComplexUpset")
library(ComplexUpset)

#import limma stat sheets
male <- read.csv("Output/Filt norm Limma phospho results_M KOvTam.csv")
female <- read.csv("Output/Filt norm Limma phospho results_F KOvTam.csv")

# Add "_F" to all column names except the first one
colnames(female)[2:ncol(female)] <- paste0(colnames(female)[2:ncol(female)], "_F")

# Add "_M" to all column names except the first one
colnames(male)[2:ncol(male)] <- paste0(colnames(male)[2:ncol(male)], "_M")

#merge male and female sheets
comb <- merge(male, female, by = "Phospho.Site")


# For each comparison, added a column to label the significance as TRUE or FALSE. 
comb$"KO v Tam (M)" <- ifelse(comb$adj.P.Val_M < 0.05, "TRUE", "FALSE")
comb$"KO v Tam (F)" <- ifelse(comb$adj.P.Val_F < 0.05, "TRUE", "FALSE")

#split phosphosite into genes and site columns
comb_2 <- comb %>%
  separate(Phospho.Site, into = c("gene", "site"), sep = "_")

#filter sig proteins for PPI
male_up <- comb_2 %>%
  filter(adj.P.Val_M < 0.05, logFC_M > 0)

male_down <- comb_2 %>%
  filter(adj.P.Val_M < 0.05, logFC_M < 0)

female_up <- comb_2 %>%
  filter(adj.P.Val_F < 0.05, logFC_F > 0)

female_down <- comb_2 %>%
  filter(adj.P.Val_F < 0.05, logFC_F < 0)


# call out the intersected proteins
intersect <- comb_2 %>%
  filter(comb_2$"KO v Tam (M)" == "TRUE",comb_2$"KO v Tam (F)" == "TRUE")

write.csv(intersect, "Output/Intersected Proteins M and F_KO v Tam.CSV")
write.csv(male_up, "Output/Upregulated proteins M_KO v Tam.CSV")
write.csv(male_down, "Output/Downregulated proteins M_KO v Tam.CSV")
write.csv(female_up, "Output/Upregulated proteins F_KO v Tam.CSV")
write.csv(female_down, "Output/Downregulated proteins F_KO v Tam.CSV")



#write.csv(intersect, "Output/Intersected Lipids M and F_KO v Tam.CSV")

# For each comparison, added a column to label the directions of change as Up, Down, or NS.

comb$M_direct <- ifelse(!comb$adj.P.Val_M <0.05, 
                        "NS",
                        ifelse(comb$logFC_M >0,
                               "Up", "Down"))
comb$F_direct <- ifelse(!comb$adj.P.Val_F <0.05, 
                        "NS",
                        ifelse(comb$logFC_F >0,
                               "Up", "Down"))

# Added a column to label the overall direction of change of the 4 comparisons. If all non NA directions are Up or Down, write "Up" or "Down", otherwise write "Different direction"

comb$Intersect_direction <- ifelse(rowSums(comb[, c(16:17)] =="Down", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), 
                                   "Down", 
                                   ifelse(rowSums(comb[, c(16:17)] =="Up", na.rm = TRUE) == rowSums(!comb[, c(16:17)] == "NS"), "Up", "Different direction"))

comb$Intersect_direction <- factor(comb$Intersect_direction, 
                                   levels = c("Up","Down"))

# Plot UpSet

KOvTam <- colnames(comb)[14:15]

upset(comb, KOvTam, name = '', width_ratio = 0.7,
      height_ratio = 0.7, min_size = 1, min_degree = 1,
      
      base_annotations = list(
        'Intersection size' = (
          intersection_size(mapping = aes(fill = Intersect_direction))
          + scale_fill_manual(values = c("indianred3", "skyblue2"))
          + theme(
            axis.title.y = element_text(margin = margin(r = -10), size = 14),
            text = element_text(size = 14),
            legend.title = element_blank(),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank()
          )
        )
      ),
      
      # Trick: set bar height to 0 by scaling y-axis to 0 range
      set_sizes = (
        upset_set_size()
        + scale_y_continuous(limits = c(0, 0))  # Shrinks bars to invisible
        + theme_void()
      ),
      
      stripes = c("white")
) + 
  theme(
    panel.grid = element_blank(),
    text = element_text(size = 14)
  ) +
  patchwork::plot_layout(heights = c(1, 0.5, 1))
ggsave(filename="Male v Female UpSets.png",width=6.14,height=4.21,units="in",dpi=600)
ggsave(filename="Male v Female UpSets.pdf",width=6.14,height=4.21,units="in")
ggsave(filename="Male v Female UpSets.svg",width=6.14,height=4.21,units="in")

#########################################################################################
#########################################################################################
#########################################################################################
######################### KSEA ANALYSIS####################################
library(devtools)
#install.packages("KSEAapp")
library(KSEAapp)
library(tidyverse)
#BiocManager::install("org.Hs.eg.db")
library(org.Hs.eg.db)


################################ Redo Limma with unweighted imputed values################################
#BiocManager::install("limma")
library(limma)

#########Unnormalized phosphoproteomics dataset
exprs1 <- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", check.names = F, row.names = 1) #expression data
#cols <- exprs[c(1:3)]
exprs1 <- exprs1[-c(1,3:6)]
exprs <- exprs1
sample_info <- read.csv("Input/Phosphoproteomics metadata.csv", check.names = F) #metadata

# Replace NA values with one-fifth of the smallest value in the same row (excluding first column)
exprs[,-1] <- t(apply(exprs[,-1], 1, function(row) {
  row[is.na(row)] <- min(row, na.rm = TRUE) / 5
  row
}))

# Create a design matrix
design <- model.matrix(~0 + Sex + Genotype, data = sample_info)

# Combine the design matrix with the interaction terms
design_interaction <- cbind(
  design,
  SexF_GenotypeTam = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "Tam"),
  SexF_GenotypeHet = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "HET"),
  SexF_GenotypeKO = as.numeric(sample_info$Sex == "F" & sample_info$Genotype == "KO"),
  SexM_GenotypeTam = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "Tam"),
  SexM_GenotypeHet = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "HET"),
  SexM_GenotypeKO = as.numeric(sample_info$Sex == "M" & sample_info$Genotype == "KO")
)
# Convert the design data frame to a numeric matrix
design_matrix <- as.matrix(design_interaction)
design_matrix <- design_matrix[,-(1:4)]
# Fit the linear model
fit <- lmFit(exprs, design_matrix)
# contrast
contrast.matrix <- makeContrasts(
  SexF_GenotypeKO - SexF_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
female <- topTable(fit2, coef = 1, number = nrow(exprs))

##############################
# contrast
contrast.matrix <- makeContrasts(
  SexM_GenotypeKO - SexM_GenotypeTam,
  levels = design_matrix
)
#fit the linear model to the contrast
fit2 <- contrasts.fit(fit, contrast.matrix)
fit2 <- eBayes(fit2)
male <- topTable(fit2, coef = 1, number = nrow(exprs))


#import datasheets
phospho<- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", check.names = F, row.names = 1)
m2h <- read.csv("Input/BioMart_mousetohuman.csv", check.names = F)

#filter relevant columns
phospho <- phospho[c(1:6)]
phospho$name <- sub("^[^_]*_", "", phospho$name)
#rename columns
colnames(phospho)[colnames(phospho) == "name"] <- "Peptide"
colnames(phospho)[colnames(phospho) == "Site"] <- "Residue.Both"
m2h <- m2h[c(2,4)]

#merge
phospho <- merge(phospho, m2h, by = "Genes")
phospho <- phospho[-c(1)]
colnames(phospho)[colnames(phospho) == "Human gene name"] <- "Gene"

#remove rows without human gene names
phospho <- phospho %>%
  filter(!is.na(Gene) & Gene != "")
# Change column 
colnames(phospho)[colnames(phospho) == "Phospho Site"] <- "Phospho.Site"
male <- merge(phospho, male, by = "Phospho.Site")
female <- merge(phospho, female, by = "Phospho.Site")

#calculate FC from LogFC
male$FC <- 2^male$logFC
female$FC <- 2^female$logFC

write.csv(male, "Output/Limma phospho results_Male KOvTam II.csv", row.names = F)
write.csv(female, "Output/Limma phospho results_Female KOvTam II.csv", row.names = F)

male <- male[c(4,6,2,5,10,13)]
# rename
colnames(male)[colnames(male) == "P.Value"] <- "p"

female <- female[c(4,6,2,5,10,13)]
# rename
colnames(female)[colnames(female) == "P.Value"] <- "p"

#Run KSEA
KSEA.Complete(KSData, male, NetworKIN=TRUE, NetworKIN.cutoff=3, m.cutoff=3, p.cutoff=0.05)
male.score <- KSEA.Scores(KSData, male, NetworKIN=TRUE, NetworKIN.cutoff=5)

KSEA.Complete(KSData, female, NetworKIN=TRUE, NetworKIN.cutoff=3, m.cutoff=3, p.cutoff=0.05)
female.score <- KSEA.Scores(KSData, female, NetworKIN=TRUE, NetworKIN.cutoff=5)

KSEA.Heatmap(score.list=list(male.score, female.score),
                       sample.labels=c("Male", "Female"),
                       stats="p.value", m.cutoff=3, p.cutoff=0.05, sample.cluster=TRUE)

####################################################################################################
####################################################################################################
####################################################################################################
################################### KSEA Kinase Score ###################################
#Volcano Plots

library(ggplot2)
library(ggrepel)

########################## Male
male <- read.csv("Output/Male KSEA Kinase Scores.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute z value
max_abs_z<- max(abs(c(min(male$z.score), max(male$z.score))))

#label dots with biggest positive z score
label_point <- male %>%
  filter(p.value < 0.05 ) %>%
  arrange(desc(z.score)) %>%
  filter(z.score > 0) %>%
  slice_head(n = 5) 

#label dots with smallest negative z score
label_point2 <-male %>%
  filter(p.value < 0.05) %>%
  arrange(z.score) %>%
  filter(z.score < 0) %>%
  slice_head(n = 7)
 

#label dots with highest logP val
label_point3 <- male %>%
  filter(p.value < 0.05) %>%
  arrange(p.value) %>%
  slice_head(n = 5) 


# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (z.score > 0)
unique_labels2 <- unique_labels %>% filter (z.score < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(male, aes(x=z.score,y= -log10(p.value), size = m)) +
  geom_point(aes(color = ifelse(p.value < significance_threshold,
                                ifelse(z.score > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Kinase z-score"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  labs(title = " ") +  
  theme(
    legend.position = 'none',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  scale_size_continuous(range = c(2,8), limits = range(male$m, na.rm = T)) +
  guides(color = "none", size = guide_legend(title = "#Mapped Sites")) +  # Hides the color legend only
  ylim(c(0,5)) +
  xlim(c(-5,5)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Kinase.Gene),
    ylim=c(-log10(0.05), NA),
    color = "indianred3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Kinase.Gene),
    ylim=c(-log10(0.05), NA),
    color = "deepskyblue3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -5-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot

ggsave(filename="Male KSEA Kinase Z-score II.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Male KSEA Kinase Z-score II.svg",width=6.28,height=5.28,units="in")

################################## Female

female <- read.csv("Output/Female KSEA Kinase Scores.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute z value
max_abs_z<- max(abs(c(min(female$z.score), max(female$z.score))))

#label dots with biggest positive z score
label_point <- female %>%
  filter(p.value < 0.05 ) %>%
  arrange(desc(z.score)) %>%
  filter(z.score > 0) %>%
  slice_head(n = 8) 

#label dots with smallest negative z score
label_point2 <-female %>%
  filter(p.value < 0.05) %>%
  arrange(z.score) %>%
  filter(z.score < 0) %>%
  slice_head(n = 7)


#label dots with highest logP val
label_point3 <- female %>%
  filter(p.value < 0.05) %>%
  arrange(p.value) %>%
  slice_head(n = 8) 


# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (z.score > 0)
unique_labels2 <- unique_labels %>% filter (z.score < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(female, aes(x=z.score,y= -log10(p.value), size = m)) +
  geom_point(aes(color = ifelse(p.value < significance_threshold,
                                ifelse(z.score > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Kinase z-score"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  labs(title = " ") +  
  theme(
    legend.position = 'right',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  scale_size_continuous(range = c(2,8), limits = range(female$m, na.rm = T)) +
  guides(color = "none", size = guide_legend(title = "#Mapped Sites")) +  # Hides the color legend only
  ylim(c(0,5)) +
  xlim(c(-5,5)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Kinase.Gene),
    ylim=c(-log10(0.05), NA),
    color = "indianred3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Kinase.Gene),
    ylim=c(-log10(0.05), NA),
    color = "deepskyblue3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -5-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot

ggsave(filename="Female KSEA Kinase Z-score.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Female KSEA Kinase Z-score.svg",width=6.28,height=5.28,units="in")

####################################################################################################
####################################################################################################
####################################################################################################
############################################ ROKAI #################################################
male<- read.csv("Output/Limma phospho results_Male KOvTam II.csv", check.names = F)
male <- male[c(4,5,7)]
names(male)[names(male) == "Residue.Both"] <- "Position"
names(male)[names(male) == "logFC"] <- "Quantification"

#check if data is centered
hist(male$Quantification)
summary(male$Quantification)

#Center data
male$Quantification <- male$Quantification -
  median(male$Quantification, na.rm = TRUE)

#check if data is centered
hist(male$Quantification)
summary(male$Quantification)
write.csv(male,"Output/ROKAI male.csv", row.names = F)

female<- read.csv("Output/Limma phospho results_Female KOvTam II.csv", check.names = F)
female <- female[c(4,5,7)]
names(female)[names(female) == "Residue.Both"] <- "Position"
names(female)[names(female) == "logFC"] <- "Quantification"

#check if data is centered
hist(female$Quantification)
summary(female$Quantification)

#Center data
female$Quantification <- female$Quantification -
  median(female$Quantification, na.rm = TRUE)
#check if data is centered
hist(female$Quantification)
summary(female$Quantification)


write.csv(female,"Output/ROKAI female.csv", row.names = F)

#run RoKAI kinase scoring on rokai.io

#import result files for plotting
#Volcano Plots

library(ggplot2)
library(ggrepel)

########################## Male
male <- read.csv("Input/Male RoKAI kinase scores.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute z value
max_abs_z<- max(abs(c(min(male$Activity), max(male$Activity))))

#label dots with biggest activity
label_point <- male %>%
  filter(PValue < 0.1 ) %>%
  arrange(desc(Activity)) %>%
  filter(Activity > 0) %>%
  slice_head(n = 5) 

#label dots with smallest negative z score
label_point2 <-male %>%
  filter(PValue < 0.1) %>%
  arrange(Activity) %>%
  filter(Activity < 0) %>%
  slice_head(n = 5)


#label dots with highest logP val
label_point3 <- male %>%
  filter(PValue < 0.1) %>%
  arrange(PValue) %>%
  slice_head(n = 5) 


# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (Activity > 0)
unique_labels2 <- unique_labels %>% filter (Activity < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(male, aes(x=Activity,y= -log10(PValue), size = NumSubs)) +
  geom_point(aes(color = ifelse(PValue < significance_threshold,
                                ifelse(Activity > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Kinase Activity"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  labs(title = " ") +  
  theme(
    legend.position = 'none',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  scale_size_continuous(range = c(2,8), limits = range(male$NumSubs, na.rm = T)) +
  guides(color = "none", size = guide_legend(title = "#Mapped Sites")) +  # Hides the color legend only
  ylim(c(0,5)) +
  xlim(c(-5,5)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Name),
    ylim=c(-log10(0.05), NA),
    color = "indianred3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Name),
    ylim=c(-log10(0.05), NA),
    color = "deepskyblue3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -5-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot

ggsave(filename="Male KSEA Kinase Z-score II.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Male KSEA Kinase Z-score II.svg",width=6.28,height=5.28,units="in")

################################## Female

female <- read.csv("Output/Female KSEA Kinase Scores.csv", check.names = F)
# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05

# Calculate the maximum absolute z value
max_abs_z<- max(abs(c(min(female$z.score), max(female$z.score))))

#label dots with biggest positive z score
label_point <- female %>%
  filter(p.value < 0.05 ) %>%
  arrange(desc(z.score)) %>%
  filter(z.score > 0) %>%
  slice_head(n = 8) 

#label dots with smallest negative z score
label_point2 <-female %>%
  filter(p.value < 0.05) %>%
  arrange(z.score) %>%
  filter(z.score < 0) %>%
  slice_head(n = 7)


#label dots with highest logP val
label_point3 <- female %>%
  filter(p.value < 0.05) %>%
  arrange(p.value) %>%
  slice_head(n = 8) 


# Row-bind the label points
combined_labels <- rbind(label_point, label_point2, label_point3)

# Remove duplicate rows
unique_labels <- unique(combined_labels)
unique_labels1 <- unique_labels %>% filter (z.score > 0)
unique_labels2 <- unique_labels %>% filter (z.score < 0)


# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(female, aes(x=z.score,y= -log10(p.value), size = m)) +
  geom_point(aes(color = ifelse(p.value < significance_threshold,
                                ifelse(z.score > 0, "Red", "Blue"), "Grey"))) +
  xlab(expression(paste("Kinase z-score"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred3", "Blue" = "deepskyblue3", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  labs(title = " ") +  
  theme(
    legend.position = 'right',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  scale_size_continuous(range = c(2,8), limits = range(female$m, na.rm = T)) +
  guides(color = "none", size = guide_legend(title = "#Mapped Sites")) +  # Hides the color legend only
  ylim(c(0,5)) +
  xlim(c(-5,5)) +
  #add label to graph
  geom_text_repel(
    data = unique_labels1,
    aes(label = Kinase.Gene),
    ylim=c(-log10(0.05), NA),
    color = "indianred3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = 4-unique_labels1$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 0,
    size = 4,
    show.legend = F
  ) +
  
  #add label to graph
  geom_text_repel(
    data = unique_labels2,
    aes(label = Kinase.Gene),
    ylim=c(-log10(0.05), NA),
    color = "deepskyblue3",
    box.padding = 0.5,
    point.padding = 0.25,
    segment.color = "black",
    segment.size = 0.25,
    segment.curvature = 0,
    max.overlaps = Inf,
    nudge_x = -5-unique_labels2$logFC,
    #nudge_y = 1,
    direction = "y",
    hjust = 1,
    size = 4,
    show.legend = F
  )

volcano_plot

ggsave(filename="Female KSEA Kinase Z-score.pdf",width=6.28,height=5.28,units="in")
ggsave(filename="Female KSEA Kinase Z-score.svg",width=6.28,height=5.28,units="in")

#####################################################################################
#####################################################################################
#####################2 Dimensional Analysis##########################################
library(dplyr)
library(tidyr)
library(lme4)
#install.packages("lmerTest")
library(lmerTest)
library(purrr)
library(broom)

###################Unnormalized data with protein abundance as covariate - What is happening on the phosphoproteome level
exprs1 <- read.csv("Output/Filtered Phosphoproteomics Dataset III.csv", check.names = F, row.names = 1)
sample_info <- read.csv("Input/Phosphoproteomics metadata.csv", check.names = F)
sample_cols <- sample_info$Sample

# Load proteomics and average to gene level
prot_matrix <- read.csv("Input/Proteomics Dataset II.csv", check.names = F, row.names = 1) %>%
  .[-1] %>%
  filter(Genes != "" & !is.na(Genes)) %>%
  group_by(Genes) %>%
  summarise(across(where(is.numeric), ~ mean(., na.rm = TRUE))) %>%
  column_to_rownames("Genes") %>%
  as.matrix()

# Pivot phospho to long format and join metadata
long_phos <- exprs1 %>%
  dplyr::select(Genes, `Phospho Site`, all_of(sample_cols)) %>%
  pivot_longer(all_of(sample_cols), names_to = "Sample", values_to = "Intensity") %>%
  left_join(sample_info, by = "Sample") %>%
  mutate(Genotype = relevel(factor(Genotype), ref = "Tam"))

# Add matched protein abundance per gene per sample
prot_long <- prot_matrix %>%
  as.data.frame() %>%
  rownames_to_column("Genes") %>%
  pivot_longer(-Genes, names_to = "Sample", values_to = "ProtAbundance")

long_phos <- long_phos %>%
  left_join(prot_long, by = c("Genes", "Sample"))

#fit function
fit_gene_mixed <- function(dat) {
  n_sites <- length(unique(dat$`Phospho Site`))
  gene_name <- unique(dat$Genes)
  
  if (n_sites == 1) {
    m <- try(lm(Intensity ~ Genotype + ProtAbundance, data = dat), silent = TRUE)
    if (inherits(m, "try-error")) {
      return(tibble(log2FC_phos = NA, p.value_phos = NA, n_sites = n_sites,
                    method = "lm_single_error", error = conditionMessage(attr(m, "condition"))))
    }
    cf <- summary(m)$coefficients
    if (!"GenotypeKO" %in% rownames(cf)) {
      return(tibble(log2FC_phos = NA, p.value_phos = NA, n_sites = n_sites,
                    method = "lm_single_error", error = "GenotypeKO term missing from model"))
    }
    return(tibble(log2FC_phos = cf["GenotypeKO", "Estimate"],
                  p.value_phos = cf["GenotypeKO", "Pr(>|t|)"],
                  n_sites = n_sites, method = "lm_single", error = NA))
  }
  
  m <- try(lmerTest::lmer(Intensity ~ Genotype + ProtAbundance + (1 | `Phospho Site`),
                          data = dat, REML = TRUE,
                          control = lmerControl(optimizer = "bobyqa")), silent = TRUE)
  
  if (inherits(m, "try-error") || lme4::isSingular(m, tol = 1e-4)) {
    message("[lm_fallback] Gene ", gene_name, " lmer failed or singular; falling back to lm.")
    m <- try(lm(Intensity ~ Genotype + ProtAbundance, data = dat), silent = TRUE)
    if (inherits(m, "try-error")) {
      return(tibble(log2FC_phos = NA, p.value_phos = NA, n_sites = n_sites,
                    method = "lm_fallback_error", error = conditionMessage(attr(m, "condition"))))
    }
    cf <- summary(m)$coefficients
    if (!"GenotypeKO" %in% rownames(cf)) {
      return(tibble(log2FC_phos = NA, p.value_phos = NA, n_sites = n_sites,
                    method = "lm_fallback_error", error = "GenotypeKO term missing from model"))
    }
    return(tibble(log2FC_phos = cf["GenotypeKO", "Estimate"],
                  p.value_phos = cf["GenotypeKO", "Pr(>|t|)"],
                  n_sites = n_sites, method = "lm_fallback_singular", error = NA))
  }
  
  cf <- summary(m)$coefficients
  if (!"GenotypeKO" %in% rownames(cf)) {
    return(tibble(log2FC_phos = NA, p.value_phos = NA, n_sites = n_sites,
                  method = "lmer_error", error = "GenotypeKO term missing from model"))
  }
  return(tibble(log2FC_phos = cf["GenotypeKO", "Estimate"],
                p.value_phos = cf["GenotypeKO", "Pr(>|t|)"],
                n_sites = n_sites, method = "lmer_multi", error = NA))
}

# Run separately for each sex
results_f <- long_phos %>%
  filter(Sex == "F") %>%
  group_by(Genes) %>%
  group_modify(~ fit_gene_mixed(.x)) %>%
  ungroup() %>%
  mutate(adj.P.Val = p.adjust(p.value_phos, method = "BH"))

results_m <- long_phos %>%
  filter(Sex == "M") %>%
  group_by(Genes) %>%
  group_modify(~ fit_gene_mixed(.x)) %>%
  ungroup() %>%
  mutate(adj.P.Val = p.adjust(p.value_phos, method = "BH"))

results_f <- results_f %>% filter(!is.na(adj.P.Val))
results_m <- results_m %>% filter(!is.na(adj.P.Val))


# Get gene-level estimates from your results
cancellation_check <- results_f %>%                        # or results_m
  select(Genes, log2FC_phos, n_sites) %>%
  filter(n_sites > 1) %>%                                  # only multi-site genes
  inner_join(
    long_phos %>%
      filter(Sex == "F") %>%
      group_by(Genes, `Phospho Site`, Genotype) %>%
      summarise(mean_intensity = mean(Intensity, na.rm = TRUE), .groups = "drop") %>%
      pivot_wider(names_from = Genotype, values_from = mean_intensity) %>%
      mutate(direction = sign(KO - Tam)) %>%
      group_by(Genes) %>%
      filter(n_distinct(direction) > 1) %>%
      summarise(n_opposing_sites = n(), .groups = "drop"),
    by = "Genes"
  ) %>%
  filter(abs(log2FC_phos) < 0.5)                           # near-zero net effect; adjust threshold as needed

cat("Genes likely affected by cancellation:", nrow(cancellation_check), "\n")


write.csv(results_f, "Output/Phosphoprotein results_F KOvTam_protcovar.csv", row.names = F)
write.csv(results_m, "Output/Phosphoprotein results_M KOvTam_protcovar.csv", row.names = F)

results_f %>% filter(adj.P.Val < 0.05) %>% arrange(-abs(log2FC_phos)) %>%
  write.csv("Output/Sig hits_Phosphoprotein results_F KOvTam_protcovar.csv", row.names = F)
results_m %>% filter(adj.P.Val < 0.05) %>% arrange(-abs(log2FC_phos)) %>%
  write.csv("Output/Sig hits_Phosphoprotein results_M KOvTam_protcovar.csv", row.names = F)

########################################
df <- read.csv("Output/Filtered Prot normalized_Phosphoproteomics Dataset II.csv", check.names = F, row.names = 1)
#control and KO females
df_f <- df[c(3,6:12,20:30)]
#control and KO males
df_m <- df[c(3,6,31:35,48:57)]

#import sample metadata
sample_info <- read.csv("Input/Phosphoproteomics metadata.csv", check.names = F) #metadata

#filter female and male metadata
meta_f <- sample_info[1:24,]
meta_m <- sample_info[25:51,]

#remove HET from metadata
meta_f <- meta_f[meta_f$Genotype != "HET", ]
meta_m <- meta_m[meta_m$Genotype != "HET", ]

meta_f <- meta_f[c(1,3)]
meta_m <- meta_m[c(1,3)]

# -----------------------------------------
# 1. Reshape your wide data to long format
# -----------------------------------------

long_phos.m <- df_m %>%
  pivot_longer(
    cols = 3:ncol(.),                 # sample intensity columns
    names_to = "Sample",
    values_to = "Intensity"
  ) %>%
  left_join(meta_m, by = "Sample") 

long_phos.f <- df_f %>%
  pivot_longer(
    cols = 3:ncol(.),                 # sample intensity columns
    names_to = "Sample",
    values_to = "Intensity"
  ) %>%
  left_join(meta_f, by = "Sample") 

# -----------------------------------------
# 2. Mixed Effects Model
# -----------------------------------------
fit_gene_mixed <- function(dat) {
  
  n_sites <- length(unique(dat$Site))
  gene_name <- unique(dat$Genes)
  
  dat$Genotype <- factor(dat$Genotype)
  dat$Genotype <- relevel(dat$Genotype, ref = "Tam")
  
  # CASE 1: Single site → plain lm (random effect not identifiable)
  if (n_sites == 1) {
    message("[lm_single] Gene ", gene_name, " has 1 site; using lm.")
    m <- try(lm(Intensity ~ Genotype, data = dat), silent = TRUE)
    if (inherits(m, "try-error")) {
      return(tibble(log2FC_phos = NA, p.value_phos = NA,
                    n_sites = n_sites, method = "lm_single_error"))
    }
    cf <- summary(m)$coefficients
    return(tibble(log2FC_phos = cf["GenotypeKO", "Estimate"],
                  p.value_phos = cf["GenotypeKO", "Pr(>|t|)"],
                  n_sites = n_sites,
                  method = "lm_single"))
  }
  
  # CASE 2: Multi-site → lmer with Satterthwaite p-values via lmerTest
  if (n_sites >= 2) {
    m <- try(lmerTest::lmer(Intensity ~ Genotype + (1 | Site),
                            data = dat,
                            REML = TRUE,
                            control = lmerControl(optimizer = "bobyqa")),
             silent = TRUE)
    
    if (inherits(m, "try-error") || lme4::isSingular(m, tol = 1e-4)) {
      message("[lm_fallback] Gene ", gene_name, " lmer failed or singular (",
              n_sites, " sites); falling back to lm.")
      m <- try(lm(Intensity ~ Genotype, data = dat), silent = TRUE)
      if (inherits(m, "try-error")) {
        return(tibble(log2FC_phos = NA, p.value_phos = NA,
                      n_sites = n_sites, method = "lm_fallback_error"))
      }
      cf <- summary(m)$coefficients
      return(tibble(log2FC_phos = cf["GenotypeKO", "Estimate"],
                    p.value_phos = cf["GenotypeKO", "Pr(>|t|)"],
                    n_sites = n_sites,
                    method = "lm_fallback_singular"))
    }
    
    cf <- summary(m)$coefficients
    return(tibble(log2FC_phos = cf["GenotypeKO", "Estimate"],
                  p.value_phos = cf["GenotypeKO", "Pr(>|t|)"],
                  n_sites = n_sites,
                  method = "lmer_multi"))
  }
  
  tibble(log2FC_phos = NA, p.value_phos = NA, n_sites = n_sites, method = "undefined")
}

phos_results.m <- long_phos.m %>%
  group_by(Genes) %>%
  group_modify(~ fit_gene_mixed(.x)) %>%
  ungroup() %>%
  mutate(adj.P.Val_phos = p.adjust(p.value_phos, method = "BH"))
write.csv(phos_results.m, "Output/Phosphoprotein results_M KOvTam_norm.csv", row.names = F)

phos_results.f <- long_phos.f %>%
  group_by(Genes) %>%
  group_modify(~ fit_gene_mixed(.x)) %>%
  ungroup() %>%
  mutate(adj.P.Val_phos = p.adjust(p.value_phos, method = "BH"))
write.csv(phos_results.f, "Output/Phosphoprotein results_F KOvTam_norm.csv", row.names = F)
################################################################################################
################################################################################################
################################################################################################
#################2D Analysis Male
#import proteomics and phosphoproteomics data
mprot <- read.csv("Input/Limma proteomics results_M KOvTam II.csv", check.names = F)
mprot <- mprot[-c(1)]

mphos <- read.csv("Output/Filt norm Limma phospho results_M KOvTam.csv", check.names = F)

#create a new column
mphos <- mphos %>%
  mutate(Genes = sub("_.*", "", `Phospho.Site`))

# Add "_prot" to all column names except the first one
colnames(mprot)[2:ncol(mprot)] <- paste0(colnames(mprot)[2:ncol(mprot)], "_prot")

#merge male and female sheets
male <- merge(mprot, mphos, by = "Genes")

#plot data
#filter
male <- male %>% filter(adj.P.Val_prot < 0.05 | adj.P.Val < 0.05)

#plot data
male$significant <- ifelse(male$adj.P.Val < 0.05 & male$adj.P.Val_prot < 0.05, "Both",
                             ifelse(male$adj.P.Val < 0.05, "Phospho Only", "Not Significant"))

ggplot(male, aes(x = logFC, y = logFC_prot, fill = significant, size = -log10(adj.P.Val))) +
  geom_point(alpha = 0.8, shape = 21, color = "black", stroke = 0.3) +
  scale_fill_manual(values = c("Both" = "#C20015", "Phospho Only" = "#dc5e0b", "Not Significant" = "white")) +
  scale_size_continuous(range = c(1, 6), name = expression(-Log[10]*"(adj. p-value)")) +
  scale_x_continuous(limits = c(-5, 5)) +
  scale_y_continuous(limits = c(-3, 3)) +
  theme_minimal() +
  theme(
    panel.border = element_rect(color = "black", fill = NA, size = 0.75),
    panel.grid = element_blank(),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 14),
    plot.title = element_text(size = 14, face = "bold"),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 11)
  ) +
  geom_hline(yintercept = 0, color = "black", linewidth = 0.1, linetype = "dashed") +
  geom_vline(xintercept = 0, color = "black", linewidth = 0.1, linetype = "dashed") +
  labs(
    x = expression(paste(" Log"[2]*"FC Phosphosite")),
    y = expression(paste(" Log"[2]*"FC Protein")),
    title = " ", fill = " "
  )

ggplot(male, aes(x = logFC, y = logFC_prot, fill = significant, size = -log10(adj.P.Val))) +
  geom_point(alpha = 0.8, shape = 21, color = "black", stroke = 0.3) +
  scale_fill_manual(values = c("Both" = "#C20015", "Phospho Only" = "#dc5e0b", "Not Significant" = "white")) +
  scale_size_continuous(range = c(1, 6)) +
  scale_x_continuous(limits = c(-5, 5)) +
  scale_y_continuous(limits = c(-3, 3)) +
  theme_minimal() +
  theme(
    panel.border = element_rect(color = "black", fill = NA, size = 0.75),
    panel.grid = element_blank(),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 14),
    plot.title = element_text(size = 14, face = "bold"),
    legend.position = "none"
  ) +
  geom_hline(yintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  geom_vline(xintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  labs(
    x = expression(paste(" Log"[2]*"FC Phosphosite")),
    y = expression(paste(" Log"[2]*"FC Protein")),
    title = " ", fill = " "
  )

ggsave(filename="Male Scatter plot_Proteomics v Phospho.pdf",width=4.3,height=4.5,units="in")
ggsave(filename="Male Scatter plot_Proteomics v Phospho.svg",width=4.3,height=4.5,units="in")

#################2D Analysis Female
#import proteomics and phosphoproteomics data
fprot <- read.csv("Input/Limma proteomics results_F KOvTam II.csv", check.names = F)
fprot <- fprot[-c(1)]

fphos <- read.csv("Output/Filt norm Limma phospho results_F KOvTam.csv", check.names = F)

#create a new column
fphos <- fphos %>%
  mutate(Genes = sub("_.*", "", `Phospho.Site`))

# Add "_prot" to all column names except the first one
colnames(fprot)[2:ncol(fprot)] <- paste0(colnames(fprot)[2:ncol(fprot)], "_prot")

#merge male and female sheets
female <- merge(fprot, fphos, by = "Genes")

#filter
female <- female %>% filter(adj.P.Val_prot < 0.05 | adj.P.Val < 0.05)

#plot data
female$significant <- ifelse(female$adj.P.Val < 0.05 & female$adj.P.Val_prot < 0.05, "Both",
                             ifelse(female$adj.P.Val < 0.05, "Phospho Only", "Not Significant"))

ggplot(female, aes(x = logFC, y = logFC_prot, fill = significant, size = -log10(adj.P.Val))) +
  geom_point(alpha = 0.8, shape = 21, color = "black", stroke = 0.3) +
  scale_fill_manual(values = c("Both" = "#C20015", "Phospho Only" = "#3E7F64", "Not Significant" = "white")) +
  scale_size_continuous(range = c(1, 6), name = expression(-Log[10]*"(adj. p-value)")) +
  scale_x_continuous(limits = c(-5, 5)) +
  scale_y_continuous(limits = c(-3, 3)) +
  theme_minimal() +
  theme(
    panel.border = element_rect(color = "black", fill = NA, size = 0.75),
    panel.grid = element_blank(),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 14),
    plot.title = element_text(size = 14, face = "bold"),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 11)
  ) +
  geom_hline(yintercept = 0, color = "black", linewidth = 0.1, linetype = "dashed") +
  geom_vline(xintercept = 0, color = "black", linewidth = 0.1, linetype = "dashed") +
  labs(
    x = expression(paste(" Log"[2]*"FC Phosphosite")),
    y = expression(paste(" Log"[2]*"FC Protein")),
    title = " ", fill = " "
  )

ggplot(female, aes(x = logFC, y = logFC_prot, fill = significant, size = -log10(adj.P.Val))) +
  geom_point(alpha = 0.8, shape = 21, color = "black", stroke = 0.3) +
  scale_fill_manual(values = c("Both" = "#C20015", "Phospho Only" = "#3E7F64", "Not Significant" = "white")) +
  scale_size_continuous(range = c(1, 6)) +
  scale_x_continuous(limits = c(-5, 5)) +
  scale_y_continuous(limits = c(-3, 3)) +
  theme_minimal() +
  theme(
    panel.border = element_rect(color = "black", fill = NA, size = 0.75),
    panel.grid = element_blank(),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 14),
    plot.title = element_text(size = 14, face = "bold"),
    legend.position = "none"
  ) +
  geom_hline(yintercept = 0, color = "black", linewidth = 0.1, linetype = "dashed") +
  geom_vline(xintercept = 0, color = "black", linewidth = 0.1, linetype = "dashed") +
  labs(
    x = expression(paste(" Log"[2]*"FC Phosphosite")),
    y = expression(paste(" Log"[2]*"FC Protein")),
    title = " ", fill = " "
  )

ggplot(female, aes(x = logFC, y = logFC_prot, fill = significant, size = -log10(adj.P.Val))) +
  geom_point(alpha = 0.8, shape = 21, color = "black", stroke = 0.3) +
  ggrepel::geom_text_repel(data = subset(female, significant == "Both"),
                           aes(label = `Phospho.Site`, x = logFC, y = logFC_prot),
                           size = 4, inherit.aes = FALSE, max.overlaps = 20) +
  scale_fill_manual(values = c("Both" = "#C20015", "Phospho Only" = "#3E7F64", "Not Significant" = "white")) +
  scale_size_continuous(range = c(1, 6)) +
  scale_x_continuous(limits = c(-5, 5)) +
  scale_y_continuous(limits = c(-3, 3)) +
  theme_minimal() +
  theme(
    panel.border = element_rect(color = "black", fill = NA, size = 0.75),
    panel.grid = element_blank(),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 14),
    plot.title = element_text(size = 14, face = "bold"),
    legend.position = "none"
  ) +
  geom_hline(yintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  geom_vline(xintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  labs(
    x = expression(paste(" Log"[2]*"FC Phosphosite")),
    y = expression(paste(" Log"[2]*"FC Protein")),
    title = " ", fill = " "
  )

ggsave(filename="Female Scatter plot_Proteomics v Phospho.pdf",width=4.3,height=4.5,units="in")
ggsave(filename="Female Scatter plot_Proteomics v Phospho.svg",width=4.3,height=4.5,units="in")

####################################################################################################
####################################################################################################
####################################################################################################
######################### Gene Level Pathway Enrichment Analysis ###################################
library(devtools)
#devtools::install_github("PYangLab/PhosR")
#BiocManager::install("PhosR")
#install.packages("calibrate")
#install.packages("directPA")
#BiocManager::install("annotate")
#if (!requireNamespace("ReactomePA", quietly = TRUE)) {
#  BiocManager::install("ReactomePA")
#}

#install.packages("shape")
#install.packages("generics")
#install.packages("XVector")
#install.packages("viridis")
#install.packages("broom")


library(PhosR)
library(stringr)
library(tidyverse)
library(calibrate)
library(limma)
library(directPA)
library(org.Mm.eg.db)
library(reactome.db)
library(annotate)
library(enrichplot)
library(ReactomePA)

# ---------------------------
# 1) Input: your limma results
# ---------------------------
# Expectation: `de_table` is a data.frame with at least:
#   - a column with gene symbols (or rownames are gene symbols)
#   - a numeric column "logFC" (fold change)
#   - a numeric column "adj.P.Val" (adjusted p-value)

#import datasets collapsed to the gene level
male <- read.csv("Output/Phosphoprotein results_M KOvTam_protcovar.csv", check.names = F)
female <- read.csv("Output/Phosphoprotein results_F KOvTam_protcovar.csv", check.names = F)


# ---------------------------

columns(org.Mm.eg.db) # check the columns in the database, eg. SYMBOL, ENSEMBL, ENTREXID, UNIPROT, GENENAME.
male$entrez <- mapIds(org.Mm.eg.db, keys=male$Genes, keytype="SYMBOL", column="ENTREZID", multiVals="first")
female$entrez <- mapIds(org.Mm.eg.db, keys=female$Genes, keytype="SYMBOL", column="ENTREZID", multiVals="first")

male <- male[!is.na(male$entrez), ] 
female <- female[!is.na(female$entrez), ] 

# ---------------------------
# 4) prepare ranked list for GSEA 
# ---------------------------
#calculate -log10 Pval
epsilon <- 1e-300  # very small number

male$logPval <- -log10(male$adj.P.Val)
female$logPval <- -log10(female$adj.P.Val)

#  use p value * FC sign as rank score
genelist <- sign(male$log2FC_phos) * male$logPval

# entrez id as names of the gene list
names(genelist) <- male$entrez
genelist = sort(genelist, decreasing = TRUE)
head(genelist)

x <- na.omit(genelist) 

######## reactome
gseReactome <- gsePathway(
  geneList=x,
  organism = "mouse",
  minGSSize = 15, 
  maxGSSize = 500,
  pvalueCutoff = 1,
  verbose = TRUE)
gseReactome <- setReadable(gseReactome, OrgDb = org.Mm.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol
gseReactome.df <- as.data.frame(gseReactome)
write.csv(gseReactome.df,"Output/Reactome GSEA Male.csv", row.names = F)

###########female
#  use p value * FC sign as rank score
genelist <- sign(female$log2FC_phos) * female$logPval

# entrez id as names of the gene list
names(genelist) <- female$entrez
genelist = sort(genelist, decreasing = TRUE)
head(genelist)

x <- na.omit(genelist) 

######## reactome
gseReactome <- gsePathway(
  geneList=x,
  organism = "mouse",
  minGSSize = 15, 
  maxGSSize = 500,
  pvalueCutoff = 1,
  verbose = TRUE)

gseReactome <- setReadable(gseReactome, OrgDb = org.Mm.eg.db, keyType="ENTREZID") # The geneID column is translated from EntrezID to symbol
gseReactome.df <- as.data.frame(gseReactome)
write.csv(gseReactome.df,"Output/Reactome GSEA Female.csv", row.names = F)

####################################################################################################
####################################################################################################
######################Dot plot #################################################################

#import of data
female <- read.csv("Output/Reactome GSEA Female.csv")
male <- read.csv("Output/Reactome GSEA Male.csv")

#set p-value at 0.02 to threshold dot plot
female <- female %>% filter(p.adjust < 0.05)
male <- male %>% filter(p.adjust < 0.05)

#export to clean up names
write.csv(female,"Output/dotplot_GSEA Reactome Female KOvTam.csv", row.names = F)
#write.csv(male,"Output/dotplot_GSEA Reactome Male KOvTam.csv", row.names = F)


#import cleaned up names
female <- read.csv("Input/dotplot_GSEA Reactome Female KOvTam II.csv")
#male <- read.csv("Input/dotplot_GSEA Reactome Male KOvTam II.csv")

#convert to log10
female$logPval <- -log10(female$p.adjust)
#male$logPval <- -log10(male$p.adjust)

#split datasets into positive and negative.
female_down <- female %>%
  filter(NES < 0)

female_up <- female %>%
  filter(NES > 0)

# Reorder Description based on p-value
female_down <- female_down %>%
  mutate(Description = factor(Description, levels = Description[order(logPval, decreasing = F)]))

female_up <- female_up %>%
  mutate(Description = factor(Description, levels = Description[order(logPval, decreasing = F)]))

#male <- male %>%
#  mutate(Description = factor(Description, levels = Description[order(logPval, decreasing = F)]))

# Plot dot plot
p.reactome <- ggplot(female_down,
                     aes(x = logPval, y = Description)) +
  geom_point(aes(size = setSize,
                 colour = NES)) +
  scale_color_gradient2(midpoint = -2, low = "skyblue4", mid = "skyblue3", high = "skyblue1", space = "Lab") +
  scale_x_continuous(limits = c(2, 4), breaks = seq(2, 4, by = 1)) +
  scale_size_continuous(range = c(3, 5)) +
  theme_bw(base_size = 14) +
  ylab(NULL) +
  xlab("-Log(p.adjust)") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 14),
    axis.text.x = element_text(colour = "black", size = 14),
    strip.text = element_text(colour = "black")
  ) +
  labs(color = "NES", size = "Set size")

p.reactome
ggsave(filename="Down Dot plot_Females KOvTam.pdf",width=5.4,height=4.45,units="in")
ggsave(filename="Down Dot plot_Females KOvTam.svg",width=5.4,height=4.45,units="in")


# Plot dot plot
p.reactome <- ggplot(female_up,
                     aes(x = logPval, y = Description)) +
  geom_point(aes(size = setSize,
                 colour = NES)) +
  scale_color_gradient2(midpoint = 1.48, low = "salmon", mid = "indianred2", high = "indianred4", space = "Lab") +
  scale_x_continuous(limits = c(1, 9), breaks = seq(1, 9, by = 4)) +
  scale_size_continuous(range = c(3, 5)) +
  theme_bw(base_size = 14) +
  ylab(NULL) +
  xlab("-Log(p.adjust)") +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.minor.x = element_blank(),
    axis.text.y = element_text(colour = "black", size = 14),
    axis.text.x = element_text(colour = "black", size = 14),
    strip.text = element_text(colour = "black")
  ) +
  labs(color = "NES", size = "Set size")

p.reactome
ggsave(filename="Up Dot plot_Females KOvTam.pdf",width=7.3,height=4.45,units="in")
ggsave(filename="Up Dot plot_Females KOvTam.svg",width=7.3,height=4.45,units="in")

################################################################################
################################################################################
################################################################################
#Plot Scatter plot to visualize sex differences
#import proteomics and phosphoproteomics data
interac <- read.csv("Output/Limma_Interaction_SexByGenotype phosphosite_norm.csv", check.names = F,row.names = 1)
male <- read.csv("Output/Filt norm Limma phospho results_M KOvTam.csv", check.names = F)
female <- read.csv("Output/Filt norm Limma phospho results_F KOvTam.csv", check.names = F)

# Add identifiers to all column names except the first one
colnames(interac)[4:ncol(interac)] <- paste0(colnames(interac)[4:ncol(interac)], "_interac")
colnames(male)[2:ncol(male)] <- paste0(colnames(male)[2:ncol(male)], "_male")
colnames(female)[2:ncol(female)] <- paste0(colnames(female)[2:ncol(female)], "_female")

#remove empty rows in the phospho.Site column
male <- male[male$Phospho.Site != "" & !is.na(male$Phospho.Site), ]
female <- female[female$Phospho.Site != "" & !is.na(female$Phospho.Site), ]
interac <- interac[interac$Phospho.Site != "" & !is.na(interac$Phospho.Site), ]

#merge male and female and interac sheets
df <- merge(male, female, by = "Phospho.Site")
df <- merge(interac, df, by = "Phospho.Site")

#filter for proteins that show significance in at least 1 comparison
#df_filtered <- df %>%
#  filter(adj.P.Val_male < 0.05 | 
#           adj.P.Val_female < 0.05 | 
#           P.Value_interac < 0.01)
write.csv(df, "Output/limma combined.csv")
#write.csv(df_filtered, "Output/Sig hits_limma combined.csv")

#filter for phosphosites with significant interaction
df_filtered <- df %>%
  filter( P.Value_interac < 0.01)
write.csv(df_filtered, "Output/Sig hits_limma SexbyGenotype_norm.csv")

# Plot
# Calculate correlation
cor_test <- cor.test(df_filtered$logFC_male, df_filtered$logFC_female, method = "pearson")
r_value <- round(cor_test$estimate, 2)
p_value <- signif(cor_test$p.value, 2)
label_text <- paste0("r = ", r_value, "\n", "p = ", p_value)


# Label dots with most female-driven effects (top logFC_female, significant in females)
label_female <- df_filtered %>%
  filter(adj.P.Val_female < 0.05 & adj.P.Val_male >= 0.05) %>%
  arrange(desc(abs(logFC_female))) %>%
  slice_head(n = 12)

# Label dots with most male-driven effects (top logFC_male, significant in males)
label_male <- df_filtered %>%
  filter(adj.P.Val_male < 0.05 & adj.P.Val_female >= 0.05) %>%
  arrange(desc(abs(logFC_male))) %>%
  slice_head(n = 3)

# Label dots with strongest interaction term
label_interac <- df_filtered %>%
  filter(P.Value_interac < 0.01) %>%
  arrange(P.Value_interac) %>%
  slice_head(n = 10)

# Label dots with highest absolute logFC_male regardless of p value
label_top_male_fc <- df_filtered %>%
  arrange(desc(abs(logFC_male))) %>%
  slice_head(n = 4)

# Label dots with highest absolute logFC_female regardless of p value
label_top_female_fc <- df_filtered %>%
  arrange(desc(abs(logFC_female))) %>%
  slice_head(n = 10)

# Combine and deduplicate
combined_labels <- unique(rbind(label_female, label_male, label_interac, 
                                label_top_male_fc, label_top_female_fc))
labels_female_side <- combined_labels %>% filter(adj.P.Val_female < 0.05 & adj.P.Val_male >= 0.05)
labels_male_side   <- combined_labels %>% filter(adj.P.Val_male < 0.05 & adj.P.Val_female >= 0.05)
labels_both        <- combined_labels %>% filter(adj.P.Val_female < 0.05 & adj.P.Val_male < 0.05)
labels_ns          <- combined_labels %>% filter(adj.P.Val_female >= 0.05 & adj.P.Val_male >= 0.05)

# Separate label_both defined independently to capture all both-sig proteins
labels_both <- df_filtered %>%
  filter(adj.P.Val_female < 0.05 & adj.P.Val_male < 0.05) %>%
  arrange(desc(abs(logFC_female))) %>%
  slice_head(n = 20)

ggplot(df_filtered, aes(x = logFC_male, y = logFC_female)) +
  geom_point(aes(color = case_when(
    adj.P.Val_female < 0.05 & adj.P.Val_male >= 0.05 ~ "Female only",
    adj.P.Val_male < 0.05 & adj.P.Val_female >= 0.05 ~ "Male only",
    adj.P.Val_female < 0.05 & adj.P.Val_male < 0.05  ~ "Both",
    TRUE ~ "NS"),
    size = -log10(P.Value_interac)), alpha = 0.8) +
  scale_color_manual(values = c("Female only" = "#3E7F64", "Male only" = "#dc5e0b", "Both" = "black", "NS" = "grey80"), guide = "none") +
  scale_size_continuous(range = c(1, 7), guide = "none") +
  scale_x_continuous(limits = c(-5, 5)) + scale_y_continuous(limits = c(-5, 5)) +
  geom_hline(yintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  geom_vline(xintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  labs(x = expression(paste(" Male Log"[2]*"FC")), y = expression(paste(" Female Log"[2]*"FC"))) +
  theme_minimal() +
  theme(panel.border = element_rect(color = "black", fill = NA, size = 0.5), panel.grid = element_blank(),
        axis.title = element_text(size = 14), axis.text = element_text(size = 14)) +
  
  # Female-only labels
  geom_text_repel(data = labels_female_side, aes(label = Phospho.Site),
                  color = "#3E7F64", box.padding = 0.5, point.padding = 0.25,
                  segment.color = "black", segment.size = 0.25,
                  max.overlaps = Inf, nudge_x = 3 - labels_female_side$logFC_male,
                  direction = "y", hjust = 0, size = 3.5, show.legend = FALSE) +
  
  # Male-only labels
  geom_text_repel(data = labels_male_side, aes(label = Phospho.Site),
                  color = "#dc5e0b", box.padding = 0.5, point.padding = 0.25,
                  segment.color = "black", segment.size = 0.25,
                  max.overlaps = Inf, nudge_x = -3 - labels_male_side$logFC_male,
                  direction = "y", hjust = 1, size = 3.5, show.legend = FALSE) +
  
  # Both-significant labels
  geom_text_repel(data = labels_both, aes(label = Phospho.Site),
                  color = "black", box.padding = 0.5, point.padding = 0.25,
                  segment.color = "black", segment.size = 0.25,
                  max.overlaps = Inf, min.segment.length = 0,
                  size = 3.5, show.legend = FALSE) +
  
  # NS but extreme logFC labels
  geom_text_repel(data = labels_ns, aes(label = Phospho.Site),
                  color = "grey40", box.padding = 0.5, point.padding = 0.25,
                  segment.color = "grey60", segment.size = 0.25,
                  max.overlaps = Inf, size = 3.5, show.legend = FALSE)

ggplot(df_filtered, aes(x = logFC_male, y = logFC_female)) +
  # All dots except "Both"
  geom_point(aes(fill = case_when(
    adj.P.Val_female < 0.05 & adj.P.Val_male >= 0.05 ~ "Female only",
    adj.P.Val_male < 0.05 & adj.P.Val_female >= 0.05 ~ "Male only",
    TRUE ~ "NS"),
    size = -log10(P.Value_interac)),
    data = df_filtered %>% filter(!(adj.P.Val_female < 0.05 & adj.P.Val_male < 0.05)),
    shape = 21, color = "black", stroke = 0.3, alpha = 0.8) +
  
  # "Both" dots with grey border
  geom_point(aes(size = -log10(P.Value_interac)),
             data = df_filtered %>% filter(adj.P.Val_female < 0.05 & adj.P.Val_male < 0.05),
             shape = 21, fill = "black", color = "grey60", stroke = 0.3, alpha = 0.8) +
  
  scale_fill_manual(values = c("Female only" = "#3E7F64", "Male only" = "#dc5e0b", "NS" = "grey80"), guide = "none") +
  scale_size_continuous(range = c(1, 7), guide = "none") +
  scale_x_continuous(limits = c(-3, 3)) + scale_y_continuous(limits = c(-5, 3)) +
  geom_hline(yintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  geom_vline(xintercept = 0, color = "black", linewidth = 0.3, linetype = "dashed") +
  labs(x = expression(paste(" Male Log"[2]*"FC")), y = expression(paste(" Female Log"[2]*"FC"))) +
  theme_minimal() +
  theme(panel.border = element_rect(color = "black", fill = NA, size = 0.5), panel.grid = element_blank(),
        axis.title = element_text(size = 14), axis.text = element_text(size = 14)) +
  
  # Female-only labels
  geom_text_repel(data = labels_female_side, aes(label = Phospho.Site),
                  color = "#3E7F64", box.padding = 0.5, point.padding = 1,
                  segment.color = "black", segment.size = 0.25,
                  max.overlaps = Inf, min.segment.length = 0,
                  force = 2, force_pull = 0.5,
                  size = 3.5, show.legend = FALSE) +
  
  # Male-only labels
  geom_text_repel(data = labels_male_side, aes(label = Phospho.Site),
                  color = "#dc5e0b", box.padding = 0.5, point.padding = 1,
                  segment.color = "black", segment.size = 0.25,
                  max.overlaps = Inf, min.segment.length = 0,
                  force = 2, force_pull = 0.5,
                  size = 3.5, show.legend = FALSE) +
  
  # Both-significant labels
  geom_text_repel(data = labels_both, aes(label = Phospho.Site),
                  color = "black", box.padding = 0.5, point.padding = 1,
                  segment.color = "black", segment.size = 0.25,
                  max.overlaps = Inf, min.segment.length = 0,
                  force = 2, force_pull = 0.5,
                  size = 3.5, show.legend = FALSE) +
  
  # NS but extreme logFC labels
  geom_text_repel(data = labels_ns, aes(label = Phospho.Site),
                  color = "grey40", box.padding = 0.5, point.padding = 1,
                  segment.color = "grey60", segment.size = 0.25,
                  max.overlaps = Inf, min.segment.length = 0,
                  force = 2, force_pull = 0.5,
                  size = 3.5, show.legend = FALSE)

ggsave(filename="Sex and Genotype Interaction II_norm.pdf",width=4.3,height=4.5,units="in")
ggsave(filename="Sex and Genotype Interaction II_norm.svg",width=4.3,height=4.5,units="in")

#################################################################################################
#################################################################################################
#################################################################################################
female <- read.csv("Output/Filt norm Limma phospho results_F KOvTam.csv", check.names = F)
#female <- read.csv("Output/Filt Limma phospho results_F KOvTam.csv", check.names = F)
df <- read.csv("Input/Insulin Signaling Genes.csv")

#create a new column
female <- female %>%
  mutate(Genes = sub("_.*", "", `Phospho.Site`))

#filter for phosphosites that correspond to the FA metabolic genes
female <- merge(df, female, by = "Genes")

# Set a significance threshold (adjust as needed)
significance_threshold <- 0.05


# Calculate the maximum absolute logFC value
max_abs_logFC <- max(abs(c(min(female$logFC), max(female$logFC))))




# Create a volcano plot with a white background, a centered x-axis at 0, and without the color legend
volcano_plot <- ggplot(female, aes(x=logFC,y= -log10(P.Value))) +
  geom_point(aes(color = ifelse(adj.P.Val < significance_threshold,
                                ifelse(logFC > 0, "Red", "Blue"), "Grey"),size = 4)) +
  xlab(expression(paste("Log"[2]*"FC"*"(female KO/female CreTam)"))) + 
  ylab(expression(paste("-Log"[10]*"p-value"))) +
  scale_color_manual(values = c("Red" = "indianred", "Blue"= "skyblue2", "Grey" = "grey")) +
  #geom_hline(yintercept = -log10(0.0065), linetype = 'dashed', color = "grey") +
  geom_vline(xintercept = 0, linetype = 'dashed', color = "grey") +
  #labs(title = "KO/Control", x = "logFC", y = "-log10(P.Val)", size = "Average Abundance") +
  labs(title = " ") +  
  theme(
    legend.position = 'none',
    panel.background = element_rect(fill = "white"),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(size = 14, color = "black"),   # Axis text
    axis.title = element_text(size = 16, face = "bold"),    # Axis labels
    plot.title = element_text(hjust = 0.5, size = 18, face = "bold"), # Title
    panel.grid = element_blank()
  ) +
  #scale_size_continuous(range = c(1,12), limits = range(female$meanexpression, na.rm = T)) +
  guides(color = "none") +  # Hides the color legend only
  ylim(c(0,5)) +
  xlim(c(-3,3)) +
  #add label to graph
  geom_text_repel(
    data = female,
    aes(label = Phospho.Site),
    color = "black",
    #box.padding = 0.5,
    point.padding = 0.25,
    max.overlaps = Inf,
    size = 5,
    show.legend = F
  ) 

volcano_plot
ggsave(filename="Female KO v Tam_norm_FA.pdf",width=4,height=4,units="in")
ggsave(filename="Female KO v Tam_norm_FA.svg",width=4,height=4,units="in")


#########################################################################################

library(Biostrings)
library(httr)

if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("pwalign")

library(pwalign)

# Fetch human sequence
human_fasta <- GET("https://rest.uniprot.org/uniprotkb/O60237.fasta")
writeLines(content(human_fasta, "text"), "human_PPP1R12B.fasta")

# Fetch mouse sequence
mouse_fasta <- GET("https://rest.uniprot.org/uniprotkb/Q8BG95.fasta")
writeLines(content(mouse_fasta, "text"), "mouse_PPP1R12B.fasta")

# Now read them in
human_seq <- readAAStringSet("human_PPP1R12B.fasta")
mouse_seq <- readAAStringSet("mouse_PPP1R12B.fasta")

human_seq
mouse_seq

alignment <- pairwiseAlignment(
  pattern = mouse_seq[[1]],
  subject = human_seq[[1]],
  type = "global",
  substitutionMatrix = "BLOSUM62",
  gapOpening = 10,
  gapExtension = 0.5
)

alignment

# Check local windows around the sites once you've confirmed sequences loaded correctly
subseq(human_seq[[1]], start = 402, end = 422)  # human T646 ± 10
subseq(mouse_seq[[1]], start = 402, end = 422)  # mouse T649 ± 10


# Get the aligned (gapped) sequences as strings
aligned_mouse  <- as.character(pattern(alignment))
aligned_human  <- as.character(subject(alignment))

# Print the alignment region around the site — find where human position 646 falls
writePairwiseAlignments(alignment)
